
public class main {

    public static void main(String[] args) {

        int matrixOneRows = 2;
        int matrixOneColumns = 3;

        int matrixTwoRows = matrixOneColumns;
        int matrixTwoColumns = matrixOneRows;

        int[][] matrixOne = {{1, 2, 3},
                             {4, 5, 6}};
        
        int[][] matrixTwo = {{0, 0},
                             {0, 0},
                             {0, 0}};
   
        for(int i = 0; i < matrixTwoRows; i++) {
            for (int j = 0; j < matrixTwoColumns; j++) {
                matrixTwo[i][j] = matrixOne[j][i];
            }
        }
        
        for (int i = 0; i < matrixOneRows; i++) {
            for (int j = 0; j < matrixOneColumns; j++) {
                System.out.println("arr[" + i + "][" + j + "] = "
                                   + matrixOne[i][j]); 
            }
        }
        System.out.println("\n\n");
        
        for (int i = 0; i < matrixTwoRows; i++) {
            for (int j = 0; j < matrixTwoColumns; j++) {
                System.out.println("arr[" + i + "][" + j + "] = "
                                   + matrixTwo[i][j]); 
            }
        }

    /*
        data_type[][] array_name = {
                             {valueR1C1, valueR1C2, ....}, 
                             {valueR2C1, valueR2C2, ....}
                           };

        For example: int[][] arr = {{1, 2}, {3, 4}};
      
        MB = NA
        NB = MA
        for (i = 0; i <MB; i++)
            for (j= 0; j<MB; j++)
                MATB[i,j] = MATA[j,i]
     */
}
}
