/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pawn
 */
public class LetterGrade {
    private final String grade;
    private final double pts;
    private final boolean pass;
 
    private LetterGrade (String letGrade, double qualPts, boolean isPass) {
        grade = letGrade;
        pts = qualPts;
        pass = isPass;
    }
 
 
    public String getGrade () {
        return grade;
    }
 
    public boolean isPassing(){
        return pass;
    }
 
 
    public double getQualityPts (){
        return pts;
    }
 
 
    public String toString (){
        return getGrade ();
    }
}
