teamRocket: robotics code for NXT
else
	general coursework (m68k)