import java.util.ArrayList;
import java.util.*;

public class Player {
    private ArrayList<String> developmentCards = new ArrayList<String>();
    private ArrayList<Building> buildings = new ArrayList<Building>();
    private String username;
    private int wood;
    private int wheat;
    private int stone;
    private int sheep;
    private int brick;
    private int victoryPoints;
    private int developmentCardCount;

    //default constructor
    public Player() {
    }

    //Player constructor
    public Player(ArrayList<String> developmentCards,
                  ArrayList<Building> buildings, String username,
                  int wood, int wheat, int stone,
                  int sheep, int brick, int victoryPoints,
                  int developmentCardCount, int totalBuildings) {
        this.developmentCards = developmentCards;
        this.buildings = buildings;
        this.username = username;
        this.wood = wood;
        this.wheat = wheat;
        this.stone = stone;
        this.sheep = sheep;
        this.brick = brick;
        this.victoryPoints = victoryPoints;
        this.developmentCardCount = developmentCardCount;
    }


    public void trade(ArrayList<Player> players, int playersTurn) {
        String userInput = "";
        int trader;
        Player tradePartner = null;
        Scanner console = new Scanner(System.in);
        String resourceWant = "";
        int quantityWanted = 0;
        String resourceOffer = "";
        int quantityOffered = 0;
        boolean tradeFlag = true;
        playersTurn++;


        System.out.println("\n~ Player " + playersTurn + "'s Trade ~" + "\n"
                + "~ Any Player that wanted to Trade, Respond with Player Number: " + "\n"
                + "~ Player 1" + "\n"
                + "~ Player 2" + "\n"
                + "~ Player 3" + "\n"
                + "~ Player 4" + "\n"
                + "~ 9 (No Trade)");
        trader = console.nextInt();

        while (tradeFlag) {
            if (trader == playersTurn) {
                System.out.println("\n~ You cannot trade with yourself >:(");
                return;
            }
            if (trader == 0 && trader <= 4) {
                tradePartner = players.get(trader - 1);

                System.out.println("\n Trade Partner: " + "\n"
                        + tradePartner.getUsername());
                tradeFlag = false;
            }
            if (trader > 4) {
                tradeFlag = false;
                System.out.println("\n~ No one wants to trade with you");
                return;
            }
        }

        System.out.println("\n~ Here is what " + this.getUsername() + " has to offer:\n" + this.toString());
        System.out.println("\n~ Here is what " + tradePartner.getUsername() + " has to offer:\n" + tradePartner.toString());

        System.out.println("\n~ Player Trading ~" + "\n"
                + this.getUsername() + ", which Resource Type to Receive?: " + "\n"
                + " -Wheat" + "\n"
                + " -Stone" + "\n"
                + " -Sheep" + "\n"
                + " -Wood" + "\n"
                + " -Brick");
        resourceWant = console.next();

        System.out.println("\n~ Player Trading ~" + "\n"
                + this.getUsername() + ", which Resource Type to Offer?: " + "\n"
                + " -Wheat" + "\n"
                + " -Stone" + "\n"
                + " -Sheep" + "\n"
                + " -Wood" + "\n"
                + " -Brick");
        resourceOffer = console.next();

        System.out.println("\nHow many " + resourceWant + " do you want to receive");
        quantityWanted = console.nextInt();

        if (resourceWant.equalsIgnoreCase("Wheat") && tradePartner.getWheat() < quantityWanted) {
            System.out.println("Trade Partner is too poor");
            return;
        } else if (resourceWant.equalsIgnoreCase("Stone") && tradePartner.getStone() < quantityWanted) {
            System.out.println("Trade Partner is too poor");
            return;
        } else if (resourceWant.equalsIgnoreCase("Sheep") && tradePartner.getSheep() < quantityWanted) {
            System.out.println("Trade Partner is too poor");
            return;
        } else if (resourceWant.equalsIgnoreCase("Wood") && tradePartner.getWood() < quantityWanted) {
            System.out.println("Trade Partner is too poor");
            return;
        } else if (resourceWant.equalsIgnoreCase("Brick") && tradePartner.getBrick() < quantityWanted) {
            System.out.println("Trade Partner is too poor");
            return;
        }

        System.out.println("\nHow many " + resourceOffer + " do you want to offer");
        quantityOffered = console.nextInt();

        if (resourceOffer.equalsIgnoreCase("Wheat") && this.getWheat() < quantityOffered) {
            System.out.println("Current player too poor");
            return;
        } else if (resourceOffer.equalsIgnoreCase("Stone") && this.getStone() < quantityOffered) {
            System.out.println("Current player too poor");
            return;
        } else if (resourceOffer.equalsIgnoreCase("Sheep") && this.getSheep() < quantityOffered) {
            System.out.println("Current player too poor");
            return;
        } else if (resourceOffer.equalsIgnoreCase("Wood") && this.getWood() < quantityOffered) {
            System.out.println("Current player too poor");
            return;
        } else if (resourceOffer.equalsIgnoreCase("Brick") && this.getBrick() < quantityOffered) {
            System.out.println("Current player too poor");
            return;
        }

        System.out.println("\n~ " + this.username + " wants " + quantityWanted + " " + resourceWant + "\n"
                + "~ from " + tradePartner.getUsername() + "\n"
                + "~ " + tradePartner.getUsername() + " will receive " + quantityOffered + " " + resourceOffer);

        System.out.println("\n~ " + tradePartner.getUsername() + ", Do you accept this trade?" + "\n"
                + "Yes" + "\n"
                + "No");
        userInput = console.next();

        if (userInput.equalsIgnoreCase("Yes")) {
            ////
            //
            //adjust current player's and trade partner's resources in accordance to trade
            //
            ////
            if (resourceOffer.equalsIgnoreCase("Wheat")) {
                this.setWheat(this.getWheat() - quantityOffered);
                tradePartner.setWheat(tradePartner.getWheat() + quantityOffered);
            }
            if (resourceOffer.equalsIgnoreCase("Stone")) {
                this.setStone(this.getStone() - quantityOffered);
                tradePartner.setStone(tradePartner.getStone() + quantityOffered);
            }
            if (resourceOffer.equalsIgnoreCase("Sheep")) {
                this.setSheep(this.getSheep() - quantityOffered);
                tradePartner.setSheep(tradePartner.getSheep() + quantityOffered);
            }
            if (resourceOffer.equalsIgnoreCase("Wood")) {
                this.setWood(this.getSheep() - quantityOffered);
                tradePartner.setWood(tradePartner.getWood() + quantityOffered);
            }
            if (resourceOffer.equalsIgnoreCase("Brick")) {
                this.setBrick(this.getBrick() - quantityOffered);
                tradePartner.setBrick(tradePartner.getBrick() + quantityOffered);
            }
            if (resourceWant.equalsIgnoreCase("Wheat")) {
                tradePartner.setWheat(tradePartner.getWheat() - quantityWanted);
                this.setWheat(this.getWheat() + quantityWanted);
            }
            if (resourceWant.equalsIgnoreCase("Stone")) {
                tradePartner.setStone(tradePartner.getStone() - quantityWanted);
                this.setStone(this.getStone() + quantityWanted);
            }
            if (resourceWant.equalsIgnoreCase("Sheep")) {
                tradePartner.setSheep(tradePartner.getSheep() - quantityWanted);
                this.setSheep(this.getSheep() + quantityWanted);
            }
            if (resourceWant.equalsIgnoreCase("Wood")) {
                tradePartner.setWood(tradePartner.getWood() - quantityWanted);
                this.setWood(this.getWood() + quantityWanted);
            }
            if (resourceWant.equalsIgnoreCase("Brick")) {
                tradePartner.setBrick(tradePartner.getBrick() - quantityWanted);
                this.setBrick(this.getBrick() + quantityWanted);
            }

            System.out.println("\n~ Trade Complete," + "\n"
                    + "~ Trade Results:" + "\n"
                    + this.toString() + "\n"
                    + tradePartner.toString());
        } else {
            System.out.println("\n~ Trade cancelled or declined");
        }
    }


    public void buildBuilding(String type) {

        Settlement settlement = new Settlement();
        City city = new City();
        Road road = new Road();

        if(type == "Settlement"){
            if(this.getWood() < 1 || this.getBrick() < 1 || this.getWheat() < 1 || this.getSheep() < 1){
                System.out.print("\n~ Insufficient Resources \n");
            }
            else{
                this.setWood(this.getWood() - 1);
                this.setBrick(this.getBrick() - 1);
                this.setWheat(this.getWheat() - 1);
                this.setSheep(this.getSheep() - 1);
                this.setVictoryPoints(this.getVictoryPoints() + 1);
                this.getBuildings().add(settlement);//how to add here
                /*need to decide where to place building
                    here
                */

                System.out.print("\n~ Settlement successfully built \n");
            }

        }
        if(type == "City"){
            if(this.getWheat() < 2 || this.getStone() < 3){
                System.out.print("\n~ Insufficient Resources \n");
            }  //this building also has to have a city available
            else if (this.getBuildings().contains("Settlement") == false){
                System.out.print("\n Missing prerequisite Building \n");
            }
            else{
                this.setWheat(this.getWheat() - 2);
                this.setStone(this.getStone() - 3);
                //remove settlement and add city

                this.getBuildings().remove(settlement);
                this.getBuildings().add(city);

                //still need to know how to place city

                this.setVictoryPoints(this.getVictoryPoints() + 1 );
                System.out.print("\n~ City successfully built \n");
            }

        }
        if (type == "Road"){
            if (this.getBrick() < 1 || this.getWood() < 1){
                System.out.print("\n~ Insufficient Resources\n");
            }
            else{
                this.setBrick(this.getBrick() - 1);
                this.setStone(this.getStone() - 1);
                /*
                add road to list of buildings
                Also place road
                 */

                this.getBuildings().add(road);

                //also need to devise a way to check and see if they have the longest road.

                System.out.print("\n~ Road successfully built \n");
            }
        }

    }

    public void playCard(String developmentCard, ArrayList<Player> players) {
        if (developmentCard.equalsIgnoreCase("Soldier")) {

        }
        if (developmentCard.equalsIgnoreCase("Victory Point")) {

        }
        if (developmentCard.equalsIgnoreCase("Monopoly")) {

        }
        if (developmentCard.equalsIgnoreCase("Year of Plenty")) {

        }
        if (developmentCard.equalsIgnoreCase("Road Building")) {

        }
    }


    /*
    public void passTurn(boolean signal) {
        set end turn flag to true
    }
     */

    //getters && setters
    public ArrayList<String> getDevelopmentCards() {
        return developmentCards;
    }

    public void setDevelopmentCards(ArrayList<String> developmentCards) {
        this.developmentCards = developmentCards;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getWood() {
        return wood;
    }

    public void setWood(int wood) {
        this.wood = wood;
    }

    public int getWheat() {
        return wheat;
    }

    public void setWheat(int wheat) {
        this.wheat = wheat;
    }

    public int getStone() {
        return stone;
    }

    public void setStone(int stone) {
        this.stone = stone;
    }

    public int getSheep() {
        return sheep;
    }

    public void setSheep(int sheep) {
        this.sheep = sheep;
    }

    public int getBrick() {
        return brick;
    }

    public void setBrick(int brick) {
        this.brick = brick;
    }

    public int getVictoryPoints() {
        return victoryPoints;
    }

    public void setVictoryPoints(int victoryPoints) {
        this.victoryPoints = victoryPoints;
    }

    public int getDevelopmentCardCount() {
        return developmentCardCount;
    }

    public void setDevelopmentCardCount(int developmentCardCount) {
        this.developmentCardCount = developmentCardCount;
    }

    public ArrayList<Building> getBuildings() {
        return this.buildings;
    }

    public void setTotalBuildings(ArrayList<Building> buildings) {
        this.buildings = buildings;
    }

    @Override
    public String toString() {
        return "\n\n ~ Player: " + "\n" +
                "~ Development Cards: " + developmentCards.toString() + "\n" +
                "~ Buildings: " + buildings.toString() + "\n" +
                "~ Username: '" + username + "\n" +
                "~ Wood: " + wood + "\n" +
                "~ Wheat: " + wheat + "\n" +
                "~ Stone: " + stone + "\n" +
                "~ Sheep: " + sheep + "\n" +
                "~ Brick: " + brick + "\n" +
                "~ Victory Points: " + victoryPoints + "\n" +
                "~ Development Cards: " + developmentCardCount;
    }
}
