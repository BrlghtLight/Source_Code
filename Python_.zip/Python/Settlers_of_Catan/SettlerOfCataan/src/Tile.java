import java.util.ArrayList;
import java.util.Random;


public class Tile {

    // variables
    String type;
    int x, y;
    int pip_val;
    String[] tile_vertices = new String[6];


    // constructor
    public Tile(String type, int x, int y, int pip_val) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.pip_val = pip_val;

        // initiate tile corners as empty
        tile_vertices[0] = "empty";
        tile_vertices[1] = "empty";
        tile_vertices[2] = "empty";
        tile_vertices[3] = "empty";
        tile_vertices[4] = "empty";
        tile_vertices[5] = "empty";
    }

    // get tile corner value
    public String getCornerAt(int vertex) {
        return tile_vertices[vertex];
    }

    //set tile corner
    public void setCornerAt(int vertex, String value) {
        tile_vertices[vertex] =  value;
    }

    // get the x coordinate
    public int getX() {
        return x;
    }

    // get the y coordinate
    public int getY() {
        return y;
    }

    // get the pip_value
    public int getPip_val() {
        return pip_val;
    }

    // get the tile type
    public String getTileType() {
        return type;
    }

}