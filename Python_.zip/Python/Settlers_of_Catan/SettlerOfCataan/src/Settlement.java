public class Settlement extends Building {


    public Settlement() {

        super("Settlement",1);
    }
}
