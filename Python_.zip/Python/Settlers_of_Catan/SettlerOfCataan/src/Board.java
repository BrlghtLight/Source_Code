import java.util.ArrayList;

/*
 */

public class Board {

    // board tiles
    ArrayList<Tile> tiles = new ArrayList<Tile>();

    // constructor
    public Board() {

        // --- Build the Standard Game Board -- //

        // y-index == 2
        tiles.add(new Tile("Mountains", -2, 2, 10));
        tiles.add(new Tile("Pasture", 0, 2, 2));
        tiles.add(new Tile("Forest", 1, 2, 9));

        // y-index == 1
        tiles.add(new Tile("Fields", -2, 1, 12));
        tiles.add(new Tile("Hills", -1, 1, 6));
        tiles.add(new Tile("Pasture", 0, 1, 4));
        tiles.add(new Tile("Hills", 1, 1, 10));

        // y-index == 0
        tiles.add(new Tile("Fields", -2, 0, 9));
        tiles.add(new Tile("Forest", -1, 0, 11));
        tiles.add(new Tile("Desert", 0, 0, 0));
        tiles.add(new Tile("Forest", 1, 0, 3));
        tiles.add(new Tile("Mountains", 2, 0, 9));

        // y-index == -1
        tiles.add(new Tile("Forest", -2, -1, 9));
        tiles.add(new Tile("Mountains", -1, -1, 3));
        tiles.add(new Tile("Fields", 0, -1, 4));
        tiles.add(new Tile("Pasture", 1, -1, 5));

        // y-index == -2
        tiles.add(new Tile("Hills", -1, -2, 5));
        tiles.add(new Tile("Fields", 0, -2, 6));
        tiles.add(new Tile("Pasture", 1, -2, 11));

    }
}