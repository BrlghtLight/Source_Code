import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComponent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.function.*;


public class SettlersGame {

    private static final long serialVersionUID = 1L;
    /* Height of an equilateral triangle with side length = 1 */
    private static final double H = Math.sqrt(3) / 2;

    // -- MAIN -- //
    public static void main(String[] args) {
        //operate game
        String playerCommand = "";
        Scanner console = new Scanner(System.in);
        ArrayList<Player> players = new ArrayList<Player>();
        Player tradePartner;
        int turnCounter = 0;
        int diceRoll = 0;

        //game state flags
        boolean gameFlag = true;
        boolean turnFlag = true;

        //player instance variables
        ArrayList<String> developmentCards = new ArrayList<String>();
        ArrayList<Building> buildings = new ArrayList<Building>();
        String username;
        int wood;
        int wheat;
        int stone;
        int sheep;
        int brick;
        int victoryPoints;
        int developmentCardCount;

        //building instance variables

        //tile instance variables

        //dice instance variables

        //game board instance variables

        //initialize game

        ////////////////
        //
        //
        //create players
        Player currentPlayer;
        username = "Player One";
        Player playerOne = new Player(developmentCards, buildings, username, 10, 10, 31, 11, 11, 0, 0, 0);
        username = "Player Two";
        Player playerTwo = new Player(developmentCards, buildings, username, 10, 10, 10, 10, 10, 0, 0, 0);
        username = "Player Three";
        Player playerThree = new Player(developmentCards, buildings, username, 10, 10, 10, 10, 10, 0, 0, 0);
        username = "Player Four";
        Player playerFour = new Player(developmentCards, buildings, username, 10, 10, 10, 10, 10, 0, 0, 0);
        players.add(playerOne);
        players.add(playerTwo);
        players.add(playerThree);
        players.add(playerFour);

        //create buildings
        DevelopmentCard developmentCardDeck = new DevelopmentCard();
        Dice diceRoller = new Dice();
        //create board
        //create tiles
        //etc......
        //
        //
        ////////////////


        // --- BEGIN BUILD BOARD GUI --- //

        final int width = 50;
        final int height = 50;
        final Hexagon[][] grid = new Hexagon[height][width];
        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                grid[row][col] = new Hexagon(row, col, 50);
            }
        }

        JFrame f = new JFrame("Hexagons");
        f.getContentPane().setLayout(new GridLayout());
        f.getContentPane().add(new JComponent() {
            @Override
            public void paint(Graphics g) {
                g.setColor(new Color(0xFF, 0xFF, 0xFF));
                g.fillRect(0, 0, 1000, 1000);
                g.setColor(new Color(0, 0, 0));
                final int[] xs = new int[6];
                final int[] ys = new int[6];
                for (Hexagon[] row : grid) {
                    for (Hexagon h : row) {
                        final int[] i = {0};
                        h.foreachVertex((x, y) -> {
                            xs[i[0]] = (int) ((double) x);
                            ys[i[0]] = (int) ((double) y);
                            i[0]++;
                        });
                        g.drawPolygon(xs, ys, 6);

                        g.drawString(
                                "(" + h.row + "," + h.col + ")",
                                (int) (h.getCenterX() - 15),
                                (int) (h.getCenterY() + 12)
                        );
                    }
                }
            }
        });
        f.setBounds(0, 0, 500, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        try {
            Thread.sleep(100);
        } catch (Throwable e) {

        } finally {
            f.repaint();
        }

        // --- END BOARD GUI --- //


        gameStart();
        gameBoard();

        //begin players' turns
        int playersTurn = 0;
        while (gameFlag) {
            diceRoll = diceRoller.rollDice();
            gameState(turnCounter, playersTurn, diceRoll);
            currentPlayer = players.get(playersTurn);
            while (turnFlag) {
                System.out.println(playerCommands(playersTurn));
                System.out.print("~ " + currentPlayer.getUsername() + ", what would you like to do?: ");
                playerCommand = console.next();
                switch (playerCommand) {
                    case "1":
                        if (currentPlayer.getSheep() < 0 || currentPlayer.getStone() < 0 || currentPlayer.getWheat() < 0) {
                            System.out.println("\n~ You do not have the required resources");
                        } else {
                            currentPlayer.setSheep(currentPlayer.getSheep() - 1);
                            currentPlayer.setStone(currentPlayer.getStone() - 1);
                            currentPlayer.setWheat(currentPlayer.getWheat() - 1);
                            currentPlayer.getDevelopmentCards().add(developmentCardDeck.drawCard());
                            System.out.println("\n" + currentPlayer.getUsername() + "'s Cards: \n" + currentPlayer.getDevelopmentCards().toString());
                        }
                        break;
                    case "2":
                        System.out.println("\n~ Ports Trading ~" + "\n"
                                + "Which Resource Type to Trade?: " + "\n"
                                + " -Wheat" + "\n"
                                + " -Stone" + "\n"
                                + " -Sheep" + "\n"
                                + " -Wood" + "\n"
                                + " -Brick");
                        playerCommand = console.next();

                        if (playerCommand.equalsIgnoreCase("Wheat")) {
                            if (currentPlayer.getWheat() >= 3) {
                                currentPlayer.setWheat(currentPlayer.getWheat() - 3);
                            } else {
                                System.out.println("\n~ Not enough Wheat");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Stone")) {
                            if (currentPlayer.getStone() >= 3) {
                                currentPlayer.setStone(currentPlayer.getStone() - 3);
                            } else {
                                System.out.println("\n~ Not enough Stone");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Sheep")) {
                            if (currentPlayer.getStone() >= 3) {
                                currentPlayer.setSheep(currentPlayer.getSheep() - 3);
                            } else {
                                System.out.println("\n~ Not enough Sheep");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Wood")) {
                            if (currentPlayer.getWood() >= 3) {
                                currentPlayer.setWood(currentPlayer.getWood() - 3);
                            } else {
                                System.out.println("\n~ Not enough Wood");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Brick")) {
                            if (currentPlayer.getBrick() >= 3) {
                                currentPlayer.setBrick(currentPlayer.getBrick() - 3);
                            } else {
                                System.out.println("\n~ Not enough Brick");
                            }
                        }

                        System.out.println("\n~ Ports Trading ~" + "\n"
                                + "Which Resource Type to Receive?: " + "\n"
                                + " -Wheat" + "\n"
                                + " -Stone" + "\n"
                                + " -Sheep" + "\n"
                                + " -Wood" + "\n"
                                + " -Brick");
                        playerCommand = console.nextLine();

                        if (playerCommand.equalsIgnoreCase("Wheat")) {
                            currentPlayer.setWheat(currentPlayer.getWheat() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Stone")) {
                            currentPlayer.setStone(currentPlayer.getStone() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Sheep")) {
                            currentPlayer.setSheep(currentPlayer.getSheep() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Wood")) {
                            currentPlayer.setWood(currentPlayer.getWood() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Brick")) {
                            currentPlayer.setBrick(currentPlayer.getBrick() + 1);
                        }

                        System.out.println(currentPlayer.toString());

                        break;
                    case "3":
                        System.out.println("\n~ Bank Trading ~" + "\n"
                                + "Which Resource Type to Trade?: " + "\n"
                                + " -Wheat" + "\n"
                                + " -Stone" + "\n"
                                + " -Sheep" + "\n"
                                + " -Wood" + "\n"
                                + " -Brick");
                        playerCommand = console.nextLine();

                        if (playerCommand.equalsIgnoreCase("Wheat")) {
                            if (currentPlayer.getWheat() >= 4) {
                                currentPlayer.setWheat(currentPlayer.getWheat() - 4);
                            } else {
                                System.out.println("\n~ Not enough Wheat");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Stone")) {
                            if (currentPlayer.getStone() >= 4) {
                                currentPlayer.setStone(currentPlayer.getStone() - 4);
                            } else {
                                System.out.println("\n~ Not enough Stone");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Sheep")) {
                            if (currentPlayer.getStone() >= 4) {
                                currentPlayer.setSheep(currentPlayer.getSheep() - 4);
                            } else {
                                System.out.println("\n~ Not enough Sheep");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Wood")) {
                            if (currentPlayer.getWood() >= 4) {
                                currentPlayer.setWood(currentPlayer.getWood() - 4);
                            } else {
                                System.out.println("\n~ Not enough Wood");
                            }
                        } else if (playerCommand.equalsIgnoreCase("Brick")) {
                            if (currentPlayer.getBrick() >= 4) {
                                currentPlayer.setBrick(currentPlayer.getBrick() - 4);
                            } else {
                                System.out.println("\n~ Not enough Brick");
                            }
                        }

                        System.out.println("\n~ Bank Trading ~" + "\n"
                                + "Which Resource Type to Receive?: " + "\n"
                                + " -Wheat" + "\n"
                                + " -Stone" + "\n"
                                + " -Sheep" + "\n"
                                + " -Wood" + "\n"
                                + " -Brick");
                        playerCommand = console.nextLine();

                        if (playerCommand.equalsIgnoreCase("Wheat")) {
                            currentPlayer.setWheat(currentPlayer.getWheat() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Stone")) {
                            currentPlayer.setStone(currentPlayer.getStone() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Sheep")) {
                            currentPlayer.setSheep(currentPlayer.getSheep() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Wood")) {
                            currentPlayer.setWood(currentPlayer.getWood() + 1);
                        } else if (playerCommand.equalsIgnoreCase("Brick")) {
                            currentPlayer.setBrick(currentPlayer.getBrick() + 1);
                        }

                        System.out.println(currentPlayer.toString());
                        break;
                    case "4":
                        currentPlayer.trade(players, playersTurn);
                        System.out.print("\n\n~~~ Back in case 4 ~~~~\n\n");
                        //
                        break;
                    case "5":

                        String buildCommand = "";
                        System.out.print("\n~ which building do you want to build: \n"
                                + "~ 1 - Settlement" + "\n"
                                + "~ 2 - City" + "\n"
                                + "~ 3 - Road" + "\n"
                        );
                        buildCommand = console.next();

                        switch (buildCommand) {
                            case "1":
                                currentPlayer.buildBuilding("Settlement");
                                break;

                            case "2":
                                currentPlayer.buildBuilding("City");
                                break;

                            case "3":
                                currentPlayer.buildBuilding("Road");
                                break;

                            default:
                                System.out.println("Invalid Command");
                        }
                        break;
                    case "6":
                        System.out.println("\n~ Development Cards for " + currentPlayer.getUsername() + "\n"
                                + "~ " + currentPlayer.getDevelopmentCards().toString());
                        if (currentPlayer.getDevelopmentCards().isEmpty()) {
                            System.out.println("\n~ " + currentPlayer.getUsername() + ", you have no development cards");
                        } else {
                            System.out.println("\n~ Which card to use?: ");
                            playerCommand = console.next();
                            currentPlayer.playCard(playerCommand, players);
                        }
                        break;
                    case "0":
                        System.out.println("\n~ Passing turn");
                        turnFlag = false;
                        break;
                    default:
                        System.out.println("Invalid Command");
                }
            }
            playersTurn++;
            turnFlag = true;
            turnCounter++;
            if (playersTurn == 4) {
                playersTurn = 0;
            }
        }
    }

    public static void gameStart() {
        System.out.println("\n ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~"
                + "\n ~    ~      ~         ~           ~          ~    ~"
                + "\n ~        ~        ~          ~          ~         ~"
                + "\n ~   ~        ~            ~        ~          ~   ~"
                + "\n ~            Welcome to Settlers of Catan!        ~"
                + "\n ~    ~      ~         ~           ~          ~    ~"
                + "\n ~        ~        ~          ~          ~         ~"
                + "\n ~   ~        ~            ~        ~          ~   ~"
                + "\n ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");
    }

    public static void gameState(int turnCount, int playersTurn, int diceRoll) {
        playersTurn++;
        System.out.println("\n ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~"
                + "\n ~  Settlers of Catan ~        ~        ~          ~"
                + "\n ~  Game State:    ~                         ~     ~"
                + "\n ~  Total Turns Taken:" + turnCount + ", Player " + playersTurn + "              ~   ~"
                + "\n ~  Player " + playersTurn + "'s roll is " + diceRoll
                + "\n ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");
    }

    public static void gameBoard() {
        System.out.println(
                " ---   ---   ---" + "\n"
                        + "-   - -   - -   -" + "\n"
                        + " ---   ---   ---" + "\n"
                        + "" + "\n");
    }

    public static String playerCommands(int playersTurn) {
        playersTurn += 1;
        return "\n ~ ~ ~ ~ ~ ~ Player: " + playersTurn + " ~ ~ ~ ~ ~ ~" + "\n"
                + "~ 1 --- Purchase Development Card" + "\n"
                + "~ 2 --- Trade with Port" + "\n"
                + "~ 3 --- Trade with Bank" + "\n"
                + "~ 4 --- Trade with Player" + "\n"
                + "~ 5 --- Build" + "\n"
                + "~ 6 --- Use Development Card" + "\n"
                + "~ 0 --- Pass Turn" + "\n"
                + "~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~";
    }

    static class Hexagon {
        final int row;
        final int col;
        final double sideLength;

        public Hexagon(int r, int c, double a) {
            this.row = r;
            this.col = c;
            this.sideLength = a;
        }

        double getCenterX() {
            return 2 * H * sideLength * (col + (row % 2) * 0.5);
        }

        double getCenterY() {
            return 3 * sideLength / 2 * row;
        }

        void foreachVertex(BiConsumer<Double, Double> f) {
            double cx = getCenterX();
            double cy = getCenterY();
            f.accept(cx + 0, cy + sideLength);
            f.accept(cx - H * sideLength, cy + 0.5 * sideLength);
            f.accept(cx - H * sideLength, cy - 0.5 * sideLength);
            f.accept(cx + 0, cy - sideLength);
            f.accept(cx + H * sideLength, cy - 0.5 * sideLength);
            f.accept(cx + H * sideLength, cy + 0.5 * sideLength);
        }
    }


}








