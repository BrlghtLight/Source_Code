public class Road extends Building {


    public Road() {
        super("Road", 0);
        //vps for roads only comes once the longest road is achieved.  
    }
}
