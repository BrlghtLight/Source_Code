public class City extends Building {


    public City() {
        super("City", 2);
    }
}
