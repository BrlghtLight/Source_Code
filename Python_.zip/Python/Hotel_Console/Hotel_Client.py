import hashlib
import pymysql
import uuid
import random
import datetime
#from validate_email import validate_email

connection = pymysql.connect(host='mrbartucz.com',
                             user='rv7388ow',
                             password='S3qu3nc3112358',
                             db='rv7388ow_hotel_mgmt',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)


def default():
    return "Invalid Entry"


def Exit():
    end()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# GUEST DEFS
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def Guest_Access():
    guestMenu()


def Guest_Create():
    createGuest()


def Guest_View_Booking():
    guestView()


def Guest_Forgot_Booking():
    guestForgot()


def Guest_Return_Main():
    guestMenu()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# ADMIN DEFS
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
def Admin_Access():
    adminMenu()


def Admin_Login():
    adminLogin()


def Admin_Create():
    adminCreate()


def Admin_View_Guest():
    adminView()


def Admin_Modify_Menu():
    adminModify()

def Admin_Modify_gName():
    adminModifyName()

def Admin_Modify_gEmail():
    adminModifyEmail()

def Admin_Modify_gBooking():
    adminModifyBooking()

def Admin_Modify_gNumber():
    adminModifyNumber()

def Admin_Modify_gAddress():
    adminModifyAddress()


def Admin_Return_Main():
    adminMenu()


def Admin_Log_Out():
    mainMenu()


def mainMenu():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Pending>                             \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       \\ 1: Guest                    /       \\" + "\n"
          + "\\       / 2: Admin                    \\       /" + "\n"
          + "/       \\ 0: Quit                     /       \\" + "\n"
          + "\\                                             /" + "\n"
          + "/                                             \\" + "\n"
          + "\\  |Input")
    userInput = input("/  |Enter Command: ")
    return userInput


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# GUEST MENUS                                                                                                           #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

def get_user_checkin_date():
    while True:
        try:
            print("Enter the following information for the day you wish to check in: ")
            year = int(input("Enter a year: "))
            month = int(input("Enter a month: "))
            day = int(input("Enter a day: "))
            date1 = datetime.date(year, month, day)
            return date1
        except ValueError:
            print("Invalid Input!")


def get_user_checkout_date():
    while True:
        try:
            print("Enter the following information for the day you wish to check out: ")
            year = int(input("Enter a year: "))
            month = int(input("Enter a month: "))
            day = int(input("Enter a day: "))
            date1 = datetime.date(year, month, day)
            return date1
        except ValueError:
            print("Invalid Input!")

def get_input():
    keywords = ['basic', 'deluxe', 'luxury']
    user_input = None
    while True:
        user_input = input("\\ Please choose a room type: (Basic, Deluxe, or Luxury: ")
        if user_input.casefold() in keywords:
            break
    return user_input


def guestMenu():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Guest>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       \\ 10: Request Booking           /      \\" + "\n"
          + "\\       / 11: View Booking              \\      /" + "\n"
          + "/       \\ 12: Modify Booking            /      \\" + "\n"
          + "/       \\                              /      \\" + "\n"
          + "\\       / 5: Return                    \\      /" + "\n"
          )


def createGuest():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Guest>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n")
    try:
        with connection.cursor() as cursor:
            guestID = 0
            while True:
                guestFirst = input("/ Enter First Name: ")
                if guestFirst.isalpha():
                    break
                else:
                    print("Please enter a valid string")
            while True:
                guestLast = input("/ Enter Last Name: ")
                if guestLast.isalpha():
                    break
                else:
                    print("Please enter a valid string")
            while True:
                guestEmail = input("Enter Email: ")
                if validate_email(guestEmail):
                    break
                else:
                    print("Enter a valid email address")
            while True:
                guestPhone = input("\\ Enter Phone Number: ")
                if guestPhone.isnumeric():
                    break
                else:
                    print("Please use integers only! Try again.")
            guestAddress = input("Enter Address: ")
            while True:
                guestCount = input("\\ Enter Guest Count: ")
                if guestCount.isnumeric():
                    break
                else:
                    print("Please enter how many people will be staying with us. Maximum is 6")


            sql = "INSERT INTO guest (guest_id, guest_fname, guest_lname, guest_email, phone_number, guest_address, guest_count)" \
                  "VALUES (%s, %s, %s, %s, %s, %s, %s)"
            args = (guestID, guestFirst, guestLast, guestEmail, guestPhone, guestAddress, guestCount)
            cursor.execute(sql, args)
            connection.commit()
            bookingid = random.randint(1, 249)
            checkindate = get_user_checkin_date()
            checkoutdate = get_user_checkout_date()
            roomtype = get_input()
            sql = "INSERT INTO booking (booking_id, guest_id, checkin_date, checkout_date, room_type)"  "VALUES (%s, %s, %s, %s, %s)"
            args = (bookingid, guestID, checkindate, checkoutdate, roomtype)
            cursor.execute(sql, args)
            connection.commit()

    except Exception as e:
        print(e)
    finally:
        connection.commit()
        mainMenu()

def guestView():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Guest>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n")
    try:
        with connection.cursor() as cursor:
            guestPhone = input("Enter Phone Number: ")

            sql = "SELECT booking_id, booking.guest_id, checkin_date, checkout_date, room_type FROM booking INNER JOIN guest ON booking.guest_id=guest.guest_id WHERE guest.phone_number = %s"
            to_sql = guestPhone
            cursor.execute(sql, to_sql)
        for result in cursor.fetchall():
            bid = result.get('booking_id')
            gid = result.get('guest_id')
            cid = result.get('checkin_date')
            cod = result.get('checkout_date')
            rt = result.get('room_type')
        print(" Booking ID: ", bid, "\n", "Guest ID: ", gid, "\n", "Check-In Date: ", cid, "\n",
              "Check-Out Date: ", cod, "\n", "Room Type: ", rt)
    except Exception as e:
        print(e)

    finally:
        print("Hotel Information as Follows: ")
        connection.commit()
        mainMenu()


def guestForgotBooking():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Admin>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n")
    try:
        with connection.cursor() as cursor:
            guestid = input("Enter your phone number: ")
            sql = "SELECT * FROM booking WHERE guest_id = %d"
            to_sql = int(guestid)
            cursor.execute(sql, to_sql)
            connection.commit()
    except Exception as e:
        print(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# ADMINISTRATOR MENUS                                                                                                   #
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

def adminMenu():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Admin>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       \\ 20: Create Account                 \\" + "\n"
          + "\\       / 21: Login                           /" + "\n"
          + "\\       /                                    \\" + "\n"
          + "/       \\ 4: Return                           /" + "\n"

          )

def adminModify():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
              + "/ Role: <Admin>                               \\" + "\n"
              + "\\                                             /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\       >      Hotel California        <      /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\                                             /" + "\n"
              + "/       \\ 30: Modify Guest Name           /  \\" + "\n"
              + "\\       / 31: Modify Guest Email      \\      /" + "\n"
              + "/       \\ 32: Modify Guest Booking     /     \\" + "\n"
              + "/       /  33: Modify Guest Phone Number\\    \\" + "\n"
              + "\\      \\ 34: Modify Guest Address     /      /" + "\n"
              + "/        /                              \\    \\" + "\n"
              + "\\       / 35: Return                    /     /" + "\n"
              )
    userInput = input("/  |Enter Command: ")
    return userInput

def adminModifyName():
    while True:
        print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
              + "/ Role: <Admin>                               \\" + "\n"
              + "\\                                             /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\       >      Hotel California        <      /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\                                             /" + "\n")
        try:
            with connection.cursor() as cursor:
                while True:
                    guestidmod = input("\\ Enter ID of Guest to Modify: ")
                    if guestidmod.isnumeric():
                        break
                    else:
                        print("Please use integers only! Try again.")
                while True:
                    gfirstName = input("/ Enter First Name: ")
                    if gfirstName.isalpha():
                        break
                    else:
                        print("Please enter a valid string")
                while True:
                    glastName = input("/ Enter Last Name: ")
                    if glastName.isalpha():
                        break
                    else:
                        print("Please enter a valid string")
                sql = "UPDATE guest SET fName = '%s', lName = '%s' WHERE guest_id = '%s' "
                to_sql = gfirstName, glastName, guestidmod
                connection.commit()

        finally:
            connection.commit()
            print("Record updated successfully")
            adminModify()

def adminModifyEmail():
    adminModify()

def adminModifyBooking():
    adminModify()

def adminModifyNumber():
    adminModify()

def adminModifyAddress():
    adminModify()




def adminCreate():
    while True:
        print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
              + "/ Role: <Admin>                               \\" + "\n"
              + "\\                                             /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\       >      Hotel California        <      /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\                                             /" + "\n")

        try:
            with connection.cursor() as cursor:
                adminID = 0
                username = input("/ Enter a Username: ")
                password = input("\\ Enter a Password: ").encode("utf-8")
                salt = uuid.uuid4().hex.encode("utf-8")
                hashedPassword = hashlib.sha512(password + salt).hexdigest()
                while True:
                    firstName = input("/ Enter First Name: ")
                    if firstName.isalpha():
                        break
                    else:
                        print("Please enter a valid string")
                while True:
                    lastName = input("/ Enter Last Name: ")
                    if lastName.isalpha():
                        break
                    else:
                        print("Please enter a valid string")
                while True:
                    email = input("Enter Email: ")
                    if validate_email(email):
                        break
                    else:
                        print("Enter a valid email address")
                while True:
                    phoneNumber = input("\\ Enter Phone Number: ")
                    if phoneNumber.isnumeric():
                        break
                    else:
                        print("Please use integers only! Try again.")
                sql = "INSERT INTO admin (admin_id, username, salt, hash, fname, lname, email, phone_number)" \
                      "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
                args = (adminID, username, salt, hashedPassword, firstName, lastName, email, phoneNumber)
                cursor.execute(sql, args)
                connection.commit()
        except Exception as e:
            print(e)


def adminLogin():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Admin>                               \\" + "\n"
          + "\\                                             /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\       >      Hotel California        <      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
          + "\\                                             /" + "\n")

    try:
        with connection.cursor() as cursor:
            username_login = str(input("Enter user name: "))
            password_login = (input("Enter password: "))

            sql = "SELECT * FROM admin WHERE username = %s"
            to_sql = username_login
            cursor.execute(sql, to_sql)

        for result in cursor:
            savedSalt = result.get('salt').encode('utf-8')
            savedHash = result.get('hash')
        connection.commit()

        check_hashed_password = hashlib.sha512(password_login + savedSalt).hexdigest()
        connection.commit()
        if savedHash == check_hashed_password:
            print("Password accepted, please log out when done")
        else:
            print("Incorrect Password, please try again.")
    finally:
        connection.commit()
        print("/ Access Granted")
        adminModify()

def adminView():
    print("\n\\~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~/" + "\n"
          + "/ Role: <Admin>                                         \\" + "\n"
          + "\\                                                      /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<               \\" + "\n"
          + "\\       >      Hotel California        <              /" + "\n"
          + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<               \\" + "\n"
          + "\\                                                      /" + "\n"
          + "/       \\ 1: Input Guest Phone Number: /             \\" + "\n"
          + "\\       /                              \\            /" + "\n"
          + "/       \\ 24: Return                    /      \\" + "\n")
    userInput = input("/  |Enter: ")
    if int(userInput) == 1:
        try:
            with connection.cursor() as cursor:
                targetGuest = input("\\ Enter Guest Phone Number: ")
                sql = "SELECT * FROM guest WHERE phone_number LIKE (phone_number))" \
                      "VALUES (%s)"
                cursor.execute(sql, targetGuest)
                connection.commit()
        except Exception as e:
            print(e)
    else:
        print("\\                                             /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\       >      Returning....             <      /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n")

    def end():

        print("\\                                             /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\       >      Exiting....             <      /" + "\n"
              + "/       > ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~<      \\" + "\n"
              + "\\                                             /" + "\n")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    # SWITCH KEYS
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#


def ui(userInput):
    switcher = {
        1: Guest_Access,
        2: Admin_Access,
        3: Exit,
        10: Guest_Create,
        11: Guest_View_Booking,
        12: Guest_Forgot_Booking,
        13: Guest_Return_Main,
        20: Admin_Create,
        21: Admin_Login,
        22: Admin_View_Guest,
        23: Admin_Modify_Menu,
        30: Admin_Modify_gName,
        31: Admin_Modify_gEmail,
        32: Admin_Modify_gBooking,
        33: Admin_Modify_gNumber,
        34: Admin_Modify_gAddress,
        24: Admin_Return_Main,
        25: Admin_Log_Out,
    }
    return switcher.get(userInput, default)()


userInput = mainMenu()

while True:
    ui(int(userInput))
    if int(userInput) == 3:
        break
    print("\\                                             /" + "\n"
          + "/                                             \\" + "\n"
          + "\\  |Input")
    userInput = input("/  |Enter Command: ")

connection.close()
