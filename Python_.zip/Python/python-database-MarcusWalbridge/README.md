# Python-MySQL-Database-Connection

How to create a connection to a MySQL database using Python and PyMySQL

If you don't have PyMySQL already installed (Python gives an error "No Module PyMySQL")
Try the following command:

pip3 install pymysql

If you're in Thonny, just go into Tools->Packages and search for it, then install it.
