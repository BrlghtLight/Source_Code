public class City extends Building {
    private String name;
    private int victoryPoints;
    public City(String name, int victoryPoints) {
        this.name = "City";
        this.victoryPoints = 3;
    }
}
