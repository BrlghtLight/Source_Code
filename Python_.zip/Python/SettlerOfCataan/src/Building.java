public class Building {
    private String name = "Building";
    private int victoryPoints = 0;

    public Building(){}
    public Building(String name, int victoryPoints) {
        this.name = name;
        this.victoryPoints = victoryPoints;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVictoryPoints() {
        return victoryPoints;
    }

    public void setVictoryPoints(int victoryPoints) {
        this.victoryPoints = victoryPoints;
    }

    @Override
    public String toString() {
        return "Building:" + "\n" +
                "Name: '" + name + "\n" +
                "Victory Points: " + victoryPoints;
    }
}
