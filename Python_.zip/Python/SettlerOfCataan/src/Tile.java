import java.util.ArrayList;
import java.util.Random;


/*
 */

public class Tile {

    // variables
    String type;
    int x, y;

    // constructor
    public Tile(String type) {
        this.type = type;
    }

    // set the tile coordinates
    public void setCoordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // get the x coordinate
    public int getX() {
        return x;
    }

    // get the y coordinate
    public int getY() {
        return y;
    }

    // get the tile type
    public String getTileType() {
        return type;
    }

}