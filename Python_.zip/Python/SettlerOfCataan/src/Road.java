public class Road extends Building {
    private String name;
    private int victoryPoints;
    public Road(String name, int victoryPoints) {
        this.name = "Road";
        this.victoryPoints = 0;
    }
}
