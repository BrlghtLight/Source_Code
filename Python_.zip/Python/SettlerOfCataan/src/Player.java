import java.util.ArrayList;

public class Player {
    private ArrayList<String> developmentCards = new ArrayList<String>();
    private ArrayList<Building> buildings = new ArrayList<Building>();
    private String username;
    private int wood;
    private int wheat;
    private int stone;
    private int sheep;
    private int brick;
    private int victoryPoints;
    private int developmentCardCount;

    //default constructor
    public Player() {
    }

    //Player constructor
    public Player(ArrayList<String> developmentCards,
                  ArrayList<Building> buildings, String username,
                  int wood, int wheat, int stone,
                  int sheep, int brick, int victoryPoints,
                  int developmentCardCount, int totalBuildings) {
        this.developmentCards = developmentCards;
        this.buildings = buildings;
        this.username = username;
        this.wood = wood;
        this.wheat = wheat;
        this.stone = stone;
        this.sheep = sheep;
        this.brick = brick;
        this.victoryPoints = victoryPoints;
        this.developmentCardCount = developmentCardCount;
    }

    /*
    public String trade(Player tradePartner) {
        //only need trade partner as all needed info will
        //be pulled from them and
        //initiator already calling this method (we have their info)

        //return "" the details of the trade to output area
    }
     */

    /*
    public String buildBuilding(String type) {

        //if type == the 3 types
        //subtract necessary resources from the player

        //player will place building within this as well

        //return details about the building
    }
     */

    /*
    public String playCard(String someCard) {

        //search players cards for the String
        //perform the action (probably via dev card)
        //return the result String

    }
     */

    /*
    public void passTurn(boolean signal) {
        set end turn flag to true
    }
     */

    //getters && setters
    public ArrayList<String> getDevelopmentCards() {
        return developmentCards;
    }

    public void setDevelopmentCards(ArrayList<String> developmentCards) {
        this.developmentCards = developmentCards;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getWood() {
        return wood;
    }

    public void setWood(int wood) {
        this.wood = wood;
    }

    public int getWheat() {
        return wheat;
    }

    public void setWheat(int wheat) {
        this.wheat = wheat;
    }

    public int getStone() {
        return stone;
    }

    public void setStone(int stone) {
        this.stone = stone;
    }

    public int getSheep() {
        return sheep;
    }

    public void setSheep(int sheep) {
        this.sheep = sheep;
    }

    public int getBrick() {
        return brick;
    }

    public void setBrick(int brick) {
        this.brick = brick;
    }

    public int getVictoryPoints() {
        return victoryPoints;
    }

    public void setVictoryPoints(int victoryPoints) {
        this.victoryPoints = victoryPoints;
    }

    public int getDevelopmentCardCount() {
        return developmentCardCount;
    }

    public void setDevelopmentCardCount(int developmentCardCount) {
        this.developmentCardCount = developmentCardCount;
    }

    public ArrayList<Building> getBuildings() {
        return this.buildings;
    }

    public void setTotalBuildings(ArrayList<Building> buildings) {
        this.buildings = buildings;
    }

    @Override
    public String toString() {
        return "Player: " + "\n" +
                "Development Cards: " + developmentCards.toString() + "\n" +
                "Buildings: " + buildings.toString() + "\n" +
                "Username: '" + username + "\n" +
                "Wood: " + wood + "\n" +
                "Wheat: " + wheat + "\n" +
                "Stone: " + stone + "\n" +
                "Sheep: " + sheep + "\n" +
                "Brick: " + brick + "\n" +
                "Victory Points: " + victoryPoints + "\n" +
                "Development Cards: " + developmentCardCount;
    }
}
