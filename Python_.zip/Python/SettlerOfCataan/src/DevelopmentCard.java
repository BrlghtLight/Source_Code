import java.util.ArrayList;
import java.util.Random;

////
////
//  Development Card class will host the deck of cards
//  In the Game class we will draw from it and operate the card effect
//  Based on the String keyword with elif statements likely
////
////

public class DevelopmentCard {
    ArrayList<String> deck = new ArrayList<String>();
    Random generator = new Random();

    public DevelopmentCard() {
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Soldier");
        deck.add("Victory Point");
        deck.add("Victory Point");
        deck.add("Victory Point");
        deck.add("Victory Point");
        deck.add("Victory Point");
        deck.add("Monopoly");
        deck.add("Monopoly");
        deck.add("Year of Plenty");
        deck.add("Year of Plenty");
        deck.add("Road Building");
        deck.add("Road Building");
    }

    public String drawCard() {
        int random = 0;
        while(random == 0) {
            random = generator.nextInt(26);
        }
        return this.deck.get(random);
    }

    public String toString() {
        return "Deck:" + "\n" +
                this.deck.toString();
    }
}
