import java.util.*;

public class SettlersGame {
    public static void main(String[] args) {
        //operate game
        final String GAME_START = "1";
        String playerCommand = "";
        Scanner console = new Scanner(System.in);

        //game state flags
        boolean gameFlag = true;
        boolean playerOneFlag = true;
        boolean playerTwoFlag = false;
        boolean playerThreeFlag = false;
        boolean playerFourFlag = false;

        //player instance variables
        ArrayList<String> developmentCards = new ArrayList<String>();
        ArrayList<Building> buildings = new ArrayList<Building>();
        String username;
        int wood;
        int wheat;
        int stone;
        int sheep;
        int brick;
        int victoryPoints;
        int developmentCardCount;

        //building instance variables

        //tile instance variables

        //dice instance variables

        //game board instance variables

        //initialize game

        ////////////////
        //
        //
        //create players
        //create buildings
        DevelopmentCard developmentCardDeck = new DevelopmentCard();
        //create board
        //create tiles
        //etc......
        //
        //
        ////////////////

        //begin players' turns
        while (gameFlag) {
            switch (GAME_START) {
                //player 1 turn
                case "1":
                    while (playerOneFlag) {
                        switch (playerCommand) {
                            case "0":
                                playerOneFlag = false;
                                break;
                            default:
                                System.out.println("Invalid Command");
                        }
                    }
                    //player 2 turn
                case "2":
                    while (playerTwoFlag) {
                        switch (playerCommand) {
                            case "0":
                                playerTwoFlag = false;
                                break;
                            default:
                                System.out.println("Invalid Command");
                        }
                    }
                    //player 3 turn
                case "3":
                    while (playerThreeFlag) {
                        switch (playerCommand) {
                            case "0":
                                playerTwoFlag = false;
                                break;
                            default:
                                System.out.println("Invalid Command");
                        }
                    }
                    //player 4 turn
                case "4":
                    while (playerFourFlag) {
                        switch (playerCommand) {
                            case "0":
                                playerFourFlag = false;
                                break;
                            default:
                                System.out.println("Invalid Command");
                        }
                    }
                default:
                    System.out.println("~Incorrect Command");
            }//end game turns
        }//end game
    }//end main
}//end class
