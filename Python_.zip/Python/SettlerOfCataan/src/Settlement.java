public class Settlement extends Building {
    private String name;
    private int victoryPoints;
    public Settlement(String name, int victoryPoints) {
        this.name = "City";
        this.victoryPoints = 1;
    }
}
