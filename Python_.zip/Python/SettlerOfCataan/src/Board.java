import java.util.ArrayList;

/*
 */

public class Board {

    // array of Tile objects
    ArrayList<Tile> tiles = new ArrayList<>();

    public Board() {

        // add one Desert
        tiles.add(new Tile("Desert"));

        // add four of Field, Forest, and Pasture
        for (int i = 0; i < 4; i++) {
            tiles.add(new Tile("Field"));
            tiles.add(new Tile("Forest"));
            tiles.add(new Tile("Pasture"));
        }

        // add three of Mountains and Hills
        for (int i = 0; i < 3; i++) {
            tiles.add(new Tile("Mountains"));
            tiles.add(new Tile("Hills"));
        }

        // add nine of Harbor
        for (int i = 0; i < 9; i++) {
            tiles.add(new Tile("Harbor"));
        }

    }

    // assigns tiles to the board
    public void setupBoard() {

    }


}