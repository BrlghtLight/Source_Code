import java.util.Random;

public class Dice {
    private int roll;
    Random diceRoller = new Random();

    public Dice(int roll, Random diceRoller) {
        this.roll = roll;
        this.diceRoller = diceRoller;
    }

    public int rollDice() {
        //make sure 0 is never sent back
        while(roll == 0) {
            this.roll = diceRoller.nextInt(13);
        }
        return this.roll;
    }
}
