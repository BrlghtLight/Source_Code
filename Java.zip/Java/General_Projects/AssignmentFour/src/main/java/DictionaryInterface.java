import java.io.IOException;

public interface DictionaryInterface {
	/**
	 *Adds a dictionary object to a provided data structure 
	 *
	 *@ensures a new object is added to BST, HashMap, or ArrayList
	 *@param DictionaryEntry entry
	 */
	public void addEntry(DictionaryEntry entry);
	
	/**
	 *Removes an entry from a provided data structure
	 *Will not save changes to output file
	 *
	 *@param String name
	 *@return DictionaryEntry removedEntry
	 *@throws Exception 
	 */
	public DictionaryEntry removeEntry(String name) throws Exception;
	
	/**
	 *Searches for an entry by name
	 *and returns the object
	 *
	 * @param String name
	 * @return DictionaryEntry searchedEntry
	 */
	public DictionaryEntry findEntry(String name) throws Exception;
	
	/**
	 *Saves any changes made by the user and 
	 *creates an outfile
	 *
	 *@ensures changes during runtime are appended
	 *@throws IOException  
	 */
	public void save() throws IOException;
	}