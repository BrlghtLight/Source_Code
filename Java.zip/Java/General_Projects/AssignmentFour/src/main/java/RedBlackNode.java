
public class RedBlackNode {

    /* Class Node */

    RedBlackNode left, right;
    int element;
    int color;
    DictionaryEntry subElement = null;

    /* Constructor */
    public RedBlackNode(int theElement) {
        this(theElement, null, null, null);
    }

    /* Constructor */
    public RedBlackNode(int theElement, DictionaryEntry subElement) {
        this(theElement, null, null, subElement);
    }
    
    /* Constructor */
    public RedBlackNode(int theElement, RedBlackNode lt, RedBlackNode rt, DictionaryEntry subElement) {
        left = lt;
        right = rt;
        element = theElement;
        color = 1;
        this.subElement = subElement;
    }
    
    public DictionaryEntry getDictionaryEntry() {
	return subElement;
    }
}
