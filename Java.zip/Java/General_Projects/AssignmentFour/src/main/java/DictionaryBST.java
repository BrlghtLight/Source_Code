import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.TreeMap;
  
public class DictionaryBST implements DictionaryInterface{

	TreeMap<String,DictionaryEntry > dictionaryTree = new TreeMap<String, DictionaryEntry>();


	@Override
	public void addEntry(DictionaryEntry entry) {
		dictionaryTree.put(entry.getName(), entry);
    }		

	@Override
	public DictionaryEntry removeEntry(String name) {
		return dictionaryTree.remove(name);
	}

	@Override
	public DictionaryEntry findEntry(String name) {
		return dictionaryTree.get(name);
	}
	
	@Override
	public void save() throws IOException {
		PrintWriter outFile = createFileOutputObject("chatdictionary.txt");
		for(Map.Entry<String,DictionaryEntry> m : dictionaryTree.entrySet()){
			if(m.getKey().length() > 0) {
            outFile.println(m.getKey()+" "+m.getValue().getDescription());
			}
		}	
		  outFile.close();
	}

	public PrintWriter createFileOutputObject(String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName);
		PrintWriter outFile = new PrintWriter(fw);
		return outFile;
	}
}