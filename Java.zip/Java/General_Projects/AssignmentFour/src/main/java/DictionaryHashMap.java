import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class DictionaryHashMap implements DictionaryInterface {

	HashMap<String, DictionaryEntry> dictionaryMap = new HashMap<String, DictionaryEntry>();
	
	@Override
	public void addEntry(DictionaryEntry entry) {
		dictionaryMap.put( entry.getName(),entry);
	}

	@Override
	public DictionaryEntry removeEntry(String name) {
		return dictionaryMap.remove(name);
	}

	@Override
	public DictionaryEntry findEntry(String name) {
		return dictionaryMap.get(name);
	}

	public void save() throws IOException {
		PrintWriter outFile = createFileOutputObject("chatdictionary.txt");
		        for(Map.Entry<String,DictionaryEntry> m : dictionaryMap.entrySet()){
		        	if(m.getKey().length() > 0) {
		            outFile.println(m.getKey()+" "+m.getValue().getDescription());
		        	}
		        }
		      outFile.close();
	}
	public PrintWriter createFileOutputObject(String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName);
		PrintWriter outFile = new PrintWriter(fw);
		return outFile;
	}

}
