import java.io.*;
import java.util.ArrayList;

public class DictionaryArrayList extends ArrayList implements DictionaryInterface {

    ArrayList<DictionaryEntry> dictionaryList = new ArrayList<>();
	
	public void addEntry(DictionaryEntry entry) {
		dictionaryList.add(entry);
	}

	@Override
	public DictionaryEntry removeEntry(String name) throws Exception {
		for (int n = 0; n < dictionaryList.size(); n++) {
			if (dictionaryList.get(n).getName().equals(name)) {
				return dictionaryList.remove(n);
			}
		}
		throw new Exception("Unable to find record!");
	}

	@Override
	public DictionaryEntry findEntry(String name) throws Exception {
		for (int n = 0; n < dictionaryList.size(); n++) {
			if (dictionaryList.get(n).getName().equals(name)) {
				System.out.println("Record " + dictionaryList.get(n).getDescription() + " was found successfully.");
				return dictionaryList.get(n);
			}
		}
		throw new Exception("Unable to find record!");
	}

	public void save() throws IOException {
		PrintWriter fileWriter = createFileOutputObject("chatdictionary.txt");
		for(int n = 0; n<dictionaryList.size();n++) {
			fileWriter.printf("%s %n",  dictionaryList.get(n));
		}
	}	
public  PrintWriter createFileOutputObject(String fileName) throws IOException{
		
		FileWriter fw = new FileWriter(fileName);
		PrintWriter outFile = new PrintWriter( fw );
		
		return outFile;
	}
}
