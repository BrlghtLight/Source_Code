import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DictionaryClient {

	public static void main(String[] args) throws Exception {

		Scanner console = new Scanner(System.in);

		// variables
		String mainInput = null;
		String BSTInput = null;
		String hashMapInput = null;
		String arrayListInput = null;

		Boolean mainFlag = true;
		Boolean BSTFlag = true;
		Boolean hashMapFlag = true;
		Boolean arrayListFlag = true;
		List<DictionaryEntry> masterList = importTextToObject();
		// declare arrayList
		DictionaryArrayList dictionaryList = new DictionaryArrayList();
		// declare hashMap
		DictionaryHashMap dictionaryHashMap = new DictionaryHashMap();

		// declare Binary Search Tree
		DictionaryBST dictionaryBST = new DictionaryBST();

		// populate each data structure
		for (int n = 0; n < masterList.size(); n++) {
			dictionaryHashMap.addEntry(masterList.get(n));
			dictionaryList.addEntry(masterList.get(n));
			dictionaryBST.addEntry(masterList.get(n));
		}

		// display UI
		while (mainFlag) {

			// display menu options
			menu();

			// collect user input
			System.out.print("\n|" + "\n|Enter a Command: ");
			mainInput = console.next();

			// reset inner menu flags
			// to allow reuse
			BSTFlag = true;
			hashMapFlag = true;
			arrayListFlag = true;

			switch (mainInput) {

			// Binary Search Tree Menu
			case "BST":
				while (BSTFlag) {
					BSTMenu();

					// collect user input
					System.out.print("\n|" + "\n|Enter a Command: ");
					BSTInput = console.next();

					switch (BSTInput) {
					case "Add":
						console.nextLine();
						try {
							System.out.print("\n\nPlease enter a name to be added to the dictionary: ");
							String name = console.nextLine();
							System.out.println();
							System.out.print(
									"\n\nPlease enter the description to be attached to the name and added to the dictionary: ");
							String description = console.nextLine();
							DictionaryEntry newEntry = new DictionaryEntry(name, description);
							dictionaryBST.addEntry(newEntry);
							System.out.println("The name " + name + " with description " + description
									+ " was sucessfully added to your dictionary");
						} catch (Exception e) {
							System.out.println(
									"Invalid entry, please type any character in and press enter to continue.");
							console.nextLine();
						}
						break;

					case "Remove":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to remove from the list: " + "\n\n");
							String nameToRemove = console.next();
							System.out.println("Entry " + dictionaryBST.findEntry(nameToRemove).getName()
									+ " with description " + dictionaryBST.findEntry(nameToRemove).getDescription()
									+ " was removed successfully.");
							
						} catch (Exception e) {
							System.out.println(
									"Entry not found, please type any character in and press enter to continue.");
							console.nextLine();
						}
						break;
					case "Search":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to search for inside the list: ");
							String searchListInput = console.nextLine();
							System.out.println("Entry " + dictionaryBST.findEntry(searchListInput).getName()
									+ " with description "
									+ dictionaryBST.findEntry(searchListInput).getDescription()
									+ " was found successfully.");
						} catch (Exception e) {
							System.out.println("Please try to search again. Press any key to continue.");
							console.nextLine();
						}
						break;
					case "Save":
						dictionaryBST.save();
						
						System.out.println(
								"The TreeMap has been successfully saved to a text file named chatdictionary.txt");
						break;
					case "BenchMark":
						System.out.println(
								"The following is a benchmark of the addEntry method for the TreeMap of dictionary.");
						benchmarkAlgorithmAdd(dictionaryBST);
						System.out.println(
								"The following is a benchmark of the removeEntry method for the TreeMap of dictionary.");
						benchmarkAlgorithmRemove(dictionaryBST);
						break;

					case "Exit":
						BSTFlag = false;
						break;

					default:
						System.out.println("|" + "\n" + "|Invalid Command, Try again" + "\n" + "|");
					}// end BST switch
				} // end BST menu
				break;

			// Hash Map Menu
			case "HashMap":
				while (hashMapFlag) {
					HashMapMenu();

					// collect user input
					System.out.print("\n|" + "\n|Enter a Command: ");
					hashMapInput = console.next();

					switch (hashMapInput) {
					case "Add":
						console.nextLine();
						try {
							System.out.print("\n\nPlease enter a name to be added to the dictionary: ");
							String name = console.nextLine();
							System.out.println();
							System.out.print(
									"\n\nPlease enter the description to be attached to the name and added to the dictionary: ");
							String description = console.nextLine();
							DictionaryEntry newEntry = new DictionaryEntry(name, description);
							dictionaryHashMap.addEntry(newEntry);
							System.out.println("The name " + name + " with description " + description
									+ " was sucessfully added to your dictionary");
						} catch (Exception e) {
							System.out.println(
									"Invalid entry, please type any character in and press enter to continue.");
							console.nextLine();
						}
						break;

					case "Remove":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to remove from the list: " + "\n\n");
							String nameToRemove = console.next();
							System.out.println("Entry " + dictionaryHashMap.findEntry(nameToRemove).getName()
									+ " with description " + dictionaryHashMap.findEntry(nameToRemove).getDescription()
									+ " was removed successfully.");
							dictionaryHashMap.removeEntry(nameToRemove);
						break;	
						} catch (Exception e) {
							System.out.println(
									"Entry not found, please type any character in and press enter to continue.");
							console.nextLine();
						}
						//System.out.println(dictionaryHashMap.getDictionaryMap().toString());
						break;

					case "Search":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to search for inside the list: " + "\n\n");
							String searchListInput = console.nextLine();
							dictionaryHashMap.findEntry(searchListInput);
							System.out.println("Entry " + dictionaryHashMap.findEntry(searchListInput).getName()
									+ " with description "
									+ dictionaryHashMap.findEntry(searchListInput).getDescription()
									+ " was found successfully.");
						} catch (Exception e) {
							System.out.println("Entry not found, please try to search again. Press any key to continue.");
							console.nextLine();
						}
						break;

					case "Save":
						dictionaryHashMap.save();
						System.out.println(
								"The HashMap has been successfully saved to a text file named chatdictionary.txt");
						break;
						
					case "BenchMark":
						System.out.println(
								"The following is a benchmark of the addEntry method for the HashMap of dictionary.");
						benchmarkAlgorithmAdd(dictionaryHashMap);
						
						System.out.println(
								"The following is a benchmark of the removeEntry method for the HashMap of dictionary.");
						benchmarkAlgorithmRemove(dictionaryHashMap);
						
						break;


					case "Exit":
						hashMapFlag = false;
						break;

					default:
						System.out.println("|" + "\n" + "|Invalid Command, Try again" + "\n" + "|");

					}// end HashMap switch
				} // end HashMap menu
				break;

			// Array List Menu
			case "ArrayList":
				while (arrayListFlag) {
					ArrayListMenu();

					// collect user input
					System.out.print("\n|" + "\n|Enter a Command: ");
					arrayListInput = console.next();

					switch (arrayListInput) {
					case "Add":
						console.nextLine();
						try {
							System.out.print("\n\nPlease enter a name to be added to the dictionary: ");
							String name = console.nextLine();
							System.out.println();
							System.out.print(
									"\n\nPlease enter the description to be attached to the name and added to the dictionary: ");
							String description = console.nextLine();
							DictionaryEntry newEntry = new DictionaryEntry(name, description);
							dictionaryList.addEntry(newEntry);
							System.out.println("The name " + name + " with description " + description
									+ " was sucessfully added to your dictionary");
						} catch (Exception e) {
							System.out.println(
									"Invalid entry, please type any character in and press enter to continue.");
							console.nextLine();
						}
						break;

					case "Remove":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to remove from the list: " + "\n\n");
							String nameToRemove = console.next();
							DictionaryEntry temp = dictionaryList.removeEntry(nameToRemove);
                                                        System.out.print("" + temp + "\nwas removed");
						} catch (Exception e) {
							System.out.println(
									"Entry not found, please type any character in and press enter to continue.");
							console.nextLine();
						}
						break;

					case "Search":
						console.nextLine();
						try {
							System.out.println("\n\nPlease enter a name to search for inside the list: " + "\n\n");
							String searchListInput = console.nextLine();
							dictionaryList.findEntry(searchListInput);
						} catch (Exception e) {
							System.out.println("Please try to search again. Press any key to continue.");
							console.nextLine();
						}

						break;
					case "Save":
						dictionaryList.save();
						System.out.println(
								"The ArrayList has been successfully saved to a text file named chatdictionary.txt");
						break;
						
					case "BenchMark":
						System.out.println(
								"The following is a benchmark of the addEntry method for the List of dictionary.");
						benchmarkAlgorithmAdd(dictionaryList);
						System.out.println(
								"The following is a benchmark of the removeEntry method for the List of dictionary.");
						benchmarkAlgorithmRemove(dictionaryList);
						break;

					case "Exit":
						arrayListFlag = false;
						break;

					default:
						System.out.println("|" + "\n" + "|Invalid Command, Try again" + "\n" + "|");
					}// end ArrayList switch
				} // end ArrayList menu
				break;

			case "Exit":
				System.out.println("|" + "\n" + "|Shutting Down..." + "\n" + "|");
				mainFlag = false;
				break;

			default:
				System.out.println("|" + "\n" + "|Invalid Command, Try again" + "\n" + "|");

			}// end switch
		} // end menu loop
	}// end main

	public static void benchmarkAlgorithmAdd(DictionaryInterface dictionaryInterface) throws Exception {
		Integer[] loopSizes = new Integer[] { 1, 10, 100, 1000, 10000, 1000000, 10000000, 100000000 };
		String name = "JK";
		String description = "Just Kidding";
		DictionaryEntry newAdd = new DictionaryEntry(name, description);
		long startTime = System.nanoTime();
		for (Integer loopSize : loopSizes) {
			for (int n = 0; n < loopSize; n++) {
				dictionaryInterface.addEntry(newAdd);
			}
			long totalTime = System.nanoTime() - startTime;
			System.out.println(
					"It took " + totalTime + " nano seconds to run over " + loopSize + " addEntry operations.");
		}
	}
	public static void benchmarkAlgorithmRemove(DictionaryInterface dictionaryInterface) throws Exception {
		Integer[] loopSizes = new Integer[] { 1, 10, 100, 1000, 10000, 1000000, 10000000, 100000000 };
		String name = "JK";
		long startTime = System.nanoTime();
		for (Integer loopSize : loopSizes) {
			for (int n = 0; n < loopSize; n++) {
				dictionaryInterface.removeEntry(name);
			}
			long totalTime = System.nanoTime() - startTime;
			System.out.println(
					"It took " + totalTime + " nano seconds to run over " + loopSize + " removeEntry operations.");
		}
	}
	public static List<DictionaryEntry> importTextToObject() throws FileNotFoundException {
		List<DictionaryEntry> dl = new ArrayList<DictionaryEntry>();
		Scanner inFile = new Scanner(new FileReader("chatdictionary.txt"));
		inFile.nextLine();

		while (inFile.hasNextLine()) {
			String temp = inFile.nextLine().replaceAll("[<>]", "");
			temp.trim();

			String name = temp.substring(0, temp.indexOf(' '));
			String description = temp.substring(temp.indexOf(' ') + 1);

			DictionaryEntry dictionaryEntry = new DictionaryEntry(name, description);
			dl.add(dictionaryEntry);
		}
		inFile.close();
		return dl;
	}// end importTextToObject method

	// Output Main Menu Method
    public static void menu() {
        System.out.print("_________________________________________" + "\n"
                + "|                                       |" + "\n"
                + "| Dictionary Client                     |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "| BST       --- Binary Search Tree Menu |" + "\n"
                + "| HashMap   --- Hash Map Menu           |" + "\n"
                + "| ArrayList --- Array List Menu         |" + "\n"
                + "|                                       |" + "\n"
                + "| Exit      --- End Program             |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "|_______________________________________|");
    }// end Menu

    //Output BST Menu Method
    public static void BSTMenu() {
        System.out.print("_________________________________________" + "\n"
                + "|                                       |" + "\n"
                + "| Dictionary Binary Search Tree         |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "| Add       --- Add a new entry         |" + "\n"
                + "| Remove    --- Remove an existing entry|" + "\n"
                + "| Search    --- Search for an entry     |" + "\n"
                + "| Save      --- Save changes            |" + "\n"
                + "| BenchMark --- Measure efficiency      |" + "\n"
                + "| Exit      --- Return to Main Menu     |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "|_______________________________________|"
        );
    }//end BSTMenu

    //Output Hash Map Menu Method
    public static void HashMapMenu() {
        System.out.print("_________________________________________" + "\n"
                + "|                                       |" + "\n"
                + "| Dictionary Hash Map                   |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "| Add       --- Add a new entry         |" + "\n"
                + "| Remove    --- Remove an existing entry|" + "\n"
                + "| Search    --- Search for an entry     |" + "\n"
                + "| Save      --- Save changes            |" + "\n"
                + "| BenchMark --- Measure efficiency      |" + "\n"
                + "| Exit      --- Return to Main Menu     |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "|_______________________________________|"
        );
    }//end HashMapMenu

    //Output Array List Menu Method
    public static void ArrayListMenu() {
        System.out.print("_________________________________________" + "\n"
                + "|                                       |" + "\n"
                + "| Dictionary Array List                 |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "| Add       --- Add a new entry         |" + "\n"
                + "| Remove    --- Remove an existing entry|" + "\n"
                + "| Search    --- Search for an entry     |" + "\n"
                + "| Save      --- Save changes            |" + "\n"
                + "| BenchMark --- Measure efficiency      |" + "\n"
                + "| Exit      --- Return to Main Menu     |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|" + "\n"
                + "|_______________________________________|"
        );
    }//end ArrayListMenu
}// end class