/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Class definition for User
 */

import java.util.*;
public class User implements UserInterface{ 
    static final int USER_MAX_LIST_SIZE = 10;
	
	//data members
    Node head;
	private String username;
	private String firstName;
	private String lastName;
	LinkedList<Item> itemList = new LinkedList();
	
	//default constructor
	public User() {
		
	}//end default constructor
	
	//overloaded constructor
	public User(String username, String firstName, String lastName, LinkedList itemList) {
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.itemList = itemList;
	}//end overloaded constructor
	
	//getters and setters
    @Override
	public String getUsername() {
		return username;
	}
    @Override
	public String getFirstName() {
		return firstName;
	}
    @Override
	public String getLastName() {
		return lastName;
	}
	
    @Override
	public void setUsername(String username) {
		this.username = username;
	}
    @Override
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
    @Override
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
    @Override
	public void bidOnItem(Double bid, Item item) {
		Date date = new Date();
		if(itemList.size() < USER_MAX_LIST_SIZE) {
			if(bid > item.getHighBid()) {
				if(bid >= item.getBuyNowPrice()) {
                                        itemList.add((itemList.size()),item);
					System.out.println("Congratulations, you purchased " + item.getName());
					item.setDateBidComplete(date.toString());
				}else {
					item.setHighBid(bid);
					System.out.println("The new high bid is " + item.getHighBid());
				}
			}else {
				System.out.println("Please enter a number higher than " + item.getHighBid());
			}
		}else {
			System.out.println("You cannot purchase any more items at this time");
		}
	}
        
    @Override
	public void getItemList(LinkedList list) {
        int index = 1;
        while(index < list.size()) {
            System.out.println("" + list.get(index));
            index++;
        }
    }
    
    public static void printList(LinkedList<Item> list) 
    { 
        Node currNode = list.head; 
   
        System.out.print("LinkedList: "); 
   
        // Traverse through the LinkedList 
        while (currNode != null) { 
            // Print the data at current node 
            System.out.print(currNode.data + " "); 
   
            // Go to next node 
            currNode = currNode.next; 
        } 
    } 
   
	
	@Override
	public String toString() {
		return String.format("%s, %s, %s",
						  username, 
						  firstName,
						  lastName);
	}//end toString


    
	
}//end User class
