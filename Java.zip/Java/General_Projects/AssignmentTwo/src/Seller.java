/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Class definition for Seller
 */
import java.util.*;
public class Seller extends User implements SellerInterface{
    static final int SELLER_MAX_LIST_SIZE = 20;
		//data members
		public LinkedList<Item> sellList = new LinkedList();
		
		//default constructor
		public Seller() {
		}//end default constructor
		
		//overloaded constructor
		public Seller(String username, String firstName, String lastName, LinkedList itemList, LinkedList sellList) {
			super(username, firstName, lastName, itemList);
			this.sellList = sellList;
			
		}//end overloaded constructor
		
		
		public void addItemToSell(LinkedList sellList, Item item) {
			if(sellList.size() < SELLER_MAX_LIST_SIZE) {
				sellList.add((sellList.size()), item);
			}else {
				System.out.println("You already have 20 Items on your sell list and cannot add more at this time.");
			}
		}
		
		@Override
		public String toString() {
			return super.toString();
		}//end toString
}
