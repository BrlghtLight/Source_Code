/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Interface for User
 */
import java.util.*;
public interface UserInterface {
		//getters
		public String getUsername();
		public String getFirstName();
		public String getLastName();
		
		//setters
		public void setUsername(String username);
		public void setFirstName(String firstName);
		public void setLastName(String lastName);
		
		//methods
		public void bidOnItem(Double bid, Item item);
		public void getItemList(LinkedList list);
                @Override
		public String toString();
}
