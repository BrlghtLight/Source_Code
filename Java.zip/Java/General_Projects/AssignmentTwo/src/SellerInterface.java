/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Interface definition for Seller
 */
import java.util.*;
public interface SellerInterface extends UserInterface {
		//getters
		public void addItemToSell(LinkedList sellList, Item item);
			
                @Override
		public String toString();
}
