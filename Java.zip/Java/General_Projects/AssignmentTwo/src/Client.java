import java.util.*;

public class Client {
	public static void main(String[] args) {
		
		Scanner console = new Scanner(System.in);
		String fName;
		String lName;
		String uName;
                LinkedList<Item> buyList = new LinkedList();
		LinkedList<Item> sellList = new LinkedList();
                
                //establish a user object and create
		System.out.println("Please enter a first name: ");
		fName =  console.next();
		System.out.println("Please enter a last name: ");
		lName =  console.next();
		System.out.println("Please enter a username: ");
		uName =  console.next();
		
		User user1 = new User(uName, fName, lName, buyList);
                
                //hardcode a seller object
                Seller seller1 = new Seller("uRnotTheFather", "Jerry", "Springer", buyList, sellList);
                //print each object to show they are there
                System.out.println(user1);
                System.out.println(seller1);
                
                //create Items for seller to sell and user to buy
                Item dogBone = new Item("Dog Bone","They like to chew on me.",4.33,7.22,"Rochester","");
                Item catTree = new Item("Cat Tree","They like to climb on me.",32.50,47.99,"Pheonix","");
                Item dogBed = new Item("Dog Bed","They like to sleep on me.",14.80,29.99,"Harpers Ferry","");
                
                //add items to sellers list until limit is reached
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                seller1.addItemToSell(sellList, dogBed);
                seller1.addItemToSell(sellList, dogBone);
                seller1.addItemToSell(sellList, catTree);
                
                
                
                //have the user enter a bid on an item
                //if buy it now price is entered, the method bidOnItem will add the item to the users buyList                
                
                Double bid;
                System.out.println("Enter a bid higher than " + dogBone.getHighBid() + " for the Dog Bone; Enter " + dogBone.getBuyNowPrice() + " to buy it now: ");
                bid = console.nextDouble();//enter 7.22 here
                user1.bidOnItem(bid, dogBone);
                
                //if a bid higher than current bid but lower than buyItNow price will change the current bid
                System.out.println("Enter a bid higher than " + catTree.getHighBid() + " for the Cat Tree; Enter " + catTree.getBuyNowPrice() + " to buy it now: ");
                bid = console.nextDouble();//enter anything from 32.50 to 47.99 here
                user1.bidOnItem(bid, catTree);
                //an error message will print if a price is entered that is too low
                System.out.println("Enter a bid higher than "+ dogBed.getHighBid() +" for the Dog Bed; Enter " + dogBed.getBuyNowPrice() + " to buy it now: ");
                bid = console.nextDouble();//enter a nuber less than 14.80 here
                user1.bidOnItem(bid, dogBed);
                
                for(int i=0;i<10;i++){
                    user1.bidOnItem(7.22, dogBone);
                }
                
               user1.printList(buyList);
             
	}

}
