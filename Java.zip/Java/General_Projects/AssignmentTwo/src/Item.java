/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Class definition for Item
 */
public class Item {
	
	//data members
	private String name;
	private String description;
	private double highBid;
	private double buyNowPrice;
	private String location;
	private String dateBidComplete;
	
	//default constructor
	public Item() {
		
	}
	
	//overloaded constructor
	public Item(String name, String description, double highBid, double buyNowPrice, String location, String dateBidComplete) {
		this.name = name;
		this.description = description;
		this.highBid = highBid;
		this.buyNowPrice = buyNowPrice;
		this.location = location;
		this.dateBidComplete = dateBidComplete;
	}//end overloaded constructor

	//setters and getters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getHighBid() {
		return highBid;
	}

	public void setHighBid(double highBid) {
		this.highBid = highBid;
	}

	public double getBuyNowPrice() {
		return buyNowPrice;
	}

	public void setBuyNowPrice(double buyNowPrice) {
		this.buyNowPrice = buyNowPrice;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDateBidComplete() {
		return dateBidComplete;
	}

	public void setDateBidComplete(String dateBidComplete) {
		this.dateBidComplete = dateBidComplete;
	}
	
	@Override
	public String toString() {
		return String.format("%s, %s, %d, %d, %s, %s",
							  name,
							  description,
							  highBid,
							  buyNowPrice,
							  location,
							  dateBidComplete);
	}
	
	
}//end item class
