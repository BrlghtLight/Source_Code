/*
 *Author: Marcus Walbridge, Jon Comisky
 *Date: 09/12/2019
 *Assignment: Assignment #2
 *Description: Interface definition for Item
 */
public interface ItemInterface {
	
	public String getName();
	public void setName(String name);

	public String getDescription();
	public void setDescription(String description);

	public double getHighBid();
	public void setHighBid(double highBid);

	public double getBuyNowPrice();
	public void setBuyNowPrice(double buyNowPrice);

	public String getLocation();
	public void setLocation(String location);

	public String getDateBidComplete();
	public void setDateBidComplete(String dateBidComplete);

	public String toString();
}
