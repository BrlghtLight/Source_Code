/*
 Author: Marcus Walbridge
 Date: 10/11/2017
 Program: RetailerEnhanced.java
 Description: Enhanced version, loop order form until user exits using flag control.
              Outputs total cost of entire order && total cost of each product.
*/

import java.util.Scanner;

public class RetailerEnhanced
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
          
          //variables
              
      double totalCost, orderCost1 = 0, orderCost2 = 0, 
             orderCost3 = 0, orderCost4 = 0, orderCost5 = 0, orderCost,
             totalCost1 = 0, totalCost2 = 0, totalCost3 = 0, totalCost4 = 0, totalCost5 = 0;
      
      int quantity, productNumber;      
      boolean flag = true;
      
          //constants
          
      final double COST_1 = 12.98, COST_2 = 14.50, 
                   COST_3 = 19.98, COST_4 = 14.49, 
                   COST_5 = 16.87;    
         
      totalCost = 0;
      orderCost = 0;     
          
      while(flag)
      {
         System.out.println();
         System.out.println();
         
         System.out.println("*************************************");
         System.out.println("Welcome to Your Friendly Online Store");
         System.out.println("*************************************");
         
         System.out.println("Enter desired product(1-5) or 0 to exit");
      
         System.out.println("\n" +
                            "1 --- Product 1 $" + COST_1 + "\n" +
                            "2 --- Product 2 $" + COST_2 + "\n" +
                            "3 --- Product 3 $" + COST_3 + "\n" +
                            "4 --- Product 4 $" + COST_4 + "\n" +
                            "5 --- Product 5 $" + COST_5 + "\n" +
                            "0 --- Exit");
         
         System.out.println();
         
         System.out.print("Enter a number ");
         productNumber = console.nextInt();
         
         switch(productNumber)
         {
            case 1:
            
               System.out.print("Desired quantity of product #1: ");
               quantity = console.nextInt();              
               if(quantity > 0)
               {
                  orderCost1 = quantity * COST_1;
                  System.out.printf("%nCost: $%.2f", orderCost1);       
               }
               else
               {
                  System.out.println();
                  System.out.println("Invalid quantity, try again.");
               }
               break;
             
            case 2:
            
               System.out.print("Desired quantity of product #2: ");
               quantity = console.nextInt();
               if(quantity > 0)
               {
                  orderCost2 = quantity * COST_2;
                  System.out.printf("%nCost: $%.2f", orderCost2);  
               }
               else
               {
                  System.out.println();
                  System.out.println("Invalid quantity, try again.");
               }
               break;
         
            case 3:
            
               System.out.print("Desired quantity of product #3: ");
               quantity = console.nextInt();
               if(quantity > 0)
               {
                  orderCost3 = quantity * COST_3;
                  System.out.printf("%nCost: $%.2f", orderCost3);              
               }
               else
               {
                  System.out.println();
                  System.out.println("Invalid quantity, try again.");
               }
               break;
         
            case 4:
            
               System.out.print("Desired quantity of product #4: ");
               quantity = console.nextInt();
               if(quantity > 0)
               {
                  orderCost4 = quantity * COST_4;
                  System.out.printf("%nCost: $%.2f", orderCost4);
               }
               else
               {
                  System.out.println("Invalid quantity, try again.");
               }
               break;
         
            case 5:
            
               System.out.print("Desired quantity of product #5: ");
               quantity = console.nextInt();
               if(quantity > 0)
               {
                  orderCost5 = quantity * COST_5;
                  System.out.printf("%nCost: $%.2f", orderCost5);
               }
               else
               {
                  System.out.println();
                  System.out.println("Invalid quantity, try again.");
               }
               break;
               
            case 0: 
               
               flag = false;   
               break;
         
            default:
               
               System.out.println();
               System.out.println("Invalid product");
              
               break;
             
         }//end switch  
         
         orderCost = orderCost1 + orderCost2 + orderCost3 + orderCost4 + orderCost5;
         
         totalCost1 += orderCost1; 
         totalCost2 += orderCost2; 
         totalCost3 += orderCost3;
         totalCost4 += orderCost4; 
         totalCost5 += orderCost5;
         totalCost += orderCost;
        
         orderCost = 0;
         orderCost1 = 0; orderCost2 = 0; orderCost3 = 0; orderCost4 = 0; orderCost5 = 0;
         
      }//end whileloop     
      
      //output total costs of each desired product
      System.out.println("\n" +
                            "1 --- Product 1 $" + String.format("%.2f", totalCost1) + "\n" +
                            "2 --- Product 2 $" + String.format("%.2f", totalCost2) + "\n" +
                            "3 --- Product 3 $" + String.format("%.2f", totalCost3) + "\n" +
                            "4 --- Product 4 $" + String.format("%.2f", totalCost4) + "\n" +
                            "5 --- Product 5 $" + String.format("%.2f", totalCost5) + "\n" +
                            "0 --- Exit");
                            
      System.out.printf("%nTotal Cost: $%.2f", totalCost);
   
   }//end 
     
}//end