/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Random;
import java.util.Scanner;

public class ArrayProcessing
{
   static final int SIZE = 25; 
   public static void main(String [] args)
   
   { 
      Scanner console = new Scanner(System.in);       
      
         //create a Random object
      Random rand = new Random();
      
         //declare and create an array of SIZE
      int [] myList = new int[SIZE];
      
         //populate array with random numbers
      for(int i = 0; i < myList.length; i++) {
         myList[i] = rand.nextInt(501); //0-500
      }
      
         //call printArray method
      printArray(myList);
      
         //call sumArray method
      System.out.println("\n\nSum = " + sumArray(myList) );
      
         //call index method
      int maxIndex = findIndexOfLargest(myList);
      System.out.println("\nThe largest element " + myList[maxIndex] + 
                         " is at index " + maxIndex + ".");
      
         //call search method
      System.out.print("Enter a key to search: ");
      int key = console.nextInt();
      
      int foundIndex = search( myList, key);
      
      if(foundIndex == -1) {
         System.out.println("\nThe key is not found in the array.");
      }
      else {
         System.out.println("\nThe key is found at the index " + foundIndex + ".");
      }
      
         //call selection method
      selectionSort(myList);
      
         //call print array method
      printArray(myList);
      
   }//end main
   
      //print array method
   public static void printArray(int [] myList) {
      for(int i = 0; i < myList.length; i++) {
         System.out.print(myList[i] + " ");
      }
   }//end print array method
   
      //Sum method
   public static int sumArray(int [] myList) {      
      int sum = 0;     
      for( int i = 0; i < myList.length; i++) {
         sum += myList[i];
      }
      return sum;
   }//end Sum method
   
      //find index of largest val in array
   public static int findIndexOfLargest(int[] myList) {
      int maxIndex = 0;
      for(int i = 1; i < myList.length; i++) {
         
         if(myList[i] > myList[maxIndex]) {
            maxIndex = i;   
         }
         
      }//end for loop
     
      return maxIndex;
   
   }//end max index method
   
      //search method
   public static int search(int [] myList, int key) {
      for(int i = 0; i < myList.length; i++) {
         if(key == myList[i]) {
            return i;
         }
      }   
      return -1;
   }//end search method
   
      //selection swap method
   public static void selectionSort(int [] myList) {
      int minIndex, temp;
      
         //Loop the sorting
      for(int x = 0; x < myList.length - 1; x++) { 
         minIndex = x; //assume index x has smallest value
      
         for(int i = x + 1; i < myList.length; i++) {
            if(myList[i] < myList[minIndex] ) {
               minIndex = i;
            }
         }//end for loop
      
      //swap the smallest element with the first element
      
         temp = myList[x];
         myList[x] = myList[minIndex];
         myList[minIndex] = temp;
         
      } //end of outer loop 
           
   }//end selection method
   
}//end class