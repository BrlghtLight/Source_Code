/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

import javax.swing.JOptionPane;

public class HowtoFormat
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      int id = 234589;
      String title = "Computer";
      int number = 250;
      double price = 899.79;
      double discountRate = 12.5; //12.5% 
      
      double total = number * price;
      
      System.out.printf("%nHere are the results: %-8d %-11s %-6d %-8.2f %-5.2f %-4.1f",
                       id, title, number, price, discountRate, total); 
      
      String results = String.format("%nHere are the results: %-8d %-11s %-6d %-8.2f %-5.2f %-4.1f",
                       id, title, number, price, discountRate, total); 
                       
      JOptionPane.showMessageDialog( null, results );
      
      
      
       
   }
   
}