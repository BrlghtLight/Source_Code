/*
     Author: Marcus Walbridge
     Date: 10/23/17
     Program: TwoNumbersEnhanced.java
     Description: Assignment 4's program with do/for loops  !!!Total number square odds!!!
*/
 
import java.util.Scanner;

public class TwoNumbersEnhanced
{
   public static void main(String [] args)
   
   {
      
      Scanner console = new Scanner(System.in);      
      
      //variables
      
      int i, n1, n2, temp, count = 0, sumOfEvens = 0, sumOfSquareOfOdds = 0;
      double average;  
      
      //user input
      
      System.out.print("\nEnter two integers ");
      n1 = console.nextInt();
      n2 = console.nextInt();          
        
      //make sure both n1 && n2 are positive
      
      n1 = Math.abs(n1);
      n2 = Math.abs(n2);
      
      //make sure n1 is less than n2
      
      if( n1 > n2)
      {
         temp = n1;
         n1 = n2;
         n2 = temp;
      }
   
      i = n1;  
      
      System.out.println("Odd integers between " + n1 + " and " + n2 + " are: ");    
      
      do
      {
         if( i % 2 == 1 ) //odds
         {
            System.out.print(i + " "); //odds
            count++;           
         } 
         else
         { 
            // evens
         
            sumOfEvens += i;
         
         }
         if( count % 10 == 0 )
         {
            System.out.println();
         }
        
         i++;
         
      }
      while( i <= n2 );
      
      for(i=n1; i<=n2; i++)
      {
         if(i%2 == 1)
         {
            sumOfSquareOfOdds += (i*i);
         }
      }
      
      System.out.println();
      
      System.out.println("\nSum of even numbers: " + sumOfEvens);
      System.out.println("\nSum of the squares of odd integers: " + sumOfSquareOfOdds);
      
      //Output the alphabet in caps.
      
      char alphabet;
      
      System.out.println();
      
      System.out.print("Uppercase letters are: ");
      
      for(alphabet = 'A'; alphabet <= 'Z'; alphabet++)
      {
         System.out.print(alphabet + " ");
      }
      
      System.out.println();
   
   }
}