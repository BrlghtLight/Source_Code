/*
 Author: Marcus Walbridge
 Date: 9-25-17
 Program: RetailerSwitchSelection.java
 Description: Using switch selection to select desired product 
              and the cost based on quantity.
*/

import java.util.Scanner;

public class RetailerSwitchSelection
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
          
          //variables
              
      double orderCost;
      int quantity1, quantity2, quantity3,
          quantity4, quantity5;
      int productNumber;
      
          //constants
          
      final double COST_1 = 12.98, COST_2 = 14.50, 
                   COST_3 = 19.98, COST_4 = 14.49, 
                   COST_5 = 16.87;    
          
          //input
          
      System.out.print("Enter desired product(1-5): ");
      productNumber = console.nextInt();
          
          //switch
      
      switch(productNumber)
      {
         case 1:
         
            System.out.print("Desired quantity of product #1: ");
            quantity1 = console.nextInt();
           
            orderCost = quantity1 * COST_1;
            System.out.printf("%nCost: $%.2f", orderCost);       
           
            break;
           
         case 2:
         
            System.out.print("Desired quantity of product #2: ");
            quantity2 = console.nextInt();
           
            orderCost = quantity2 * COST_2;
            System.out.printf("%nCost: $%.2f", orderCost);  
            
            break;
       
         case 3:
         
            System.out.print("Desired quantity of product #3: ");
            quantity3 = console.nextInt();
           
            orderCost = quantity3 * COST_3;
            System.out.printf("%nCost: $%.2f", orderCost);
            
            break;
       
         case 4:
         
            System.out.print("Desired quantity of product #4: ");
            quantity4 = console.nextInt();
           
            orderCost = quantity4 * COST_4;
            System.out.printf("%nCost: $%.2f", orderCost);
            
            break;
       
         case 5:
         
            System.out.print("Desired quantity of product #5: ");
            quantity5 = console.nextInt();
           
            orderCost = quantity5 * COST_5;
            System.out.printf("%nCost: $%.2f", orderCost);
            
            break;
       
         default:
         
            System.out.println("Invalid product");
           
            break;
           
      } //end switch       
   }   
}