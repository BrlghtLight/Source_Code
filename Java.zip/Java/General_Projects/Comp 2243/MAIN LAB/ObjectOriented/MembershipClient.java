/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class MembershipClient 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
      
      //variables
      Membership myCard = null; //Membership myCard = new Membership();
      int id, points;
      String name; 
      
      boolean flag = true; 
      int userChoice;
      
      while(flag) {
       
         //print a menu
         System.out.println("\n******************************************");
         System.out.println("\n1 - Issue a membership card");
         System.out.println("2 - Enter the club");
        
         System.out.println("3 - Purchase more points");
         System.out.println("4 - show the card information");
         System.out.println("0 - Exit");
         
         //user choice
         System.out.print("Please make a selection: ");
         userChoice = console.nextInt();
         
         switch(userChoice) {
            case 1:
               
               //collect user information
               System.out.print("Enter member ID: ");
               id = console.nextInt();
               
               System.out.print("Enter member name: ");
               name = console.next();
               
               System.out.print("Enter number of points to purchase: ");
               points = console.nextInt();
               
               //issue the card / create an object of membership
               myCard = new Membership(id, name, points);
               System.out.println("The new membership card is issued.");
               
               break;
         
            case 2:
               
               if(myCard.getNumberOfPoint() > 0) {
               //call the enterClub() method
                  myCard.enterClub();
               
                  System.out.println("Welcome and enjoy your workout");
                  System.out.println("One point has been deducted");
                  System.out.println("\nYou have " + myCard.getNumberOfPoint() + " points remaining");
               }
               else {
                  System.out.println("No points remaining, please purchase more.");
               }
               
               break;
            
            case 3:
            
               System.out.print("How many points to purchase?: ");
               points = console.nextInt();
               
               if(points > 0) {            
                  myCard.purchasePoints(points); //call purchasePoint method
               }
               else {
                  System.out.println("Unable to purchase negative points");
               }
               
               System.out.println("You now have " + myCard.getNumberOfPoint() + " points.");
               break;
            
            case 4:
            
               //print the card info
               System.out.println("Membership Card Information: ");        
               System.out.println("\n" + myCard.toString());
            
               break;
               
            case 0:
            
               System.out.print("Exiting..."); 
               flag = false;
               break;
               
            default: 
               System.out.println("Invalid selection, try again.");
         }//end switch
      
      }//end while
          
   }//end main
   
}//end class
