/*
     Author: Marcus Walbridge
     Date: 11-06-17
     Course: COMP 2243
     Program: RoomCarpetClient.java
     Description: Client program for RoomCarpet class.
                  Collects user input and creates room object.
                  Prints results by calling the toString method.
*/

import java.util.Scanner;

public class RoomCarpetClient 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
      
         //variables
      RoomCarpet newRoom;
      
      double area;
      double costPerSqFt;
      double totalCost;
      double length;
      double width;
      double cost;
      
         //collect room information
      System.out.print("\nEnter the length of the room(Feet): ");
      length = console.nextDouble();
      
      System.out.print("Enter the width of the room(Feet): ");
      width = console.nextDouble();
      
      System.out.print("Enter the cost of the carpet(per square foot): $");
      cost = console.nextDouble();
      
      System.out.println();
      
         //validate the user's input
      if(length < 0) {
         System.out.println("Invalid input, length set to 0");
      }
      if(width < 0) {
         System.out.println("Invalid input, width set to 0");
      }
      if(cost < 0) {
         System.out.println("Invalid input, cost set to $0");
      }
      
      System.out.print("\n*********************************************");
      
         //create the room
      newRoom = new RoomCarpet(length, width, cost);
      System.out.println("\nYour new room has been constructed.");
      
         //calculate area and total cost of carpet
      area = newRoom.roomDimension();
      totalCost = newRoom.totalCost();
      
         //print the room info with toString method
      System.out.println("\nRoom and Carpet information:");
      System.out.println(newRoom.toString());
      
      System.out.println("\nArea of Room: " + String.format("%.2f", area) + " square feet" + "\n" +
                        "Total Cost(Carpet): $" + String.format("%.2f", totalCost) + "\n" +
                        "*********************************************");
       
   }//end main
   
}//end class
