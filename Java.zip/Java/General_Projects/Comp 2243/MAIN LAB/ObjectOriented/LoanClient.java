/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class LoanClient 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
      
      Loan carLoan, mortgageLoan;
      
      String name; 
      double amount, rate, monthlyPayment;
      int years;
      
      //input
      System.out.print("Enter loan name: ");
      name = console.nextLine();
      
      System.out.print("Enter loan amount: $");
      amount = console.nextDouble();
      
      System.out.print("Enter loan annual interest rate: ");
      rate = console.nextDouble();
      
      System.out.print("Enter number of years: ");
      years = console.nextInt();
      
      //create the car loan object by invoking constructor
      carLoan = new Loan(name, amount, rate/12/100, years*12);
   
      //call the method to calculate the monthly payments of the car loan
      monthlyPayment = carLoan.calMonthlyPayment(); 
      
      //print the carLoan object information
      System.out.println("Car Loan Information: ");
      System.out.println( carLoan.toString() );
      System.out.println("Monthly Payment: $" + monthlyPayment);
      
      //change the numOfPayments data member of carLoan object to 5 years
      //carLoan.numOfPayments = 5 * 12
      carLoan.setNumOfPayments( 5 * 12 );
      monthlyPayment = carLoan.calMonthlyPayment();
      
      //print the carLoan object information
      System.out.println("Car Loan Information: ");
      System.out.println( carLoan.toString() );
      System.out.println("Monthly Payment: $" + monthlyPayment);
      
      //create a mortgage loan object by invoking the default constructor
      mortgageLoan = new Loan();
      
      //setter to set data members of mortgage loan.
      mortgageLoan.setLoanName("Marcus's Mortgage Loan");
      mortgageLoan.setLoanAmount(150000);
      mortgageLoan.setInterestRate(4.25 / 12 / 100);
      mortgageLoan.setNumOfPayments(30 * 12);
   
      //call the method to calculate the monthly payments of the mortgage loan
      monthlyPayment = mortgageLoan.calMonthlyPayment(); 
      
      //print the carLoan object information
      System.out.println("\nMortgage Loan Information: ");
      System.out.println( mortgageLoan.toString() );
      System.out.println("Monthly Payment: $" + monthlyPayment);
      
      
          
   }
}
