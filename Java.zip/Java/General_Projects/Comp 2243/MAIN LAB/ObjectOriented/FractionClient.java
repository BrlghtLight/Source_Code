/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class FractionClient
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      //declare variables
      Fraction f1, f2, result;
      
      f1 = new Fraction(2, 3);
      f2 = new Fraction(3, 5);
      
      //f1 + f2
      result = f1.add(f2);
      System.out.println(f1 + " + " + f2 + " = " + result);
      
      //deep copy - call the copy constructor
      f1 = new Fraction(f2);
      
      
   }
}