/*
     Author: Marcus Walbridge
     Date: 11-06-17
     Program: RoomCarpet.java
     Description: Three private data members regarding the room and the carpet.
                  Two overloaded constructors, and methods to find total area and total cost 
*/

public class RoomCarpet {

      //data members - instance variables
   private double roomLength;
   private double roomWidth;
   private double costPerSqFt;
   
      //default constructor
   public RoomCarpet() {
      roomLength = 0;
      roomWidth = 0;
      costPerSqFt = 0;
   }   
   
      //second constructor
   public RoomCarpet(double length, double width, double cost) {      
      if(length > 0) {
         roomLength = length;
      }
      else {
         roomLength = 0;
      }
      
      if(width > 0) {
         roomWidth = width;
      }
      else {
         roomWidth = 0;
      }
      
      if(cost > 0) {
         costPerSqFt = cost;
      }
      else {
         costPerSqFt = 0;
      }
   }
   
      //getters and setters
   public void setLength(double length) {
      roomLength = length;
   }
   
   public double getLength() {
      return roomLength;
   }
   
   public void setWidth(double width) {
      roomWidth = width;
   }
   
   public double getWidth() {
      return roomWidth;
   }
   
   public void setCost(double cost) {
      costPerSqFt = cost;
   }
   
   public double getCost() {
      return costPerSqFt;
   }
   
      //Calculate && return room dimensions
   public double roomDimension() {
      return roomLength * roomWidth;
   }
   
      //Calculate and return total cost 
   public double totalCost() {
      return costPerSqFt * ( this.roomDimension() );
   }

      //toString
   public String toString () { 
      return "\nRoom Length: " + String.format("%.2f", roomLength) + "\n" + 
             "Room Width: " + String.format("%.2f", roomWidth) + "\n" + 
             "Cost per Square Foot(Carpet): $" + String.format("%.2f", costPerSqFt) + "\n";
   }
    
}//end class