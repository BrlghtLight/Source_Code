/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class PackageDeliveryClient
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      //set the flat fee for PackageDelivery class
      PackageDelivery.setFlatFee(2.50);
      
      //create 2 PackageDelivery objects
      PackageDelivery package1 = new PackageDelivery(100001, 120, 0.25);
      PackageDelivery package2 = new PackageDelivery(100002, 25, 0.20);
      
      //calculate delivery cost
      double cost = package1.calculateCost();
      
      //print package1 information
      System.out.println(package1);
      System.out.println(cost);
      
      //compare package1 weight and package2 weight
      if(package1.getWeightInOunce() < package2.getWeightInOunce() ) {
         System.out.println("Package #2 is heavier.");
      }
      
      //retrieve the public constant in PackageDelivery class
       System.out.println(PackageDelivery.SOME_CONSTANT);
      
   }
}