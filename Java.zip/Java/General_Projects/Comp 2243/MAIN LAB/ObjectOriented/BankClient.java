/*
  Author: Marcus Walbridge
  Date: 11-06-17
  Course: COMP 2243
  Program: BankClient.java
  Description: Client program that requests user input for full name and starting balance.
               Validates inputs(primarily values that handle money).
               Creates new bank account object and then prints info of the bank account via toString.
               Uses while loop controlled by flag with switch(menu) to adjust bank account values.
*/

import java.util.Random;
import java.util.Scanner;

public class BankClient 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
   
         //variables
      BankAccount newAccount = null; //If the user doesn't create an account first
      
      int accountNumber = 0;
      String firstName;
      String lastName;
      double balance = 0;
      
      double deposit = 0;
      double withdrawal = 0;
      
      boolean flag = true;
      int switchInput = 0;
      
   
         //Looped bank menu
      while(flag) {
         
         System.out.println("\n*********************************************");
         System.out.println("\n~~~~~~~~~~Welcome to Bank of America~~~~~~~~~");
         System.out.println("\n*********************************************");
         
         System.out.println("\n1 --- Open a checking account");
         System.out.println("2 --- Deposit");
         System.out.println("3 --- Withdraw");
         System.out.println("4 --- Check your balance");
         System.out.println("0 --- Exit");
         
            //Get user input for switch
         System.out.print("\nSelect an option: ");
         switchInput = console.nextInt();
            
         switch(switchInput) {
               
            case 1:
                  //Generate an account number 0-9999
               Random rand = new Random();
               accountNumber = rand.nextInt(10000); 
              
                  //Collect user information
               System.out.print("\nFirst Name: ");
               firstName = console.next();
            
               System.out.print("Last Name: ");
               lastName = console.next();
                  
               System.out.print("Opening Amount: $");
               balance = console.nextDouble();
               
                  //Validate starting balance
               if(balance < 0) {
                  System.out.println("\nStarting balances can not be negative." + "\n" +
                                     "Starting balance set to $0.00");
               }
                  //Create bank account object
               newAccount = new BankAccount(accountNumber, firstName, lastName, balance);
               System.out.println("\n======= New Checking Account created: ========");
               
               System.out.println(newAccount.toString() );
                  
               break;
               
            case 2:
               
               if(newAccount == null) {
                  System.out.println("\nPlease make an account first.");
               }
               else {
                  System.out.print("\nAmount to deposit: $");
                  deposit = console.nextDouble();
                  
                     //Validate the deposit amount
                  if(deposit > 0) {
                     newAccount.depositMoney(deposit);
                     System.out.println("\n-----Current balance after deposit: $" + 
                                        String.format("%.2f", newAccount.getBalance() ) + "-----" );    
                  }
                  else {
                     System.out.println("\n-----Invalid deposit, try again-----");
                  }
               }
               break;
                  
            case 3:
                  //Ensure an account is made first
               if(newAccount == null) {
                  System.out.println("\nPlease make an account first.");
               }
               else {
                  System.out.print("\nAmount to withdraw: $");
                  withdrawal = console.nextDouble();
               
                     //Validate amount to be withdrawn 
                  if(withdrawal < newAccount.getBalance() && withdrawal > 0) {
                     newAccount.withdrawMoney(withdrawal);
                     System.out.println("\n-----Current balance after withdrawal: $" + 
                                        String.format("%.2f", newAccount.getBalance() ) + "-----");
                           
                  }
                  else if(withdrawal > newAccount.getBalance()  ) {
                     System.out.println("\n-----Withdrawal too great, " + 
                                        "Not enough funds-----");
                  }
                  
                  else if(withdrawal < 0) {
                     System.out.print("\nYou can only withdraw positive amounts" + "\n");
                  }
                  
                  else if(withdrawal == newAccount.getBalance() ) {
                     System.out.print("\nYou cannot have an empty account" + "\n");
                  }
               }
               break;
                  
            case 4:
                  //Ensure the user made an account
               if(newAccount == null) {
                  System.out.println("\nPlease make an account first.");
               }
               else {
                  //Print the users information
                  System.out.println(newAccount.toString() );
               }   
               break;
               
            case 0:
                  //Tell user they have ended the program
               System.out.println("\nThank you for using Bank of America");
               System.out.println("\nExiting...");
               flag = false;
                  
               break;
               
            default:
                  //Print an error message
               System.out.println("\nInvalid option, try again!");
               break;       
            
         }//end switch 
         
      }//end menu loop
   
   }//end main

}//end class
