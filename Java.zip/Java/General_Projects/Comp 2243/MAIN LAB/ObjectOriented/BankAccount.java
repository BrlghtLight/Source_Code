/**  
  @author: Marcus Walbridge
  Date: 11-06-17
  Course: COMP 2243
  Program: BankAccount.java
  Description: -Class definition of the car.  Private data established regarding the car.  
               -Contains two overloaded constructors as well as setters/getters for data members.
               -Two public instance methods for acceleration and braking.
               -toString method to return year model, make, and speed.  
*/  

public class BankAccount {

   /**
    *
    *@accountNumber---Number that identifies the account
    *@firstName---First name of user
    *@lastName---Last name of user
    *@balance---Total funds in BankAccount object
    *
    */
   private int accountNumber;
   private String firstName;
   private String lastName;
   private double balance;

/**
 *Default constructor
 */ 
   public BankAccount() {
         //accountNumber = 1001
         //firstName = "Unknown"
         //lastName = "Unknown"
         //balance = 0
      this(0, "Unknown", "Unknown", 0);
   }

/**
 *Second constructor
 *
 *@param ID---Account number of the bank account
 *@param first---First name for the bank account
 *@param last---Last name for the bank account
 *@param balance---Amount of money in bank account
 *
 */ 
   public BankAccount(int accountNumber, String firstName, String lastName, double balance) {
      this.accountNumber = accountNumber;
      this.firstName = firstName;
      this.lastName = lastName;
      
      if(balance >= 0) {
         this.balance = balance;
      }
      else {
         balance = 0;
      }
   }  
    
   /**
    *
    *@set the account number
    *@set the first name
    *@set the last name
    *
    */
   public void setAccountNumber(int accountNumber) {
      this.accountNumber = accountNumber; 
   }
   
   public void setFirstName(String firstName) {
      this.firstName = firstName;
   }
   
   public void setLastName(String lastName) {
      this.lastName = lastName;
   }
   
   /**
    *
    *@return the account number
    *@return the full name
    *@return the balance
    *
    */ 
   public int getAccountNumber() {
      return accountNumber;
   }
   
   public String getFirstName() {
      return firstName;
   }
   
   public String getLastName() {
      return lastName;
   }
   
   public double getBalance() {
      return balance;
   }

   /**
    *@param deposit---Money being put into balance
    */
   public void depositMoney(double deposit) {
      if(deposit > 0) {
         balance += deposit;
      }
   }

   /**
    *@param withdrawal---Money taken from the balance
    */
   public void withdrawMoney(double withdrawal) {
      if(balance > withdrawal) {
         balance -= withdrawal;
      }
   }

   /**
    *toString method  
    */
   public String toString() {
      return "\nAccount Number: " + accountNumber + "\n" +
             "Name: " + firstName + " " + lastName + "\n" +
             "Balance: $" + String.format("%.2f", balance);
   }
  
}//end class

