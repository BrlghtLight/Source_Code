
import javax.swing.JTextArea;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author marcu
 */
public class RegisterClass {

    public static int CART_MAX = 100;

    //product array
    RegisterClass[] productList = new RegisterClass[CART_MAX];

    //data members
    private RegisterClass Product;

    private String productName;
    private double unitPrice;

    private int quantity;
    private int productsStored = 0;

    private double totalBeforeTax;
    private double totalAfterTax;

    //static constant
    public static double TAX_RATE = 0.0675;

    //default ocnstructor
    public RegisterClass() {
        this("Unknown", 0, 0);

    }//end default constructor

    //second constructor
    public RegisterClass(String productName, double unitPrice, int quantity) {
        this.productName = productName;

        if (unitPrice >= 0) {
            this.unitPrice = unitPrice;
        } else {
            unitPrice = 0;
        }

        if (quantity >= 0) {
            this.quantity = quantity;
        } else {
            quantity = 0;
        }

    }//end second contructor

    //setters
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTotalBeforeTax(double totalBeforeTax) {
        this.totalBeforeTax = totalBeforeTax;
    }

    public void setTotalAfterTax(double totalAfterTax) {
        this.totalAfterTax = totalAfterTax;
    }

    //getters
    public String getProductName() {
        return productName;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getTotalBeforeTax() {
        return totalBeforeTax;
    }

    public double getTotalAfterTax() {
        return totalAfterTax;
    }

    //create product method
    public void storeProduct(String name, double unitPrice, int quantity) {
        productList[productsStored++] = new RegisterClass(name, unitPrice, quantity);
    }

    //purchase price method (before tax)
    public double priceBeforeTax() {
        double priceBeforeTax;
        priceBeforeTax = quantity * unitPrice;

        return priceBeforeTax;
    }

    //purchase price method (after tax)
    public double priceAfterTax() {
        double priceAfterTax;
        priceAfterTax = (quantity * unitPrice * TAX_RATE) + (quantity * unitPrice);

        return priceAfterTax;
    }

    public double checkOutBeforeTax() {
        double receiptTotal = 0;

        for (int i = 0; i < productList.length; i++) {

            receiptTotal += productList[i].priceBeforeTax();

        }//end for loop

        return receiptTotal;
    }//end check out method

    public double checkOutAfterTax() {
        double receiptTotal = 0;

        for (int i = 0; i < productList.length; i++) {

            receiptTotal += productList[i].priceAfterTax();

        }//end for loop

        return receiptTotal;
    }//end check out method

    //toString method
    @Override
    public String toString() {
        return "Product Name: " + productName + "\n"
                + "Product Price: " + String.format("%.2f", unitPrice) + "\n"
                + "Quantity: " + quantity;

    }//end toString

}//end class
