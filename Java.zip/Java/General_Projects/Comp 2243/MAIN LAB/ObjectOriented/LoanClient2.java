/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class LoanClient2 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
      
      Loan carLoan, mortgageLoan, tempLoan;
      
         //declare and create an array of loan objects
      Loan [] loanList = new Loan[5];
       
      String name; 
      double amount, rate, monthlyPayment;
      int years;
      
      
      
      
      
      for(int i = 0; i < loanList.length; i++) {
            //input
         
         System.out.print("Enter loan name: ");
         name = console.nextLine();
         
         System.out.print("Enter loan amount: $");
         amount = console.nextDouble();
      
         System.out.print("Enter loan annual interest rate: ");
         rate = console.nextDouble();
      
         System.out.print("Enter number of years: ");
         years = console.nextInt();
         
         console.nextLine();
      
         //create the car loan object by invoking constructor
         tempLoan = new Loan(name, amount, rate/12/100, years*12);
        
         //place tempLoan into array
         loanList[i] = tempLoan;
      }
   
   
      
      for(int i = 0; i < loanList.length; i++) {
         //call the method to calculate the monthly payments of the car loan
      monthlyPayment = loanList[i].calMonthlyPayment();       
       
         //print the carLoan object information
      System.out.println("Loan Information: ");
      System.out.println( loanList[i].toString() );
      System.out.println("Monthly Payment: $" + monthlyPayment);
      }//end for loop
      
   }//end main

}//end class
