/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marcu
 */
public class Membership {

    //data members
    private int memberID;
    private String name;
    private int numberOfPoint;

    //default contructor
    public Membership() {
        this(0, "Unknown", 0);
    }

    //2nd constructor
    public Membership(int memberID, String name, int numberOfPoint) {
        this.memberID = memberID;
        this.name = name;
        this.numberOfPoint = numberOfPoint;
    }

    //setters & getters
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumberOfPoint(int numberOfPoint) {
        this.numberOfPoint = numberOfPoint;
    }

    public int getMemberID() {
        return memberID;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfPoint() {
        return numberOfPoint;
    }
    
    public void purchasePoint(int points) {
       this.numberOfPoint += points;
    }
    
    public void enterClub() {
       this.numberOfPoint--;   
    }
    
    //toString
    @Override
    public String toString() {
        return  "**********************************************" + "\n"
                + "Member ID: " + memberID + "\n"
                + "Name: " + name + "\n"
                + "Number Of Points: " + numberOfPoint + "\n" 
                + "********************************************";
    }

}
