/**
     @author: Marcus Walbridge
     Date: 8-23-17
     Program: Rectangle.java
     Description: Rectangle class definition
*/

public class Rectangle {

   //data members - instance variables
   
   /**
    * The length of Rectangle
    */
   private double length;
   /**
    * The width of Rectangle
    */
   private double width;
   
   /**
    * Default constructor
    */
   public Rectangle() {  
     // length = 0.0;
     // width = 0.0;
      this(0.0, 0.0); //call the other constructor
   }
   
   /**
    * Constructs a new Rectangle with passed length and width
    * 
    * @param length  length of Rectangle
    * @param width  width of Rectangle
    */
   public Rectangle( double length, double width ) {
      //this.length = length;
      //this.width = width;
      this.setLength(length); //call setter
      this.setWidth(width); //call setter
   }
   
   //setters (mutators)  and getters (accessors)
   public void setLength( double length ) {
      if(length > 0) {
         this.length = length;
      }
      else {
         this.length = 0;
      }
   }
   /**
    * @return length of Rectangle
    */
   public double getLength() {
      return length; //only one refers to data member, no "this"
   }
   
   public void setWidth( double width ) {
      if(width > 0) {
         this.width = width;
      }
      else {
         this.width = 0;   
      }
   } 
   
   public double getWidth() {
      return width;
   }
   
   //calculateArea method
   public double calculateArea() {
      return length * width;
   }
   
   //calculatePerimeter method
   public double calculatePerimeter() {
      return 2 * (length + width );
   }
   
   //override toString() method
   public String toString() {
      return "[" + length + ", " + width + "]";
   }
   
} //end class