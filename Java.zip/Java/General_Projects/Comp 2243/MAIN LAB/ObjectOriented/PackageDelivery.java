/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: Rectangle.java
     Description: Rectangle class definition
*/

public class PackageDelivery {

   //data members:
   //instance variables
   private int packageID;
   private double weightInOunce;
   private double costPerOunce;
   
   //static variables
   private static double flatFee; //default value = 0
   
   //constant
   public static final double SOME_CONSTANT = 25.5;
   
   //constructor 1
   public PackageDelivery() {
      this(0 , 0.0 , 0.0);
   }
   
   //constructor 2
   public PackageDelivery(int id, double weight, double cost) {
      this.packageID = id;
      this.weightInOunce = weight;
      this.costPerOunce = cost;
   }
   
   //setters and getters for instance variables
   public void setWeightInOunce(double weightInOunce) {
      this.weightInOunce = weightInOunce;
   }
   public double getWeightInOunce() {
      return this.weightInOunce;
   }
   
   
   //static setter and getter for static variable: flatFee
   public static void setFlatFee( double fee ) {
      flatFee = fee;
   }
   
   public static double getFlatFee() {
      return flatFee;
   }
      
   //calculate the delivery cost
   public double calculateCost() {
      return (weightInOunce * costPerOunce) + flatFee;
   }
   
   //override toString 
   public String toString() {
      return "Package ID: " + packageID + "\n" +
             "Weight in Ounces: " + weightInOunce + "\n" +
             "Cost per Ounce: " + costPerOunce;
   }
   
   
} //end class