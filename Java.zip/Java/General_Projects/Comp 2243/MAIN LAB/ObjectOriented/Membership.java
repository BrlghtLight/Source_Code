/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: 
     Description: 
*/

public class Membership {

    //data members - instance variables
   private int memberID;
   private String name;
   private int numberOfPoint;
    
    //defualt constructor
   public Membership() {
      memberID = 0;
      name = "Unknown";
      numberOfPoint = 0;
   } 
    
    //2nd constructor
   public Membership(int id, String n, int number) {
      memberID = id;
      name = n;
      if(number > 0) {
         numberOfPoint = number;
      }
      else {
         numberOfPoint = 0;
      }
   }
    
    //setters and getters
   public int getNumberOfPoint() {
      return numberOfPoint;
   }
    
   public void purchasePoints(int points) {
      if(points > 0) {
         numberOfPoint += points;
      } 
   }
    
   public void enterClub() {
      if(numberOfPoint > 0) {
         numberOfPoint--;
      }
   }
    
   public String toString() {
      return "\nMember ID: " + memberID +
              "\nMember Name: " + name +
              "\nTotal Points: " + numberOfPoint;
   }
    
    
        
}//end class