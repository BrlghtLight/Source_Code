/*
  Author: Marcus Walbridge
  Date: 11-06-17
  Course: COMP 2243
  Program: DriverClient.java
  Description: Client program that requests user input for year and make.
               Validates year input(no input before cars were invented).
               Creates new car object and then prints info of the car via toString.
               Uses while loop controlled by flag with switch(menu) to control speed.
               Finally prints final status of the car object.
*/

import java.util.Scanner;

public class DriverClient 
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
   
         //variables
      
      Car newCar;
      String make;
      boolean flag;
      
      int year = 0;
      int switchInput = 0;
   
         //Constants
      
      final int INITIAL_SPEED = 0;
      
         //User input (Car information)
      
      while(true) {
         System.out.print("\nEnter the Year Model of the car: ");
         year = console.nextInt();
         
         if(year < 1885) {
            System.out.println("\nError, cars were not invented until 1885.");
         }
         else {
            break;
         } 
      } //End year validation.
      
      System.out.print("Enter the Make of the car: ");
      make = console.next();
   
         //Create Car object
      
      newCar = new Car(year, make, INITIAL_SPEED);
      System.out.println("\n******************************************" + "\n" +
                         "\nNew Car object is created");
         
         //Print info by calling toString method
      
      System.out.println(newCar.toString() );
   
         //initialize the state of the flag
      
      flag = true;
   
         //Loop with a switch to control the speed.
      
      while(flag) {
      
            //User controls car speed, increments of 5
        
         System.out.println("\n******************************************");
         
         System.out.println("\n1 - Accelerate");
         System.out.println("2 - Brake");
         System.out.println("0 - Exit");
         
         System.out.print("\nEnter your choice: ");
         switchInput = console.nextInt();
      
         switch(switchInput) {      
            
               //Acceleration
            
            case 1: 
            
               if(newCar.getSpeed() < 65) {
                  newCar.carAcceleration();
                  System.out.println("\n******************************************" +
                                     "\n\nSpeed increased by 5 mph" + "\n" +
                                     "Current speed: " + newCar.getSpeed() + " mph");
               }
               else {
                  System.out.println("******************************************" +
                                     "\n\n------------Maximum speed reached------------");
               }
               break;
         
               //Braking
          
            case 2:
            
               if(newCar.getSpeed() > 0) {
                  newCar.carBrake();
                  System.out.println("\n******************************************" +
                                     "\n\nSpeed decreased by 5 mph" + "\n" +
                                     "Current speed: " + newCar.getSpeed() + " mph");
               }
               else {
                  System.out.println("******************************************" + 
                                     "\n\n------------Minimum speed reached------------");
               }
               break;
         
               //End speed control
          
            case 0:
            
               System.out.println("\nYou are no longer controlling the speed of the car.");
               flag = false;
               break; 
         
               //default case
           
            default:
             
               System.out.println("\nInvalid choice(Valid options: 1, 2, 0)");
         
         }//end switch
      
      }//end while loop
   
         //Print the car data after user controls speed
      
      System.out.println("\n" + newCar.toString() );
   
   }//end main

}//end class
