/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class RectangleClient
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      //declare variables
      
      Rectangle r1, r2;
      
      double length, width, area, perimeter;
      
      //input
      System.out.print("Enter length: ");
      length = console.nextDouble();
      
      System.out.print("Enter width: ");
      width = console.nextDouble();   
      
      //create r1 object 
      r1 = new Rectangle( length, width );
      
      //calculate r1
      area = r1.calculateArea();   
      perimeter = r1.calculatePerimeter();
      
      //call toString
      System.out.println("r1 object: " + r1.toString() );
      
      //print the area and perimeter 
      System.out.printf("Area: %.2f", area);
      System.out.printf("%nPerimeter: %.2f", perimeter);
      
      //double the length and width of r1
      
      /* 
      r1.length = length * 2; ERROR
      r1.width = width * 2; ERROR
      */ 
      
      r1.setLength( 2 * r1.getLength() );
      r1.setWidth( 2 * r1.getWidth() );
   
      //call toString
      System.out.println("\n\nr1 object again: " + r1.toString() );
   
      //use the default constructor to create r2
      r2 = new Rectangle();
      
      //call toString
      System.out.println("\n\nr2 object: " + r2.toString() );
   }
}