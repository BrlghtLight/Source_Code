/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: RectangleClient.java
     Description: 
*/

import java.util.Scanner;

public class RectangleClient2
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      //declare variables
      
      Rectangle r1, r2;
      
      double length, width, area, perimeter;
      
      //input
      System.out.print("Enter length: ");
      length = console.nextDouble();
      
      System.out.print("Enter width: ");
      width = console.nextDouble();   
      
      //create r1 and r2 object 
      r1 = new Rectangle( length, width );
      r2 = new Rectangle( length, width );
      
      if(r1 == r2) {
         System.out.print("They are equal");
      }
      else {
         System.out.print("They are not equal");
      }
      
      //compare r1 and r2
      if(r1.getLength() == r2.getLength() &&
         r1.getWidth() == r2.getWidth() ) {
          
         System.out.println("\nThey are equal.");   
      }      
      else {
         System.out.println("\nNot equal");
      }
   }
}