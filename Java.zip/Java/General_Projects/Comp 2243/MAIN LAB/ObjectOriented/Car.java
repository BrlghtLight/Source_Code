/*
  Author: Marcus Walbridge
  Date: 11-06-17
  Course: COMP 2243
  Program: Car.java
  Description: -Class definition of the car.  Private data established regarding the car.  
            -Contains two overloaded constructors as well as setters/getters for data members.
            -Two public instance methods for acceleration and braking.
            -toString method to return year model, make, and speed.  
*/

public class Car {

      //data members - instance variables
   private int yearModel;
   private String carMake;
   private double carSpeed;

      //Default constructor
   public Car() {
      yearModel = 1885;
      carMake = "Default";
      carSpeed = 0;
   }   

      //2nd constructor
   public Car(int year, String make, double speed) {
      if(year > 1885) {
         yearModel = year;
      }
      else {
         yearModel = 1885;
      }
   
      carMake = make;
      carSpeed = speed;
   }

      //Setters
   public void setYear(int year) {
      yearModel = year;
   }
   public void setSpeed(double speed) {
      carSpeed = speed;
   }
   public void carMake(String make) {
      carMake = make;
   }

      //Getters
   public int getYear() {
      return yearModel;
   }
   public String getMake() {
      return carMake;
   }
   public double getSpeed() {
      return carSpeed;
   }

      //Methods: Accelerate and Break
   public void carAcceleration() {
      if(carSpeed < 65) {
         carSpeed += 5;
      }
   }

   public void carBrake() {
      if(carSpeed > 0) {
         carSpeed -= 5;
      }
   }

      //toString
   public String toString() {
      return "\nCar Information:" + "\n\n" +
             "Year Model: " + yearModel + "\n" +
             "Make: " + carMake + "\n" +
             "\nCurrent status of the car:" + "\n\n" + 
             "Speed: " + carSpeed + " mph";
   }
   
}//end class

