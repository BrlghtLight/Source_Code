/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: Rectangle.java
     Description: Rectangle class definition
*/

public class Fraction {

   //data members - instance variables
   private int numerator;
   private int denominator;
   
   //default contructor
   public Fraction() {
      numerator = 0;
      denominator = 1;
   }
   
   public Fraction(int numerator, int denominator) {
      this.numerator = numerator;
      this.denominator = denominator;
   }
   
   //copy constructor
   public Fraction(other) {
      this.numerator = other.numerator;
      this.denominator = other.denominator;
   }
   
   //copy method - it is used for deep copy
   public Fraction copy() {
      Fraction copyFraction = new Fraction(this.numerator, this.denominator)
      return copyFraction;
   }
   
   //setters and getters
   
   
   
   
   public Fraction add(Fraction other) {
      int n1, n2, d1, d2, resultN, resultD;
      
      Fraction result;
      
      n1 = this.numerator;
      n2 = other.numerator;
      d1 = this.denominator;
      d2 = other.denominator;
      
      resultN = n1 * d2 + n2 * d1;
      resultD = d1 * d2;
      
      result = new Fraction(resultN, resultD); //create a new fraction object based on resultN && resultD     
      return result;
   }
   
   //override toString
   public String toString() {
       return numerator + "/" + denominator;
   }
   
   
   
   
   
} //end class