/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: 
     Description: 
*/

public class Loans {

    //data members - instance variables
   private String loanName;
   private double loanAmount;
   private double interestRate; //monthly rate
   private int numOfPayments;
    
    //default constructor
   public Loan() {
      loanName = "Unknown";
      loanAmount = 0.0;
      interestRate = 0.0;
      numOfPayments = 0;
   }
   
   //constructor
   public Loan(String x, double amount, double rate, int n) {
      loanName = x;
      loanAmount = amount;
      interestRate = rate;
      numOfPayments = n;
   }
   
   //setters and getters
   public void setLoanName(String name) {
      loanName = name;
   }
   
   public String getLoanName() {
      return loanName;
   }
   
   public void setLoanAmount(double amount) {
      loanAmount = amount;
   }
   
   public double getLoanAmount() {
      return loanAmount;
   }
   
   public void setInterestRate(double rate) {
      interestRate = rate;
   }
   
   public double getInterestRate() {
      return interestRate;
   }
   
   public void setNumOfPayments(int number) {
      numOfPayments = number;
   }
   
   public int getNumOfPayments() {
      return numOfPayments;
   } 
   
   //calculate monthly payment
   public double calMonthlyPayment() {
      double monthlyPayment;
      monthlyPayment = (loanAmount * interestRate) /
                       (1 - Math.pow( 1 / (1 + interestRate), numOfPayments) );
      return monthlyPayment; 
   }
   
   //override toString method
   public String toString() {
      return "\nLoan name: " + loanName + 
             "\nLoan Amount: $" + loanAmount +
             "\nMonthly Interest Rate: " + interestRate + 
             "\nNumber of Payments: " + numOfPayments;
   }
   
}//end class