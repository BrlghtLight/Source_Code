
/**
 *
 * @author marcus
 */
import java.util.Scanner;

public class BasketballProjectClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner console = new Scanner(System.in);
        //declare and create an array of BasketballPlayers
        BasketballPlayer[] playerList = new BasketballPlayer[5];

        //populate the array with 5 objects based on the user input
        for (int i = 0; i < playerList.length; i++) {
            System.out.print("Enter Jersey Number: ");
            int jNumber = console.nextInt();

            System.out.print("Enter First Name: ");
            String fName = console.next();

            System.out.print("Enter Last Name: ");
            String lName = console.next();

            System.out.print("Enter Shots Attempted: ");
            int shotsAttempted = console.nextInt();

            System.out.print("Enter Shots Made: ");
            int shotsMade = console.nextInt();

            //create an object and place it in the array 
            playerList[i] = new BasketballPlayer(jNumber, fName, lName,
                    shotsAttempted, shotsMade);
        }

        for (int i = 0; i < playerList.length; i++) {
            System.out.println(playerList[i].toString());
            double percentage = playerList[i].calculateShootingPercentage();

            System.out.printf("Shooting Percentage: %.2f %n%n", percentage * 100);
        }

        //find the index of the object with the highest shooting percentage
        int maxIndex = 0;
        for (int i = 1; i < playerList.length; i++) {
            if (playerList[i].calculateShootingPercentage()
                    > playerList[maxIndex].calculateShootingPercentage()) {

                maxIndex = i;

            }

        }//end for loop

        System.out.println("The player with the highest shooting percentage: ");
        System.out.println(playerList[maxIndex]);
        System.out.printf("Shooting Percentage: %.2f",
                playerList[maxIndex].calculateShootingPercentage());

    }//end main

}//end class
