/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

public class Commission
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
          //declare variables
      
      double transaction, commission;
      
          //constants
      
          
          //prompt user to enter input
      
      System.out.print("Enter the transaction amount: ");
      transaction = console.nextDouble();
      
          //calculate    
      if(transaction <= 0)
      {
          System.out.println("The user input is invalid.");
      }
      else 
      {
              //use a multiple selection
          if(transaction < 3000)             
          {
              commission = 25 + 0.015 * transaction;
          }
          else if(transaction < 6500)
          {
              commission = 50 + 0.0065 * transaction;        
          }
          else if(transaction < 40000)
          {
              commission = 70 + 0.003 * transaction;
          }
          else if(transaction < 100000) 
          {
              commission = 100 + 0.002 * transaction;
          }
          else if(transaction < 500000)
          {
              commission = 150 + 0.0011 * transaction;
          }
          else
          {
              commission = 250 + 0.0009 * transaction;
          }            
          
          if(commission < 40)
          {
              commission = 40;
          }
              
          System.out.printf("%nCommission earned: $%.2f", commission);
 
      }        
          
           
      
       
   }
   
}