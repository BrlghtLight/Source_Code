/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: Fibonacci.java
     Description:
*/

import java.util.Scanner;

public class Fibonacci
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
      
          //variable
      int position, n, i, pre1, pre2;
      
          //input
      
      System.out.print("Enter a position: ");
      position = console.nextInt();
      
      while(position < 0);
      {
          System.out.println("Invalid input, try again.");
          
          System.out.print("Enter a position: ");
          position = console.nextInt();
      }
       
          //calculate
     
      if( position == 0 || position == 0)
      {
          System.out.println("The fibonacci number at position " + position +
                             " is: " + position);
          return; //end main method
      }
       
          //While loop
      
      i = 2;
      n = 0;
      pre1 = 0;
      pre2 = 1;
      
      while( i <= position )
      {
          n = pre1 + pre2;
          
          pre1 = pre2;
          pre2 = n;
          
          i++;
      }  
  
      System.out.println("The fibonacci number at position " +
                         " is: " + n);
  
   }
}