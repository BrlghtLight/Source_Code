/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: MimicCalculator.java
     Description:
*/

import java.util.Scanner;

public class SpeedofSound
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
      
          //variables  
      String medium;
      double distance, time;
      
          //input
      System.out.print("Enter the medium (air, water, or steel): ");
      medium = console.next();
      
      medium = medium.toLowerCase();
      
          //validate
      if( medium.equals( "air" ) || medium.equals( "water" ) || medium.equals( "steel" ) )
      {
         System.out.print("Enter the distance to travel: ");
         distance = console.nextDouble();
          
         if(medium.compareTo("air") == 0)
         {
            time = distance / 1100.0;
         }
         else if(medium.compareTo("water") == 0)
         {
            time = distance / 4900.0;    
         }
         else
         {
            time = distance / 16400;
         }
                    
         System.out.printf("%nThe amount of time to travel is %.3f", time);
          
      }    
      else
      {
         System.out.println("Invalid medium");
      }
   }
}