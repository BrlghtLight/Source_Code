/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: Factorial.java
     Description:
*/

import java.util.Scanner;

public class Factorial2
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
      int n, i;
      long result;
      
      System.out.print("Enter a positive integer: ");
      n = console.nextInt();
       
      if( n < 0 )
      {
         n = -n;
      }
      
      //n = Math.abs(n);
      
      i = 1;
      
      result = 1;
      
      do
      {
         result = result * i;
          
         i++;
      }
      
      while( i <= n );
      
      System.out.printf("%n" + n +"! = %,d", result);  
      
          //calculate n! again
      i = n;
      
      result = 1;
      
      while( i >= 1 )
      {
         result *= i;
          
         i--;
      }
      
      System.out.printf("%n" + n +"! = %,d", result);
      
      
   
   
   
   
   }
}