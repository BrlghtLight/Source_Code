/*
     Author: Marcus Walbridge
     Date: 10/11/2017
     Program: Palindome.java
     Description:
*/

import java.util.Scanner;

public class Palindrome
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      String input;
      boolean flag;
      
      while(true)
      {
         System.out.print("Enter a string (Exit to end the program): ");
         input = console.nextLine().toUpperCase();
      
          //remove blank spaces and punctuations
          
         input = input.replaceAll("\\W", "");
         
         if( input.equals("Exit") ) //compare the contents of 2 String objects
         {
             break;
         }
          
          //call isPalindrome method
      
         flag = isPalindrome( input );
      
         if( flag == true )
         {
            System.out.println( input + " is a palindome.");
         }
         else
         {
            System.out.println( input + " is not a palindrome.");
         }
      }   
   }// end main
   
    //isPalindrome method definition
    
   public static boolean isPalindrome( String s1 )
   {
   
      int i, j;
       
      i = 0;
      j = s1.length() - 1;
   
      while( i < s1.length() / 2 )
      {
         if( s1.charAt(i) != s1.charAt(j) )
         {
            return false;
         }
           
         i++;
         j--;
      }
       
      return true;
       
   }
   
}// end class