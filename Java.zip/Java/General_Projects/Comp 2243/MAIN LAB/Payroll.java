/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: Payroll.java
     Description: Calculate the weekly pay for an hourly employee.
*/

import java.util.Scanner;

public class Payroll
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
       //declare variables
      String firstName, lastName;
      double hoursWorked, baseWage, pay;
       
       //prompt the user to enter data
      System.out.print("Enter first name: ");
      firstName = console.next();
       
      System.out.print("Enter last name: ");
      lastName = console.next();
       
      System.out.print("Enter hours worked: ");
      hoursWorked = console.nextDouble();
       
      System.out.print("Enter base wage: ");
      baseWage = console.nextDouble();
           
           //calculate
      pay = hoursWorked * baseWage;
       
           //output the result
      System.out.println("\n" + firstName + " " + lastName +
                          ", your weekly pay is $" + pay + ",");
       
       
       
   }
   
}