/*
     Author: Marcus Walbridge
     Date: 
     Program: EggyPeggy.java
     Description:
*/

import java.util.Scanner;

public class EggyPeggy {

   public static void main(String [] args) {
   
      Scanner console = new Scanner(System.in);
  
      String input;
      
         //Get user input
      System.out.print("Enter a string ");
      input = console.nextLine();
      
      System.out.println(encrypt(input));
      
   }//end main
   
      //encryption method
   public static StringBuilder encrypt(String input) {
      
         //convert input String object
      StringBuilder temp = new StringBuilder(input); 
      
      int index = 0;
      Character c;
      String temp;
      
      while(index < temp.length() ) {
         
            /*retrieve the char and convert 
              it to a Character object*/
         c = new Character(temp.charAt(index)); 
            
               //if char matches any letters in regular expression
            if(c.toString().matches("[aeiouAEIOU]")) {
               
               temp.insert(index, "egg");
               index += 4;
               
            } else {
                 
                 index++;   
            }
       
         }//end c
         
      }//end while
      
      return temp;
   
   }//end StringBuilder
   
}//end class