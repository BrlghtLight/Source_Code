/*
     Author: Marcus Walbridge
     Date: 10-06-17
     Program: ElectionVotes.java
     Description: 
*/

import java.util.Scanner;
import java.io.*;

public class Election2
{
   static final int SIZE = 5;
   
   public static void main(String [] args) throws IOException   
   
   { 
      Scanner console = new Scanner(System.in);       
      
         //declare and create 2 arrays
      String [] nameList = new String[SIZE];
      int [] voteList = new int[SIZE];
      
         //call the method to populate the arrays
         //based on the user input
      inputData(nameList, voteList);
      
      System.out.println("\nCandidate Name     Votes Received     % of Total Votes");
         
         //call totalVotes method
      int voteTotal = totalVotes(voteList);
      
      for(int i = 0; i < voteList.length; i++) {
         System.out.printf("%-18s %-18d %-6.2f %n",
                           nameList[i], voteList[i],
                           voteList[i] / (double)voteTotal * 100);
      }//end for loop
      
         //call the winner method
      int maxIndex = winnerIndex(voteList);
      
      System.out.println("\nThe winner is " + nameList[maxIndex] + ".");
      
      
      
   }//end main
   
   public static void inputData(String [] nameList, int [] voteList) throws IOException {
      
         //create inFile object
      File myFile = new File("Election_Data.txt");
      Scanner inFile = new Scanner(myFile);
      
      Scanner console = new Scanner(System.in);
      
      for(int i = 0; i < nameList.length; i++) {
      
         nameList[i] = inFile.next();
         voteList[i] = inFile.nextInt();
                
      }//end for loop
   
      inFile.close();
   
   }//end inputData method 
   
   public static int totalVotes(int [] voteList) {
      int sum = 0;
      
      for(int i = 0; i < voteList.length; i++) {
         sum += voteList[i];
         
      }//end for loop
      
      return sum;
      
   }//end total vote method  
         
   public static int winnerIndex(int [] voteList) {
      int maxIndex = 0;
      
      for(int i = 1; i < voteList.length; i++) {
         if(voteList[i] > voteList[maxIndex]) {
            maxIndex = i;
         }
         
      }//end for loop
      
      return maxIndex;
      
   }// end winnerIndex method

}//end class