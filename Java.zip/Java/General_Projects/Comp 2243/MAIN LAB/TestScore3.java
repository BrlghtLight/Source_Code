/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: TestScore2.java
     Description: Sentinel control
*/

import java.util.Scanner;

public class TestScore3
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int score, i, sum, largest;
      double average;
      
          //boolean value
      
      boolean flag = true;
      
      i = 0;
      sum = 0;
      largest = Integer.MIN_VALUE;
          
      while( flag )
      {
      
         System.out.print("Enter a test score for student #" + (i+1) + ": ");
         score = console.nextInt();
      
         if( score == -1 )
         {
            flag = false;
         }     
         else if(score >=0 && score <= 100)
         {
            sum += score;
              
            i++;
              
            if(largest < score)
            {
               largest = score;
            }
         }
         else
         {
            System.out.println("\nInvalid score, try again.");
         }
         
      } //end while
      
      average = sum / (double)i;
      
      System.out.println("Number of students: " + i);
      System.out.printf("%nClass Average: %.2f", average);
      System.out.println("\nHighest Score: " + largest);
      
      
      
         
   }
}