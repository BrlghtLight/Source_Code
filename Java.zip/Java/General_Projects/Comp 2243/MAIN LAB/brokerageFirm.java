/*
     Author: Marcus Walbridge
     Date: 10-23-17
     Program: brokerageFirm.java
     Description: Use user-defined methods to return the amount invested
                  and the amount received. Output this information and 
                  determine if there was a gain or a loss. Loop is controlled
                  by the user.
*/

import java.util.Scanner;

public class brokerageFirm
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
    
      //variables
      String stockSymbol;
     
      int numOfShares = 0, count = 0;     
      
      double purchasePrice = 0, sellPrice = 0, amountInvested = 0,
             amountReceived = 0, amountGained = 0;
      
      //constants
      double SERVICE_CHARGE = 4.95;
      int SENTINEL = -1;
      
      while(true)
      {
         System.out.println();
         System.out.print("\nEnter the stock symbol: ");
         stockSymbol = console.next();
      
         System.out.print("\nEnter the number of shares (-1 to stop): ");
         numOfShares = console.nextInt();
            
         if(numOfShares == SENTINEL)
         {
            System.out.println("\nExiting...");
            break;
         }
            
         System.out.print("\nEnter the purchase price per share: $");
         purchasePrice = console.nextDouble();
            
         System.out.print("Enter the selling price per share: $");
         sellPrice = console.nextDouble();
            
         if(numOfShares <= 0 || purchasePrice <= 0 || sellPrice <= 0)
         {
            System.out.println("\nError, each of the following must be greater than zero:" +
                                   "\nNumber of shares, buying price, and selling price" +
                                   "\nTry again!");
         }
         else
         {
            System.out.println("\nStock Symbol: " + stockSymbol);
                
            amountInvested = buyStock(numOfShares, purchasePrice);
            amountReceived = sellStock(numOfShares, sellPrice);
               
            amountGained = amountReceived - amountInvested;
                
            System.out.printf("%nTotal amount invested (including service charge): $%.2f", amountInvested);
            System.out.printf("%nTotal amount received (excluding service charge): $%.2f", amountReceived);
                  
            if( amountGained < 0)
            {
               amountGained *= -1;
               System.out.printf("%n%nAmount Lost: $%.2f", amountGained);
            }
            else if( amountGained > 0)
            {
               System.out.printf("%n%nAmount Gained: $%.2f", amountGained);
            }
            else if( amountGained == 0)
            {
               System.out.print("%n%nNo gains or loss");
            }
                  
            count++;
         }
      
      } //end while
   
   } //end main
   
   //method definition   
  
   public static double buyStock (int numOfShares, double purchasePrice)
   {      
      double amountInvested;
      double SERVICE_CHARGE = 4.95;
      
      amountInvested = (numOfShares * purchasePrice) + SERVICE_CHARGE; 
      return amountInvested;
   } //end buyStock
   
   public static double sellStock (int numOfShares, double sellPrice)
   {
      double amountReceived, amountGained = 0, amountLost = 0;      
      amountReceived = numOfShares * sellPrice;
      
      return amountReceived;
   } //end sellStock
}
