/*
     Author: Marcus Walbridge
     Date: 10-11-2017
     Program: TwoNumbers.java
     Description: Collect input (2 numbers), Output all odd numbers, the sum of the even numbers, 
                  the sum of all odd and even squares, and the uppercase alphabet.
*/
 
import java.util.Scanner;
 
public class TwoNumbers
{
   public static void main(String [] args)
   
   {
      
      Scanner console = new Scanner(System.in);      
      
      //variables
      
      int i, n1, n2, temp, count = 0, sumOfEvens = 0, sumOfSquareOfOdds = 0;
      double average;  
      
      //Take Input from User.
      
      System.out.print("\nEnter two integers ");
      n1 = console.nextInt();
      n2 = console.nextInt();          
        
      //Ensure the numbers are positive values.
      
      n1 = Math.abs(n1);
      n2 = Math.abs(n2);
      
      //Ensure that the two values are ordered from least to greatest
      
      if( n1 > n2)
      {
         temp = n1;
         n1 = n2;
         n2 = temp;
      }
   
   
      //D, E and F: Output the Odd values but go ahead and collect the sum of the
      // squares of these since they are needed later.  Additionally, calculate the sum
      // of evens.
      
      i = n1;      
      
      while( i <= n2 )
      {
         if( i % 2 == 1 ) // Odd numbers.
         {
            System.out.print( i + " "); //odds
            sumOfSquareOfOdds += (i*i);
            count++;           
         } 
         else
         { 
            // Even numbers
         
            sumOfEvens += i;
         
         }
         if( count % 10 == 0 )
         {
            System.out.println();
         }
        
         i++;
         
      } //end while
      
      System.out.println();
      // E's completion.
      System.out.println("\nSum of even numbers: " + sumOfEvens);
      // F's completion.
      System.out.print("Sum of all odd and even squares: " + sumOfSquareOfOdds);
   
      //Output the alphabet in caps.
      
      char alphabet;
      
      alphabet = 'A';
      
      System.out.println();
      System.out.println();
      
      System.out.print("Uppercase letters are: ");
      
      while( alphabet <= 'Z' )
      {
         System.out.print(alphabet + " ");
         alphabet++;
      }
      System.out.println();
   }
}