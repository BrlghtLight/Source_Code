/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: WhileLoop.java
     Description:
*/

import java.util.Scanner;

public class WhileLoop
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int i, sum = 0;
      
      i = 1;
      
      while( i<=500)
      {
         System.out.print( i + " ");
          
         sum = sum + i;
          
         if( i%10 == 0)
         {
            System.out.println();
         }
          
         i++;
      } //end while
      
      System.out.printf("%nThe total value is %,d", sum);    
   
      //2nd while loop
      int n1, n2, sum2 = 0, count = 0;
      double average;
   
      System.out.print("\nEnter two integers: ");
      n1 = console.nextInt();
      n2 = console.nextInt();
   
      i = n1;
      
      //assume n1 is less than n2, and both are positive integers
      while( i <= n2 )
      {
         if( i%2 == 1) //odd numbers
         {
            System.out.print( i + " ");
            
            sum2 += i;
            
            count++;
         }
         
         if( count % 10 == 0 )
         {
            System.out.println();
         }
         
         i++;
         
      } //end while
      
      average = sum2 / (double)count;
      
      System.out.printf("%nThe average value of the odd numbers is %.2f", average);
      
      
   

   }
}