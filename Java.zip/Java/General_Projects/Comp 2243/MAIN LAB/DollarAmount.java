/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: DollarAmount.java
     Description: Calculate the number of quarters, dimes, nickels, and pennies in given dollar amount.  
*/

import java.util.Scanner;

public class DollarAmount
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
         
          //variables
     
      int totalQuarter, totalDime, totalNickel, totalPenny, dollarAmount;
      double input;

          //constants
      
      final int quarter = 25, dime = 10, nickel = 5, penny = 1;
          
          //input
          
       System.out.print("Enter a dollar amount : $");
       input = console.nextDouble();
        
          //calculate
       
      dollarAmount = (int)(input * 100); 
          
      if( dollarAmount < 0)
      {     
         System.out.println("Invalid dollar amount, try again.");
      }
      else
      {
         dollarAmount = (int)(input * 100);
         
         totalQuarter = dollarAmount / quarter;
         dollarAmount = dollarAmount % quarter; 
         
         totalDime = dollarAmount / dime;
         dollarAmount = dollarAmount % dime;
         
         totalNickel = dollarAmount / nickel;
         dollarAmount = dollarAmount % nickel;
         
         totalPenny = dollarAmount;
         
         if( totalQuarter != 0 && totalDime != 0 && totalNickel != 0 && totalPenny != 0 )
         {
             System.out.println("Quarters: " + totalQuarter);
             System.out.println("Dimes: " + totalDime);
             System.out.println("Nickels: " + totalNickel);
             System.out.println("Pennies: " + totalPenny);
         }
         else if( totalQuarter != 0 && totalDime != 0 && totalNickel != 0 && totalPenny == 0 )
         {
             System.out.println("Quarters: " + totalQuarter);
             System.out.println("Dimes: " + totalDime);
             System.out.println("Nickels: " + totalNickel);
         }
         else if( totalQuarter != 0 && totalDime != 0 && totalNickel == 0 && totalPenny != 0 )
         {
             System.out.println("Quarters: " + totalQuarter);
             System.out.println("Dimes: " + totalDime);
             System.out.println("Pennies: " + totalPenny);
         }
         else if( totalQuarter != 0 && totalDime == 0 && totalNickel == 0 && totalPenny != 0 )
         {
             System.out.println("Quarters: " + totalQuarter);
             System.out.println("Nickels: " + totalNickel);
             System.out.println("Pennies: " + totalPenny);
         }
         else if( totalQuarter == 0 && totalDime == 0 && totalNickel == 0 && totalPenny != 0 )
         {
             System.out.println("Dimes: " + totalDime);
             System.out.println("Nickels: " + totalNickel);
             System.out.println("Pennies: " + totalPenny);
         }
      }
   }
}