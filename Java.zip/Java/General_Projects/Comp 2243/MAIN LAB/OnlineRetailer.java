/*
   Author: Marcus Walbridge
   Date: 9-25-17
   Program: OnlineRetailer.java
   Description:
*/

import java.util.Scanner;

public class OnlineRetailer
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
          
          //variables
          
      String order;
      double orderCost;
      int P1 = 0, P2 = 0, P3 = 0, P4 = 0, P5 = 0;
      
          //constants
          
      final double costP1 = 12.98, costP2 = 14.50, costP3 = 19.98, costP4 = 14.49, costP5 = 16.87;    
          
          //input
          
      System.out.print("Enter your order(To start, enter P1-P5): ");
      order = console.next();
          
          //switch
      
      switch(order)
      { 
         case "P1":
         
            System.out.print("Enter desired quanity of product #1: ");
            P1 = console.nextInt();
         
         case "P2":
         
            System.out.print("Enter desired quanity of product #2: ");
            P2 = console.nextInt();
         
         case "P3":
         
            System.out.print("Enter desired quanity of product #3: ");
            P3 = console.nextInt();
         
         case "P4":
         
            System.out.print("Enter desired quanity of product #4: ");
            P4 = console.nextInt();
         
         case "P5":
         
            System.out.print("Enter desired quanity of product #5: ");
            P5 = console.nextInt();
                  
            break;
       
         default:
         
            System.out.println("You did not enter a valid order");
            
            break; 
          
      } //end switch   
        //calculate
        
     orderCost = (P1 * costP1) + (P2 * costP2) + (P3 * costP3) + (P4 * costP4) + (P5 * costP5);     
     System.out.printf("%nThe cost of the order: $%.2f", orderCost);    
   
   
   }   
}