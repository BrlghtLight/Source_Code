/*
     Author: Marcus Walbridge
     Date: 10-09-17
     Program: FootballTickets.java
     Description:
*/

import java.util.Scanner;
import java.io.*;

public class FootballTickets
{
   public static void main(String [] args) throws IOException
   
   {
      Scanner console = new Scanner(System.in);
      
          //variables
      
      double pricePerTicket, totalSale = 0.0;
      int ticketsSold, totalTicketsSold = 0, count = 0;
      
          //Connnect the program with the input data file.
          //step 1: Create a file object and associate it with the data file
          //step 2: Create a scanner object and associate it with the file object
      
      File myFile = new File("tickets.txt");
      Scanner inFile = new Scanner( myFile );
          
          //Connect the program with the output file
          //step 1 : create a FileWriter object and associate it wit hthe output file
          // (true - append, false - overwrite)
          //Step 2 - create a printwriter object and associate it with the fileWriter object)
       
      FileWriter fw = new FileWriter("ticketsSales.txt", false);
      PrintWriter outFile = new PrintWriter( fw );
      
          //input data from the file and calculate the result
      while( inFile.hasNext() )
      {
         pricePerTicket = inFile.nextDouble();
         ticketsSold = inFile.nextInt();
          
         totalTicketsSold += ticketsSold;
         totalSale += pricePerTicket * ticketsSold;
          
         count++;
      } //end
      
      //write results into the output file
      outFile.printf("%nTotal number of tickets sold: %,d", totalTicketsSold);
      outFile.printf("%nTotal sales: $%,.2f", totalSale);
      outFile.println();
      
      //close the file connections
      inFile.close();
      outFile.close();  //must
      
      System.out.println("The program is completed.");
          
   }
}