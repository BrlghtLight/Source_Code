/*
     Author: Marcus Walbridge
     Date: 9-15-17
     Program: ConeShape.java
     Description: Calculate the volume and surface area of a cone.
*/

import javax.swing.JOptionPane;

public class ConeShape
{
   public static void main(String [] args)
   
   { 
           //declare variables
       
      double r, h;  //radius and height
      double volume, surfaceArea; 
      
          //constants
      final double p = Math.PI;         
       
          //input
      
      r = Double.parseDouble(
                                      JOptionPane.showInputDialog("Enter the radius of the cone: "));
      h = Double.parseDouble(
                                      JOptionPane.showInputDialog("Enter the height of the cone: "));
   
          //calculate 
      
      if( r == 0 )
      {
         String result = "error";
         
         JOptionPane.showMessageDialog( null, result );
      }
      else 
      {
         if( h == 0)
         {
            String result = "error";
            
            JOptionPane.showMessageDialog( null, result );
         }
         else
         {
            volume = p * (r * r) * (h / 3);
            surfaceArea = p * r * r + p * r * Math.sqrt(r * r + h * h); 
            
            String result = String.format("%nVolume of cone: %.2f" +
                      "%nSurface area of cone: %.2f", volume, surfaceArea);
         
            JOptionPane.showMessageDialog( null, result );
         
            System.exit(0);         
         }        
      }                     
   }   
}