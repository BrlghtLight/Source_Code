/*
     Author: Marcus Walbridge
     Date: 
     Program: RightTriangle.java
     Description: 
*/

import java.util.Scanner;

public class Parking
{
   
   static final double MIN_CHARGE = 2.0; //global constant

   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
     
      double hoursParked, charge;
      
      System.out.print("Enter the hours parked: ");
      hoursParked = console.nextDouble();
     
         //call calculateCharge method
      
      charge = calculateCharge( hoursParked );
     
         //call printReceipt method
      
      printReceipt( hoursParked, charge );
     
   } //end main
   
     //calculate parking charge method definition
   public static double calculateCharge( double hours )
   {
      double fee;
       
      if( hours < 3.0 )
      {
         fee = MIN_CHARGE;
      }
      else if( hours < 19.0 )
      {
         fee = MIN_CHARGE + 0.5 * ( hours - 3.0 );
      }
      else
      {
         fee = 10.0;
      }
       
      return fee; 
   } //end calculateCharge method 
    
     //printReceipt method definition
   
   public static void printReceipt(double hours, double fee)
   {
      System.out.printf("%nHours Parked: %.2f", hours);
      System.out.printf("%nParking Charge: $%.2f", fee);
      System.out.println("\n\nThank you for your business!");
   }
    
}//end class