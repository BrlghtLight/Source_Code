/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

public class Fax
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
       
       //declaring variables
      int numOfPages;
      double amountDue, serviceCharge;
       
       //input
      System.out.print("Enter the number of pages to fax: ");
      numOfPages = console.nextInt();
      
      
      if( numOfPages < 10)
      {
      amountDue = numOfPages * .2;
      serviceCharge = 3.00;
      System.out.println("The amount due is $" + amountDue + serviceCharge);
      }
      else
      if( numOfPages == 10)
      {
      amountDue = 2;
      serviceCharge = 3.;
      System.out.println("The amount due is $" + amountDue + serviceCharge);
      }
      else
      if( numOfPages > 10)
      { 
      amountDue = 3 + ((numOfPages - 10) * .1);
      serviceCharge = 3;
      System.out.println("The amount due is $" + amountDue + serviceCharge);
      } 
      
      
      
      
      
       
   }
   
}