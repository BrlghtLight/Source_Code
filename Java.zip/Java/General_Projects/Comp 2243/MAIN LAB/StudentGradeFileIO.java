/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: Factorial.java
     Description:
*/

import java.util.Scanner;
import java.io.*;

public class StudentGradeFileIO
{
   public static void main(String [] args) throws IOException
   
   {
      Scanner console = new Scanner(System.in);
      
          //variables
      
      String firstName, lastName;
      double testScore, totalScore = 0.0, average;
      int counter = 0;
      char grade;
      
          //Connnect the program with the input data file.
          //step 1: Create a file object and associate it with the data file
          //step 2: Create a scanner object and associate it with the file object
      
      File myFile = new File("stData.txt");
      Scanner inFile = new Scanner( myFile );
          
          //Connect the program with the output file
          //step 1 : create a FileWriter object and associate it wit hthe output file
          // (true - append, false - overwrite)
          //Step 2 - create a printwriter object and associate it with the fileWriter object)
       
      FileWriter fw = new FileWriter("stResults.txt", false);
      PrintWriter outFile = new PrintWriter( fw );
      
          //input data from the file and calculate the result
      while( inFile.hasNext() )
      {
          firstName = inFile.next();
          lastName = inFile.next();
          testScore = inFile.nextDouble();
          
          //figure out the grade
          if( testScore < 60 )
          {
              grade = 'F';
          }
          else if( testScore < 70 ) 
          {
              grade = 'D';
          }
          else if( testScore < 80 )
          {
              grade = 'C';
          }
          else if( testScore < 90 )
          {
              grade = 'B';
          }
          else 
          {
              grade = 'A';
          }
          
          totalScore += testScore;
          counter++;
        
          //write the resulta into the output file
          
          outFile.printf("%-12s %-12s %-7.1f %c %n",
                          firstName, lastName, testScore, grade);
          
      } //end
      
      //calculate average
      
      if(counter != 0)
      {
      average = totalScore / counter;
      outFile.printf("%nClass average: %.2f %n", average);
      }
      else
      {
          outFile.println("No data in the data file.");
      }      
      
      //close the file connections
      inFile.close();
      outFile.close();  //must
      
      System.out.println("The program is completed.");
          
   }
}