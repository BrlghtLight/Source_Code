/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: Factorial.java
     Description:
*/

import java.util.Scanner;

public class Lockers
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
    
          //variables
      
      int numOfFactors, lockerNum;
      
      for(lockerNum = 1; lockerNum <= 1000; lockerNum++)
      {
      
          numOfFactors = 0;
      
          for( int i = 1; i <= lockerNum/2; i++ )
          {
              if( lockerNum % i == 0 )
              {
                  numOfFactors++;
              }
          } //end inner loop
          
          numOfFactors++; //include the locker number itself
          
          if( numOfFactors % 2 != 0 ) //odd
          {
              System.out.println( "Locker " + lockerNum + " is open.");
          }
          else
          {
              System.out.println( "Locker " + lockerNum + " is closed.");
          }
      
      }









        
  }
}