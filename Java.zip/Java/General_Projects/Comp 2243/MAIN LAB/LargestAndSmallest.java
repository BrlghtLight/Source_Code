/*
   Author: Marcus Walbridge
   Date: 8-21-17
   Program: Payroll.java
   Description: Calculate the weekly pay for an hourly employee.
*/

import java.util.Scanner;

public class LargestAndSmallest
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
      
        //declare variables
      int n1, n2, n3, max, min;
      
        //input
      System.out.print("Enter 3 integers separated by a space: ");
      n1 = console.nextInt();
      n2 = console.nextInt();
      n3 = console.nextInt();
      
        //determine which is the largest and which one is the smallest
      max = n1;  
      
      if( n2 > max )
      {
         max = n2;
      }
      
      if( n3 > max )
      {
         max = n3;
      }
      
      min = n1; 
      
      if( n2 < min )
      {
      min = n2;
      }
      if( n3 < min )
      {
      min = n3;
      }
      
      
      
      
      System.out.println( max + " is the largest number.");
      System.out.println( min + " is the smallest number. ");
      
      
      
      
             
       
       
   }
  
}