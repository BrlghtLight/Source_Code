/*
     Author: Marcus Walbridge
     Date: 9-15-17
     Program: UserInfo.java 
     Description: Prompt user to enter info and print out the results.
*/

import java.util.Scanner;

public class UserInfo
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
   
           //variables
    
      String cityName, lastName, firstName, state, address, initials;
      
      int stringSize, age, annualIncome;      
                  
           //Prompt user to input data
       
      System.out.print("Enter user's first name: ");
      firstName = console.next();
       
      System.out.print("Enter user's last name: ");
      lastName = console.next();
       
      System.out.print("Enter user's initials: ");
      initials = console.next();
       
      System.out.print("Enter user's home address: ");
      address = console.next();
       
      System.out.print("Enter name of city: ");
      cityName = console.next();
       
      System.out.print("Enter name of home state: ");
      state = console.next();
      
      System.out.print("Enter your age: ");
      age = console.nextInt(); 
       
      System.out.print("Enter annual income: ");
      annualIncome = console.nextInt();
      
      //calculate
             
      stringSize = cityName.length(); 
      
      String cityUpper = cityName.toUpperCase();
      String stateUpper = state.toUpperCase();
     
      String cityLower = cityUpper.toLowerCase();
      String stateLower = stateUpper.toLowerCase();
      
           //output
       
      System.out.println("Your name (last, first): " + lastName + " , "  + firstName + "\n" +
                          "Your initials: " + initials + "\n" + 
                          "Characters in city name: " + stringSize + "\n" +
                          "User location (uppercase): " + cityUpper + " , " + stateUpper + "\n" +
                          "User location (lowercase): " + cityLower + " , " + stateLower + "\n" +
                          "Your age: " + age + "\n" +
                          "Annual income: $" + annualIncome);        
              
   }
   
}