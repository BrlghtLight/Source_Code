/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: InterestCalculator.java
     Description:
*/

import java.util.Scanner;

public class InterestCalculator
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
          
          //variables
      double principal, rate, interest;
      int loanTerm;
      
          //constants
      final int SENTINEL = -1;
      
          //input principle
      System.out.print("Enter a principal(-1 to end): ");
      principal = console.nextDouble();
      
      while( principal != SENTINEL )
      {
         System.out.print("Enter an interest rate: %");
         interest = console.nextDouble();
          
         System.out.print("Enter a loan term in days: " + loanTerm);
         loanTerm = console.nextInt();
          
         if( principal > 0 && interest > 0 && loanTerm > 0 )
         {
            interest = principal * rate / loanTerm;
            System.out.printf("%nThe interest charge is $%.2f", interest);
         }
         else
         {
            System.out.println("Invalid input, try again.");
         }
         
         System.out.print("\nEnter a principal (-1 to end): ");
         principal = console.nextDouble();
                    
      }     
                
   }
}