/*
     Author: Marcus Walbridge
     Date: 9-6-17
     Program: WeightInNewtons.java
     Description: 
*/

import java.util.Scanner;

public class WeightInNewtons
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
       
          //declare variables
      double massInKilograms, weightInNewtons;
      
          //declare constants
      final double RATE = 9.8;
      
      
          //user input
          
      System.out.print("Enter mass in kilograms: ");
      massInKilograms = console.nextDouble();
          
          //calculate
      
      if(massInKilograms <= 0)
      {
         System.out.println("Error, mass in kilograms must be more than zero.");
      }    
      else
      {
         weightInNewtons = massInKilograms * RATE;
      
         System.out.println("\nWeight In Newtons: " + weightInNewtons);             
      
         if(weightInNewtons > 1000)
         {
            System.out.println("\nHeavy");
         }
         if(weightInNewtons < 10)
         {
            System.out.println("\nLight");
         }   
      
      }
      
      
      
      
      
       
   }
   
}