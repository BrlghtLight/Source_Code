/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: Fax3.java
     Description: While loop to estimate cost.
*/

import java.util.Scanner;

public class Fax3
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
       
       //declaring variables
      int numOfPages;
      double amountDue, serviceCharge;
       
       //input
      System.out.print("Enter the number of pages to fax: ");
      numOfPages = console.nextInt();
      
      while( numOfPages <= 0 )
      {
          System.out.println("Invalid input, try again.");
          
          System.out.print("Enter the number of pages to fax: ");
          numOfPages = console.nextInt();          
      } 
      
      if(numOfPages <= 10)
      {
          amountDue = 3.0 + numOfPages * 0.2;
      }
      else
      {
          amountDue = 3.0 + 10 * 0.2 + (numOfPages - 10) * 0.1;
      }
      
      System.out.println("Amount Due: $" + amountDue);
      
   }
   
}