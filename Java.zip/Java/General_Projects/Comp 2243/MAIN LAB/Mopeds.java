/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

public class Mopeds
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
          
      //declare variables
          
      String type, day;
      double hours, cost = 0.0;
          
      //input
          
      System.out.print("Enter the type of mopette (50cc or 2500cc) ");
      type = console.next();
          
      System.out.print("Enter the day (weekday or weekend): ");
      day = console.next();
          
      System.out.print("Enter hours to rent: ");
      hours = console.nextDouble();
      
      //calculate
      if(type.compareTo("50cc") == 0)  //if(type.equals("50cc")
      {
         if(day.compareTo("weekday") == 0)
         {
            if(hours <= 3)
            {
               cost = 15.0;
            }
            else
            {
               cost = 15.0 + (hours - 3.0) * 2.5;
            }
         }
         else
         {
            if(hours<= 3)
            {
               cost = 30.0;
            }
            else
            {
               cost = 30.0 + (hours - 3.0) * 7.5;
            }
         }
      }            
      else  //250cc
      {
          
      } 
   
      System.out.println("Type : " + type + "\n" +
                         "Day: " + day + "\n" +
                         "Cost: $" + cost);  
   }   
}