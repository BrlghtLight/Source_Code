/*
     Author: Marcus Walbridge
     Date: 10/11/2017
     Program: PackageWeights.java
     Description:
*/

import java.util.Scanner;

public class PackageWeights
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
  
      int count = 1, n = 11;
      double average, sum = 0, packageWeight = 0, max = Integer.MIN_VALUE, min = Integer.MAX_VALUE;
     
      for( count = 1; count < n; count++)
      {
          System.out.print("Enter package #" + count + "'s weight: ");
          packageWeight = console.nextDouble();
          
          if(packageWeight >= 0)    
          {
              sum += packageWeight;
              
              if(count == 1)
              {
                  max = packageWeight;
              }
              else if(packageWeight > max && count < n)
              {
                  max = packageWeight;
              }
              else if( packageWeight < min && count < n)
              {
                  min = packageWeight;
              } 
          }
          else
          {
              System.out.println("Error, enter a valid weight");
          }
      }      
      average = sum / (double)count;
      
      System.out.printf("%nTotal Weight: %.2f", sum);
      System.out.printf("%nAverage: %.2f", average);
      
      System.out.printf("%nMax: %.2f", max);
      System.out.printf("%nMin: %.2f", min);
   }
}