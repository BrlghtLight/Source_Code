/*
     Author: Marcus Walbridge
     Date: 8-30-17
     Program: Payroll.java
     Description: 
*/

import javax.swing.JOptionPane;

public class StockGUI
{
   public static void main(String [] args)
   
   { 
        //declare variables
       double buyPricePerShare, sellPricePerShare;
       int sharesSold; 
       
       double purchasePrice, sellPrice, serviceFeeBuy, serviceFeeSell;
       double gainOrLoss; 
        //constant 
       final double SERVICE_CHARGE = 0.015; 
        
        //input
       buyPricePerShare = Double.parseDouble(
                                      JOptionPane.showInputDialog("Enter the buying price per share: "));
       
       sellPricePerShare = Double.parseDouble(
                                      JOptionPane.showInputDialog("Enter the selling price per share: "));
       
       sharesSold = Integer.parseInt(
                            JOptionPane.showInputDialog("Enter the number of shares sold: "));
       
       
       
        //calculate 
       serviceFeeBuy = buyPricePerShare * sharesSold * SERVICE_CHARGE;
       serviceFeeSell = sellPricePerShare * sharesSold * SERVICE_CHARGE;
       
       purchasePrice = buyPricePerShare * sharesSold + serviceFeeBuy;
       sellPrice = sellPricePerShare * sharesSold - serviceFeeSell;
       
       gainOrLoss = sellPrice - purchasePrice;
       
        
       
        //output
       String result = "Total amount invested: $" + purchasePrice + "\n" +                         
                       "Total amount received: $" + sellPRice + "\n" +     
                       "Total service charges: $" + (serviceFeeBuy + serviceFeeSell) + "\n\n" +
                       "Amount gained or lost: $" + gainOrLoss;
       JOptionPane.showMessageDialog( null, result );                   
    
       System.exit(0); 
       
   }
   
}