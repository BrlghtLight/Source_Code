/*
     Author: Marcus Walbridge
     Date: 8-28-17
     Program: Payroll.java
     Description: Calculate the weekly pay for an hourly employee.
*/

import javax.swing.JOptionPane;

public class PayrollGUI
{
   public static void main(String [] args)
   
   { 
       //declare variables
       String firstName, lastName;
       double hoursWorked, baseWage, pay;
       String hoursWorkedString, baseWageString;
       
       //prompt the user to enter data
       System.out.print("Enter first name: ");
       firstName = JOptionPane.showInputDialog("Enter first name: ");
       
       System.out.print("Enter last name: ");
       lastName = JOptionPane.showInputDialog("Enter last name: ");
       
       System.out.print("Enter hours worked: ");
       hoursWorkedString = JOptionPane.showInputDialog("Enter hours worked: ");
       
       System.out.print("Enter base wage: ");
       baseWageString = JOptionPane.showInputDialog("Enter base wage: ");
           //convert hoursWorkedString to double
       hoursWorked = Double.parseDouble( hoursWorkedString );
           //convert baseWageString to double
       baseWage = Double.parseDouble( baseWageString );        
           
           
           //calculate
       pay = hoursWorked * baseWage;
       
           //output the result
       JOptionPane.showMessageDialog(null, "\n" + firstName + " " + lastName +
                          ", your weekly pay is $" + pay + ",");
       
       System.exit(0);  //exit the program gracefully
       
   }
   
}