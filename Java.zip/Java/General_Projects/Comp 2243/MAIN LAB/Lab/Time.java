/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: Time.java
     Description:  
*/

import java.util.Scanner;

public class Time
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
       
       //declaring variables
      int hours, minutes, seconds, remainder, seconds2;
       
       //declare constant
      final int SECOND_IN_HOUR = 3600;
      final int SECOND_IN_MINUTE = 60;
       
       
       //input
      System.out.print("Enter a time in seconds: ");
      seconds = console.nextInt();
       
       //calculate
      hours = seconds / SECOND_IN_HOUR;
      remainder = seconds % SECOND_IN_HOUR;
      minutes = remainder / SECOND_IN_MINUTE;
      seconds2 = remainder % SECOND_IN_MINUTE;
       
       //output
      System.out.println("\n" + seconds + " seconds is equivalent to " + 
                          hours + ":" + minutes + ":" + seconds2);
       
       
       
       
   }
   
}