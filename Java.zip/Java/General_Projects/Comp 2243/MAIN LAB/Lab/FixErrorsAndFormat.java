/*
 * Author: Marcus Walbridge
 * Date: 9-6-17
 * Course: COMP 2243
 * Description: Fix all bugs
 */
 
public class FixErrorsAndFormat
{
      		
   public static void main(String [] args) 
   {
   	    
      System.out.println("Welcome to RCTC");
      System.out.println("This program has no more bugs");		 
      System.out.println("7+8 = " + 7 + 8);
   	
      //declare variables	                                 
      int number1, number2;
      int area;
   	
      //declare constants	 
      number1 = 23;
      number2 = 4;
      
      //calculate area
      area = number1 * number2;
    		 		 
      //output the results          
      System.out.println("area is " + area);		 
      System.out.println("sum is " + (number1 + number2));			     
      System.out.println("quotient is " + (number1 / number2));			     
      System.out.println("remainder is " + (number1 % number2));
          
          
          
          
          
   
   }//end main
     
		
}//end class
 
