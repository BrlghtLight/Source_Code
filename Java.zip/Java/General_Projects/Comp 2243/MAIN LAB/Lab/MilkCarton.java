/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

public class MilkCarton
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
       
       //declaring variables
      double milkQuantity, cost, profit;
      int cartons;
       
       //declare constant
      final double CARTON_CAPACITY = 3.78;
      final double COST_ONE_LITER = 0.38;
      final double PROFIT_ONE_CARTON = 0.27;
       
       //input
      System.out.print("Enter, in liters, the quantity of milk produced: ");
      milkQuantity = console.nextDouble();
       
       //calculate
      cartons = (int) (milkQuantity / CARTON_CAPACITY + 0.5);
      cost = milkQuantity * COST_ONE_LITER;
      profit = cartons * PROFIT_ONE_CARTON;
       
       //output
      System.out.println("\nCartons needed: " + cartons);
      System.out.println("Cost: $" + cost);
      System.out.println("Profit: $" + profit);
       
       
       
       
   }
   
}