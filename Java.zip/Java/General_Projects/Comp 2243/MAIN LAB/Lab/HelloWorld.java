/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: HelloWorld.java
     Description: This is my seventh Java program.
*/

public class HelloWorld
{
   public static void main(String [] args)
   
   {
   
       //declare variables
      int number1, number2, sum;
      double radius, circleArea, circumference;
      char gender;
       //assign values to variables
      number1 = 25;
      number2 = 81;
       
      sum = number1 + number2;
       
      radius = 6.85;
       
      circleArea = 3.14 * radius * radius;
      circumference = 2 * 3.14 * radius;
       
      gender = 'M';
       
      System.out.println("Hello World!");     
      System.out.println("\nMy name is \"Marcus Walbridge\".");
      System.out.println("This is my seventh Java program.");
      System.out.println("The gender is " + gender);  
   
           //output the results
      System.out.println();
      System.out.println("The sum is " + sum);
      System.out.println("The circle area is " + circleArea);
      System.out.println("The circumference is " + circumference);  
      
      System.out.println("\n5 / 2 = " + ( 5/2 ) );
      System.out.println("5 % 2 = " + ( 5%2 ) ); 
      
      System.out.println("5.0 / 2.0 = " + ( 5.0/2.0 ));  
   }
   
}