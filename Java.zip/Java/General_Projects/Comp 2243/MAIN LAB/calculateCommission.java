/*
     Author: Marcus Walbridge
     Date: 10-23-17
     Program: calculateCommission.java
     Description: Read the file commissiondata and calculate what each employee
                  earned in a new file.
*/

import java.util.Scanner;
import java.io.*;

public class calculateCommission
{
   public static void main(String [] args) throws IOException
   
   {
       
      Scanner console = new Scanner(System.in);       
      
      //variables
      String firstName, lastName;
      
      double overallSales = 0, commissionEarned = 0, 
         average, commissionRate, individualSales, commissionTotal = 0;
      
      int count = 0;
           
      /*Read commissiondata, then create objects 
      scanner and filewriter and printwriter */
      
      File myFile = new File("commissionData.txt");
      Scanner inFile = new Scanner( myFile );
      
      FileWriter fw = new FileWriter("commissionData2.txt", false);
      PrintWriter outFile = new PrintWriter( fw );
      
      //calculate employees commission
      while(inFile.hasNext())
      {
         firstName = inFile.next();
         lastName = inFile.next();
        
         commissionRate = inFile.nextDouble();
         individualSales = inFile.nextDouble();
         
         commissionRate *= 0.01;
         
         commissionEarned = commissionRate * individualSales;
         overallSales += individualSales;
         
         commissionTotal += commissionEarned;
         
         outFile.println(firstName + " " + lastName + "   " + 
                         commissionRate + "   " + individualSales + 
                         "   " + String.format("%.2f", commissionEarned));
          
         count++;
      }
      
      //calculate the average commission earned.
      
      average = commissionTotal / count;
      
      //print the results in the output file
      
      outFile.printf("%n%n%nOverall Sales: $%.2f", overallSales);
      outFile.printf("%nAverage Commission: $%.2f", average);
      outFile.println();
      
      //close the file connections
      inFile.close();
      outFile.close();
      
      System.out.println("\nThe program is complete.");
      
   }//end main
   
}