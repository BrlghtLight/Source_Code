/*
    Author: Marcus Walbridge
    Date: 9-4-2017
    Program: Revenue.java
    Description: Calculate total visitors and revenue from those visitors.
*/

import java.util.Scanner;

public class Revenue
{
   public static void main (String[] args)
    
   {
      Scanner console = new Scanner(System.in);
        
        //establish variables
        
      double numberChildren, numberAdults, ticket, gift, foodAndDrink, totalVisitors, revenueChildren, revenueAdults, totalRevenue;
            
        //establish constants
        
      ticket = 47.99;
      gift = 5.89;
      foodAndDrink = 15.50;
        
        //prompt user to enter data
        
      System.out.print("Enter number of children ");
      numberChildren = console.nextDouble();
      System.out.print("Enter number of adults ");
      numberAdults = console.nextDouble();
        
        //calculate
        
      totalVisitors = numberChildren + numberAdults;
      revenueChildren = ((ticket * 0.5) + gift + foodAndDrink) * numberChildren;
      revenueAdults = (ticket + gift + foodAndDrink) * numberAdults;
      totalRevenue = revenueChildren + revenueAdults;
        
        //display the results
        
      System.out.println("\n" + "Total number of visitors = " + totalVisitors);
      System.out.println("Children visitors revenue = " + revenueChildren);
      System.out.println("Adult visitors revenue = " + revenueAdults);
      System.out.println("\n" + "Total revenue = " + totalRevenue);
        
   }
}