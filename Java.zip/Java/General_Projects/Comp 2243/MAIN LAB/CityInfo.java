/*
     Author: Marcus Walbridge
     Date: 11-22-2017
     Course: COMP 2243
     Program: CityInfo.java
     Description: Read the information of city_data.txt,
                  Print the information as well as the most and least populous city
                  into a new file.
*/

import java.util.Scanner;
import java.io.*;

public class CityInfo
{
   static final int SIZE = 65;
  
   public static void main(String [] args) throws IOException { 
     
      Scanner console = new Scanner(System.in);       
         
      String fileName; 
      
         //Collect to be processed file name from user
      System.out.print("Enter input file name: ");
      fileName = console.nextLine();
      
         //Call the method to create the file input object
      Scanner inFile = createFileInputObject(fileName);
      
      System.out.print("Enter output file name: ");
      fileName = console.nextLine();
      
         //Call the method to create the file output object
      PrintWriter outFile = createFileOutputObject(fileName, false);
      
         //Call the method to read and write
      fileIOMethod(inFile, outFile);
      
         //Close the file input and outputobjects
      inFile.close();
      outFile.close(); 
         
         //Tell user the program is complete
      System.out.println("\n**************************");
      System.out.println("CityInfo.java has finished"); 
      System.out.println("**************************");
          
   }//End main
   
      //Create and return inFile object (scanner)
   public static Scanner createFileInputObject(String fileName) throws IOException {
        
         //Create inFile object
      File myFile = new File("city_data.txt");
      Scanner inFile = new Scanner(myFile);
   
      return inFile;
   
   }//End inputData method
   
      //Return the outFile object (PrintWriter)
   public static PrintWriter createFileOutputObject(String fileName, boolean flag) throws IOException {
   
      FileWriter fw = new FileWriter(fileName, flag);
      PrintWriter outFile = new PrintWriter( fw );
       
      return outFile;
      
   }//End createFileOutputObject method
   
      //Read data, print city names and populations, print most/least populous cities  
   public static void  fileIOMethod(Scanner inFile, PrintWriter outFile) throws IOException {
      
         //Declare two arrays
      String [] cityList = new String[SIZE];
      int [] populationList = new int[SIZE];
   
      outFile.print("Name:                  Population:");
      outFile.println();
      
      outFile.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
      outFile.println();
    
         //Use for loop to read and print data 
      for(int i = 0; i < SIZE; i++) {
        
         cityList[i] = inFile.next();
         populationList[i] = inFile.nextInt();
         
         outFile.printf("%-22s %,-1d %n",
                         cityList[i], populationList[i]);
      }//End for loop
      
      int maxIndex = 0;    
      
         //Find city with highest population
      for(int i = 0; i < populationList.length; i++) {
         
         if(populationList[i] > populationList[maxIndex]) {
           
            maxIndex = i;  
             
         }
         
      } //End for loop
      
      int minimumIndex = 0;
      
         //Find city with lowest population
      for(int i = 0; i < populationList.length; i++) {
         
         if(populationList[i] < populationList[maxIndex]) {
           
            minimumIndex = i;  
             
         }  
         
      }//End for loop 
      
      outFile.println();
      
      outFile.printf("%nThe most populous city: %-2s with a population of %,-10d",
                     cityList[maxIndex], populationList[maxIndex]);
      outFile.printf("%n%nThe least populous city: %-2s with a population of %,-10d", 
                     cityList[minimumIndex], populationList[minimumIndex]);
   
   }//End fileIO method

}//End class