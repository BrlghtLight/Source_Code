/*
     Author: Marcus Walbridge
     Date: 11-22-17
     Course: COMP 2243
     Program: CityRainfall.java
     Description: Allow user to enter 10 
                  city names and average yearly rainfall.
                  Multiple methods to output the arrays' info.
                  Find the max index.
                  Find average of all rainfall.
                  Print all cities with below or above average 
                  rainfall.
*/

import java.util.Scanner;

public class CityRainfall
{
   static final int SIZE = 5;
   public static void main(String [] args)
   
   { 
      Scanner console = new Scanner(System.in);    
       
      boolean flag = true;    
      
         //Declare two arrays
      String [] cityList = new String[SIZE];
      double [] rainfallList = new double[SIZE];
      
         //User populates city array   
      for(int i = 0; i < rainfallList.length; i++) {
      
         System.out.print("Enter the city's name: ");
         cityList[i] = console.next();
         
         if(rainfallList[i] >= 0) {
            System.out.print("Enter the city's rainfall: ");
            rainfallList[i] = console.nextDouble();
         } else {
            System.out.println("Invalid input");
            break;
         }
         
         System.out.println();
         
      }//End for loop  
         
         //Call printArray method
      printArray(cityList, rainfallList);
      
         //Call max index method
      int maxIndex = findMaxIndex(rainfallList);  
      
      System.out.println("\n\nMost rainfall: " + 
                          rainfallList[maxIndex] + " at index: " + (maxIndex));
      
      System.out.println("\nCities with most rainfall: ");
      
      for(int i = 0; i < rainfallList.length; i++) {
      
         if(rainfallList[i] == rainfallList[maxIndex]) {
            System.out.print(cityList[i] + " ");
         }
      
      }   
         //Call average rainfall method
      double average = rainfallAverage(rainfallList);
      System.out.printf("%n%nAverage Rainfall: %.2f", average);
      
      System.out.println("\n\nCities with rainfall below average: ");
      
      for(int i = 0; i < rainfallList.length; i++) {
         
         if(rainfallList[i] < average) {       
            System.out.print(cityList[i] + " ");        
         }
      
      }
      
      System.out.println("\n\nCities with rainfall above or equal to average: ");
      
      for(int i = 0; i < rainfallList.length; i++) {
      
         if(rainfallList[i] >= average) {           
            System.out.print(cityList[i] + " ");
         }
            
      }//End for loop
   
      
   }//End main
   
      //Print the 2 arrays
   public static void printArray(String[] cityList, double[] rainfallList) {
      
      System.out.println("City Name          Rainfall");
      System.out.println("***************************");
      
      for(int i = 0; i < rainfallList.length; i++) {
         
         System.out.printf("%-18s %-1s %n", cityList[i], rainfallList[i]);
      
      }//End for loop
   
   }//End groupArrays method
      
      //Max Index (rainfall)
   public static int findMaxIndex(double[] rainfallList) {
      
      int maxIndex = 0;    
      
      for(int i = 1; i < rainfallList.length; i++) {
         
         if(rainfallList[i] > rainfallList[maxIndex]) {
           
            maxIndex = i;  
             
         }
         
      }//End for loop
     
      return maxIndex;
   
   }//End max index method

      
      //Return avg rainfall of 10 cities
   public static double rainfallAverage(double[] rainfallList) {
      
      double average;
      double rainfallTotal = 0;
      
      for(int i = 0; i < rainfallList.length; i++) {
         
         rainfallTotal += rainfallList[i];   
         
      }//End for loop
   
      average = rainfallTotal / (double)SIZE;
      return average;
    
   }//End rainfallAverage method
        
}//End class