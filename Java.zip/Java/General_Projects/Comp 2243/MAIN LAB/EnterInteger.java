/*
     Author: Marcus Walbridge
     Date: 9-15-17
     Program: EnterInteger.java
     Description: Determine if an integers is positive, negative, or zero.  
                  Outpout the absolute value. 
*/

import java.util.Scanner;

public class EnterInteger
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
   
           //variables
      
      int integer, absoluteValue;
       
           //Prompt user to input data
      
      System.out.print("Enter an integer: ");
      integer = console.nextInt();
    
       
           //calculate
       
      if(integer < 0)
      {
         System.out.println("The integer " + integer + " is negative");
      }       
      else if(integer == 0)
      {
         System.out.println("The integer " + integer + " is zero");   
      }
      else if(integer > 0)
      {
         System.out.println("The integer " + integer + " is positive");
      }
       
      absoluteValue = Math.abs(integer);
       
       //output
       
      System.out.println("The absolute value is " + absoluteValue);                  
   }  
}