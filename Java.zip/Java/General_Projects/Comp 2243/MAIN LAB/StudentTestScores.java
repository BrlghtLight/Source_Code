/*
     Author: Marcus Walbridge
     Date: 9-20-17
     Program: StudentTestScores.java
     Description:
*/

import java.util.Scanner;

public class StudentTestScores
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int score, i, sum, largest;
      double average;
      
          //constants
      final int SIZE = 10;
      
      i = 0;
      sum = 0;
      largest = Integer.MIN_VALUE;
      
      
      while( i < SIZE )        
      {
          System.out.print("Enter a test score for student #" + (i+1) + ": ");
          score = console.nextInt();
          
          if(score >=0 && score <= 100)
          {
              sum += score;
              
              i++;
              
              if(largest < score)
              {
                  largest = score;
              }
          }
          else
          {
              System.out.println("\nInvalid score, try again.");
          }

      } //end while
      
      average = sum / (double)SIZE;
      
      System.out.printf("%nClass Average: %.2f", average);
      System.out.println("\nHighest Score: " + largest);
      
      
      
         
   }
}