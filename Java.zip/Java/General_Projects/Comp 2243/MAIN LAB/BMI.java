/*
     Author: Marcus Walbridge
     Date: 10-23-17
     Program: BMI.java
     Description: Take user input(weight and height) to find BMI.  
                  Use user-defined method to calculate and
                  return the value.  Classify it as either 
                  optimal, underweight, or overweight.
*/

import java.util.Scanner;

public class BMI
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
    
      //variables
      double weight, height, BMI = 0;
      int input = 0;
      
      //constants
      int SENTINEL = 1;
   
      do
      {                 
         System.out.print("\nEnter 1 to end: ");//To end the loop
         input = console.nextInt();
      
         System.out.print("\nEnter the weight in pounds: ");//collect information from user
         weight = console.nextDouble();
         
         System.out.print("Enter the height in inches: ");
         height = console.nextDouble();
         
         if(weight <= 0 || height <= 0)//validate the weight&&height.
         {
            System.out.println("Weight and height need" + 
                                " to be above 0, try again.");
         }
         else//call the user-defined method for the result
         {
            BMI = BMI( weight, height );
            System.out.printf("%nBMI: %.2f", BMI);
            
            if(BMI < 18.5)
            {
               System.out.println(", Underweight.");
            }
            else if( BMI >= 18.5 && BMI <= 25 )
            {
               System.out.println(", Optimal weight.");
            }
            else if(BMI > 25)
            {
               System.out.println(", Overweight.");
            }       
         }        
         System.out.println();         
      }
      while(input != SENTINEL);
      
   }//end main
   
   //method definition   
   public static double BMI (double weight, double height)
   {
      double result;
      result = (weight*703) / Math.pow(height, 2);
      
      return result;
   }
   
}
