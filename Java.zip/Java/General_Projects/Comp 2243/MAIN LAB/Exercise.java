/*
    Author: Marcus Walbridge 
    Date: 9-6-2017
    Program: Exercise.java
    Description: Pay wages 
*/

import java.util.Scanner;

public class Exercise
{
   public static void main(String[] args)
   {
      Scanner console = new Scanner(System.in);
        
        //variables
        
      int SECRET;
      double RATE;
        
      int num1, num2, newNum;
      String name;
      double hoursWorked, wages, newNum2;
        //constants 
                              
      SECRET = 11;
      RATE = 12.50;
            
        //Prompt user input of information
        
      System.out.print("Enter num1: ");
      num1 = console.nextInt();
      System.out.print("Enter num2: ");
      num2 = console.nextInt();
      System.out.print("Enter a last name: ");
      name = console.next();
      System.out.print("Enter hours worked: ");
      hoursWorked = console.nextDouble();
      
        
        
      newNum = (num1 * 2) + num2;
      newNum2 = newNum + SECRET;
      wages = RATE * hoursWorked;
        
        //output
        
      System.out.println("\n" + "If the value of num1 is " +  num1 +
                           "\n" + "and if the value of num2 is " +  num2  +
                           "\n" + "then the output is " + (num1 + num2));
        
      System.out.println("\n" + "newNum is equal to " + newNum);                   
      System.out.println("When adding the value of SECRET to newNum, the output is " + newNum2);   
        
      System.out.println("\n" + "Name: " + name +
                           "\n" + "Pay Rate: " + RATE +     
                           "\n" + "Hours worked: " + hoursWorked +
                           "\n" + "Salary: " + wages);      
                                  
        
   }
}                
