import java.util.Scanner; // Needed for the Scanner class
import java.util.Random;  // Needed for the Random class

/**
   This program demonstrates the Random class.
*/

public class MathTutor
{
   public static void main(String[] args)
   {
      int number1;      // A number
      int number2;      // Another number
      int sum = 0;          // The sum of the numbers
      int quotient = 0;
      int difference = 0;
      int remainder = 0;
      int product = 0;
      int userAnswer;   // The user's answer
      int operator = 0;
      
      // Create a Scanner object for keyboard input.
      Scanner keyboard = new Scanner(System.in);
      
      // Create a Random class object.
      Random randomNumbers = new Random();
   
      // Get two random numbers.
      number1 = randomNumbers.nextInt(100);
      number2 = randomNumbers.nextInt(100);
      
      //operator
      operator = randomNumbers.nextInt(4);
   
      switch (operator)
      {
      
         case '0':
           
            System.out.println("What is the answer to the " +
                         "following problem?");
            System.out.print(number1 + " + " +
                       number2 + " = ? ");     
         
            sum = number1 + number2;
            userAnswer = keyboard.nextInt();
            
            break; 
      
      
         case '3':
         
            System.out.println("What is the answer to the " +
                         "following problem?");
            System.out.print(number1 + " / " +
                       number2 + " = ? ");
            quotient = number1 / number2;
            userAnswer = keyboard.nextInt();
      
            break;
      
      
         case '2':
         
            System.out.println("What is the answer to the " +
                         "following problem?");
            System.out.print(number1 + " * " +
                       number2 + " = ? ");
            product = number1 * number2;
            userAnswer = keyboard.nextInt();
           
            break;
      
         case '4':
                    
            System.out.println("What is the answer to the " +
                         "following problem?");
            System.out.print(number1 + " % " +
                       number2 + " = ? ");
            remainder = number1 % number2;
            userAnswer = keyboard.nextInt();
            
            break;
      
         case '1':
                     
            System.out.println("What is the answer to the " +
                         "following problem?");
            System.out.print(number1 + " - " +
                       number2 + " = ? ");
            difference = number1 - number2;
            userAnswer = keyboard.nextInt();
          
            break;
      
      }//end switch
      
      
      // Get the user's answer.
      userAnswer = keyboard.nextInt();
   
      // Display the user's results.
      if (userAnswer == sum)
      {
         System.out.println("Correct!");
      }
      else
      {
         System.out.printf("Sorry, wrong answer. " +
                            "The correct answer is %d %d %d %d %d " +
                            sum, difference, product, quotient, remainder);
      }
   }
}
