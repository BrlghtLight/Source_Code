/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: 
     Description:
*/

import java.util.Scanner;

public class SpeedofSoundTwo
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
      
          //variables  
      String medium;
      double distance, time;
      
          //input
      System.out.print("Enter the medium (air, water, or steel): ");
      medium = console.next();
      
    
          
          //switch
      switch(medium)
      {               
          case "air": 
          
          System.out.print("Enter the distance travelled: ");
          distance = console.nextDouble();
          time = distance / 1100.0;
          System.out.printf("%nThe amount of time to travel is: %.3f", time);
          break;
          
          case "water":
          
          System.out.print("Enter the distance travelled: ");
          distance = console.nextDouble();
          time = distance / 4900.0;
          System.out.printf("%nThe amount of time to travel is: %.3f", time);
          break;
          
          case "steel":
          
          System.out.print("Enter the distance travelled: ");
          distance = console.nextDouble();
          time = distance / 16400.0;
          System.out.printf("%nThe amount of time to travel is: %.3f", time);
          break;
          
          default:
              System.out.println("Invalid medium");
      
      
      } 
       
       
       
       
       
       
       
         
   }
}