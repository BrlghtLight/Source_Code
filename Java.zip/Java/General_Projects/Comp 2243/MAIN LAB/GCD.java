/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: TestScore2.java
     Description: Sentinel control
*/

import java.util.Scanner;

public class GCD
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int m, n, r, temp;
      
          //input
      System.out.print("Enter a positive integer: ");
      m = console.nextInt();
      
      while(m <= 0)
      {
          System.out.println("Invalid input, try again");
          System.out.println("Enter a positive integer: ");
          m = console.nextInt();
      }
      
      System.out.print("Enter another positive integer: ");
      n = console.nextInt();
      
      while(n <= 0)
      {
          System.out.println("Invalid input, try again");
          System.out.println("Enter a positive integer: ");
          n = console.nextInt();
      }
      
          //make sure m is larger than n, swap if necessary
      if( m > n)
      {
         System.out.println("The value m is greater than n.");
      }
      else
      {
         temp = m;
         m = n;
         n = temp;
      }
          //calculate the greated common divisor of m and n
   
      r = m % n;
        
      while( r != 0 )
      {
         m = n;
         n = r;
         r = m % n;
      }  
          
      System.out.println("GCD is " + n);        
      
   }
}