/*
     Author: Marcus Walbridge
     Date: 10-11-2017
     Program: GPA.java
     Description: Calculate GPA as well as validating user inputs. Controlled by SENTINEL.  
*/

import java.util.Scanner;

public class GPA
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
    
      int gpEarned, hoursAttempted, count = 0, exit;
      double gpa, sum = 0, average;
      
          //constants
     
      final int SENTINEL = -1;
          
      do
      {
         System.out.print("Enter total grade points earned: ");
         gpEarned = console.nextInt();
      
         System.out.print("Enter the total credit hours attempted: ");
         hoursAttempted = console.nextInt();
          
         if( gpEarned < 0 || hoursAttempted < 0 )
         {
            System.out.println("Invalid input");
         }
         else
         {
            gpa = gpEarned / hoursAttempted;
            sum += gpa;
            System.out.printf("%nGPA: %.2f", gpa);
         }
          
         System.out.println(); 
         
         System.out.print("Enter -1 to exit or any other number to loop ");
         exit = console.nextInt();
           
         count++;
      }               
      while( exit != SENTINEL); 
          
      average = sum / (double)count;
      System.out.printf("%nAverage: %.2f", average);
   
   }
}