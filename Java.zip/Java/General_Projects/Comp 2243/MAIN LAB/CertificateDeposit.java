/*
     Author: Marcus Walbridge
     Date:
     Program: CertificateDeposit.java
     Description:
*/

import javax.swing.*; //components 
import java.awt.*; //container
import java.awt.event.*; //events

public class CertificateDeposit extends JFrame {
   
      //labels
   private JLabel amountLabel;
   private JLabel yearLabel;
   private JLabel interestLabel;
   private JLabel maturityLabel;
   
      //fields
   private JTextField amountField;
   private JTextField yearField;
   private JTextField interestField;
   private JTextField maturityField;
   
      //buttons
   private JButton calculateButton;
   private JButton exitButton;
   
      //frame constants
   private static final int WIDTH = 400; 
   private static final int HEIGHT = 300;
   
      //declare object button handlers
   private CalculateButtonHandler cbHandler;
   private ExitButtonHandler ebHandler;
   
      //constructor
   public CertificateDeposit() {
      
         //create the labels
      amountLabel = new JLabel("Amount to deposit: ", SwingConstants.RIGHT);
      yearLabel = new JLabel("Duration in years: ", SwingConstants.RIGHT);   
      interestLabel = new JLabel("Interest Rate: ", SwingConstants.RIGHT);
      maturityLabel = new JLabel("Value on maturity: ", SwingConstants.RIGHT);
         
         //create text fields
      amountField = new JTextField(10);
      yearField = new JTextField(10);
      interestField = new JTextField(10);
      maturityField = new JTextField(10);
      
         //create buttons
      calculateButton = new JButton("Calculate");
      exitButton = new JButton("Exit");
      
         //Retrieve content pane 
      Container pane = getContentPane();
      
         //Create grid layout
      pane.setLayout(new GridLayout(5, 2));
      
         //add components
      pane.add(amountLabel);
      pane.add(amountField);
      pane.add(yearLabel);
      pane.add(yearField);
      
      pane.add(interestLabel);
      pane.add(interestField);  
      pane.add(maturityLabel);
      pane.add(maturityField);
      
      pane.add(calculateButton);
      pane.add(exitButton);
      
      maturityField.setEnabled(false);
      
         //create button handler object
      cbHandler = new CalculateButtonHandler();
      ebHandler = new ExitButtonHandler();
      
         //event registration
      calculateButton.addActionListener(cbHandler);
      exitButton.addActionListener(ebHandler);
      
         //customize frame
      setTitle("Certificate of Deposit");
      setSize(WIDTH, HEIGHT);     
      setVisible(true);
         
         //close the program gracefully
      setDefaultCloseOperation(EXIT_ON_CLOSE); 
   }
   
      //private class, calculate button event
   private class CalculateButtonHandler implements ActionListener {
      
      public void actionPerformed(ActionEvent e) {
         
            //retrieve data from text fields
         double amount;
         double interest;
         double maturity;
         int years;
         
         amount = Double.parseDouble(amountField.getText());
         years = Integer.parseInt(yearField.getText());
         interest = Double.parseDouble(interestField.getText());
         
            //calculate
         maturity = amount * (Math.pow((1 + (interest / 100)), years));
         
            //print result
         maturityField.setText("$" + String.format("%.2f", maturity));
         
      }//end actionPerformed method
      
   }//end CalculateButtonHandler class
   
      //private class, exit button event
   private class ExitButtonHandler implements ActionListener {
      
      public void actionPerformed(ActionEvent e) {
         
         System.exit(0);
         
      }//end actionPerformed method
      
   }//end ExitButtonHandler class
   
   public static void main(String [] args) {
     
        //create a CertificateDeposit object
      CertificateDeposit mainFrame = new CertificateDeposit();
   
   }//end main
    
}//end while