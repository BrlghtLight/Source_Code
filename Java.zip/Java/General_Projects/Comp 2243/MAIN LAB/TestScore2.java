/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: TestScore2.java
     Description: Sentinel control
*/

import java.util.Scanner;

public class TestScore2{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int score, i, sum, largest;
      double average;
      
          //constants
      final int SENTINEL = -1;
      
      i = 0;
      sum = 0;
      largest = Integer.MIN_VALUE;
          
          //input first test score
      System.out.print("Enter a test score for student #" + (i+1) + ": ");
      score = console.nextInt();
      
      while( score != SENTINEL )        
      {
         if(score >=0 && score <= 100)
         {
            sum += score;
              
            i++;
              
            if(largest < score)
            {
               largest = score;
            }
         }
         else
         {
            System.out.println("\nInvalid score, try again.");
         }
         
         //input first test score
      System.out.print("Enter a test score for student #" + (i+1) + ": ");
      score = console.nextInt();
      
      } //end while
      
      average = sum / (double)i;
      
      System.out.println("Number of students: " + i);
      System.out.printf("%nClass Average: %.2f", average);
      System.out.println("\nHighest Score: " + largest);
      
      
      
         
   }
}