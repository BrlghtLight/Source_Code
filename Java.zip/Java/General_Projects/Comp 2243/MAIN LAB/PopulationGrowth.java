/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: TestScore2.java
     Description: Sentinel control
*/

import java.util.Scanner;

public class PopulationGrowth
{   
   public static void main(String [] args)  
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      int populationA, populationB, year;
      double growthA, growthB;
      
          //input
      System.out.print("Enter city A population: ");
      populationA = console.nextInt();
      
      System.out.print("Enter city B population: ");
      populationB = console.nextInt();
      
      System.out.print("Enter city A growth rate: ");
      growthA = console.nextDouble();
      
      System.out.print("Enter city B growth rate: ");
      growthB = console.nextDouble();
      
          //how many years
      
      year = 0;
      
      while( populationA < populationB )
      {
         populationA = (int) (populationA * (1 + growthA / 100));
         populationB = (int) (populationB * (1 + growthB / 100));
         year ++;     
      }
      
      System.out.printf("%nAfter " + year + " years, %n" +
                        "city A population is %,d%n" +
                        "city B population is %,d%n", populationA, populationB);
      
   }
   
}