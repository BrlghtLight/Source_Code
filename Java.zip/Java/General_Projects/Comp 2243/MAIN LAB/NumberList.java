/*
     Author: Marcus Walbridge
     Date: 11-22-17
     Course: COMP 2243
     Program: NumberList.java
     Description: Create an array of 100 elements (int),
                  Use four user-defined methods to:
                  Out the array with 10 elements per line.
                  Return the mean of the array.
                  Find the max index.
                  Count and output the amount of 
                  single, double, and triple digit numbers.
                  Return the standard deviation of the array.
*/

import java.util.Random;
import java.util.Scanner;

public class NumberList
{
   static final int SIZE = 100; 
   public static void main(String [] args)
   { 
      Scanner console = new Scanner(System.in);       
      
         //Array data range 0-500
      final int ARRAY_RANGE = 501;
      
         //Create a Random object
      Random rand = new Random();
      
         //Declare and create an array of SIZE
      int [] myList = new int[SIZE];
      
         //Populate array with random numbers
      for(int i = 0; i < myList.length; i++) {
         myList[i] = rand.nextInt(ARRAY_RANGE); //0-500
      }
      
         //Call printArray method
      printArray(myList);
      
         //Call findMean method
      double mean = findMean(myList);
      System.out.printf("%n%nMean: %.2f", mean);
      
         //Call maxIndex method
      int maxIndex = findIndexOfLargest(myList);  
      System.out.println("\n\nThe largest element in the array is " + 
                          myList[maxIndex] + " at index: " + maxIndex);
      
         //Call countNumber method
      int[] values = countNumber(myList);
      
      System.out.print("\n---------------------    ---------------------     ---------------------");
      System.out.println("\nSingle-digit Numbers:    Double-digit Numbers:     Triple-digit Numbers:");
      System.out.println("---------------------    ---------------------     ---------------------");
     
      for(int num : values) {
         System.out.print(num + "                        ");
      }
      
         //Call standardDeviation method
      double standardDeviation = standardDeviation(myList);
      System.out.printf("%n%nStandard Deviation: %.2f", standardDeviation);
              
   }//End main
   
      //Print array method
   public static void printArray(int [] myList) {
     
      for(int i = 0; i < myList.length; i++) {
         
         System.out.printf("%-5s", myList[i]);
         
         if((i+1) % 10 == 0) {
            if(i != 0) {
               System.out.println();
            }     
         } 
      }//End for loop
      
   }//End print array method
      
      //Find the mean method
   public static double findMean(int[] myList) {
   
      double mean = 0;
   
      for(int i = 0; i < myList.length; i++) {
         mean += myList[i]; 
      }
      
      mean = mean / (double)SIZE;     
      return mean;
      
   }//End mean method
           
      //Find index of largest val in array
   public static int findIndexOfLargest(int[] myList) {
      
      int maxIndex = 0;
      
      for(int i = 1; i < myList.length; i++) {
         
         if(myList[i] > myList[maxIndex]) {
           
            maxIndex = i;  
             
         }
         
      }//End for loop
     
      return maxIndex;
   
   }//End max index method

   public static int[] countNumber(int[] myList) {
         
         //Variables
      int singleDig = 0;
      int doubleDig = 0;
      int tripleDig = 0;      
      
         //Constants
      final int SINGDIGIT_CONDITION = 10;
      final int DOUBDIGIT_CONDITION = 100;
      final int DOUBDIGIT_CONDITION2 = 9;
      final int TRIPDIGIT_CONDITION = 99;
      
      for(int i = 0; i < myList.length; i++) {
         
         if(myList[i] < SINGDIGIT_CONDITION) {
            singleDig++;
         }  
         else if(myList[i] < DOUBDIGIT_CONDITION && myList[i] > DOUBDIGIT_CONDITION2) {
            doubleDig++;
         }
         else if(myList[i] > TRIPDIGIT_CONDITION) {
            tripleDig++;
         }
         
      }//End for loop
      
      int[] array = {singleDig, doubleDig, tripleDig};
      
      return array;
      
   }//End countNumber method
   
      //Standard deviation method
   public static double standardDeviation(int[] myList) {
   
      double standardDeviation;
      double mean = findMean(myList);
      double sd = 0;
      
      for(int i = 0; i < myList.length; i++) {
                             
         sd += Math.pow((myList[i] - mean), 2) / myList.length;
         
      }//End for loop
    
      standardDeviation = Math.sqrt(sd);
      return standardDeviation;
   
   }//End standardDeviation method
   
}//End class