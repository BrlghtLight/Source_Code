/*
     Author: Marcus Walbridge
     Date: 9-25-17
     Program: Discounts.java
     Description: Uses multiple selection to determine the values: 
                  discount and cost after discount.
*/

import java.util.Scanner;

public class Discounts
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
          //declare variables
      
      double purchaseAmount, discount, totalCost;
      
          //input
      
      System.out.print("Enter the purchase amount: $");
      purchaseAmount = console.nextDouble();
   
          //calculate    
     
      if( purchaseAmount <= 0 )
      {
         System.out.println("The purchase amount must be more than $0.00");
      }
      else 
      {
         if( purchaseAmount < 1000)
         {
            discount = 0.05 * purchaseAmount;
            totalCost = purchaseAmount - discount;
            
            System.out.println("Discount: $" + discount + 
                               "\nAnd your total expense is: $" + totalCost);
         }
         else if( purchaseAmount >= 1000 && purchaseAmount < 2000)
         {
            discount = 50 + (0.10 * purchaseAmount);
            totalCost = purchaseAmount - discount;
            
            System.out.println("Discount: $" + discount +
                               "\nAnd your total expense is: $" + totalCost);
         }
         else if( purchaseAmount >= 2000 && purchaseAmount < 3000)
         {
            discount = 100 + (0.15 * purchaseAmount);
            totalCost = purchaseAmount - discount;
            
            System.out.println("Discount: $" + discount + 
                               "\nAnd your total expense is: $" + totalCost);
         }
         else if( purchaseAmount >= 3000 && purchaseAmount < 4000)
         {
            discount = 250 + (0.20 * purchaseAmount);
            totalCost = purchaseAmount - discount;
            System.out.println("Discount: $" + discount + 
                               "\nAnd your total expense is: $" + totalCost);
         }
         else
         {
            discount = 0.25 * purchaseAmount;
            totalCost = purchaseAmount - discount;
            System.out.println("Discount: $" + discount + 
                               "\nAnd your total expense is: $" + totalCost);
         }
      
      }        
      
   }
   
}