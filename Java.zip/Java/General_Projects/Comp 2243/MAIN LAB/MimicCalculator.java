/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: MimicCalculator.java
     Description:
*/

import java.util.Scanner;

public class MimicCalculator
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
        
          //variables
      double number1, number2, result;
      char operator;
      
          //constants
      System.out.print("Enter the first value: ");
      number1 = console.nextDouble();
      
      System.out.print("Enter the second value: ");
      number2 = console.nextDouble();
      
      System.out.print("Enter the operator (+, - , *, or /): ");
      operator = console.next().charAt(0);    
      
          //use a switch structure
      switch( operator )
      {
         case '+':
          
            result = number1 + number2;         
            System.out.printf( number1 + " + " + number2 + " = %.2f", result);        
            break;
      
         case '-':
          
            result = number1 - number2;          
            System.out.printf( number1 + " - " + number2 + " = %.2f", result);           
            break;
      
         case '*':
          
            result = number1 * number2;          
            System.out.printf( number1 + " * " + number2 + " = %.2f", result);         
            break;
      
         case '/':          
            if( number2 != 0)
            {
               result = number1 / number2;         
               System.out.printf( number1 + " / " + number2 + " = %.2f", result);         
            }
            else
            {
               System.out.println("Cannot divide by 0.");
            }
            break;
      
         default:
            System.out.println("Invalid operator");
            
      }//end switch    
   
   }
}