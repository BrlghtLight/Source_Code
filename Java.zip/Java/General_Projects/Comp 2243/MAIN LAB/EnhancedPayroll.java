/*
     Author: Marcus Walbridge
     Date: 8-21-17
     Program: Payroll.java
     Description: Calculate the weekly pay for an hourly employee.
*/

import java.util.Scanner;

public class EnhancedPayroll
{
   public static void main(String [] args)
   
   {
      Scanner console = new Scanner(System.in);
      
       //declare variables
      String firstName, lastName;
      double hoursWorked, baseWage, pay;
      
       //constants
      final double REGULAR_HOURS = 40.0;
      final double OVERTIME_RATE = 1.5;
       
       //prompt the user to enter data
      System.out.print("Enter first name: ");
      firstName = console.next();
       
      System.out.print("Enter last name: ");
      lastName = console.next();
       
      System.out.print("Enter hours worked: ");
      hoursWorked = console.nextDouble();
       
      System.out.print("Enter base wage: ");
      baseWage = console.nextDouble();
           
           //calculate
      if(hoursWorked > 0 && baseWage > 0)
      {
                        
                      
                            
          if(hoursWorked <= REGULAR_HOURS)  //no overtime
          {              
          pay = hoursWorked * baseWage;
          }
          else    //overtime
          {
              pay = REGULAR_HOURS * baseWage + 
              OVERTIME_RATE * baseWage * (hoursWorked - REGULAR_HOURS);    
          }    
         
             //output the result
          System.out.println("\n" + firstName + " " + lastName +
                          ", your weekly pay is $" + pay + ",");
      }
      else
      { 
          System.out.println("\nInvalid input.");
      }     
   }
   
}