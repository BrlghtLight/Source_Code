/*
    Author: Marcus Walbridge
    Date: 9-4-2017
    Program: StudentPercentages.java
    Description: Calculates total students and what percentage each class makes up. (GUI)
*/

import javax.swing.JOptionPane;

public class StudentPercentages
{
   public static void main(String[] args)     
   {
      
      
      //Establish variables
      
      double CS, CIS, Bioinformatics, studentTotal, percentCS, percentCIS, percentBioinformatics;
      
      //Prompt user to enter info
      
      CS = Double.parseDouble(
                             JOptionPane.showInputDialog("Enter number of students in CS "));
     
      CIS = Double.parseDouble(
                             JOptionPane.showInputDialog("Enter number of students in CIS "));
      
      Bioinformatics = Double.parseDouble(
                             JOptionPane.showInputDialog("Enter number of students in Bioinformatics "));
      
      
      //calculate
      
      studentTotal = CS + CIS + Bioinformatics;
      percentCS = CS / studentTotal;
      percentCIS = CIS / studentTotal;
      percentBioinformatics = Bioinformatics / studentTotal;
      
      //output the information
      
      String result = "Total number of students is " + studentTotal + "\n" +
                      "Percentage of CS is " + percentCS + "\n" +
                      "Percentage of CIS is " + percentCIS + "\n" +
                      "Percentage of Bioinformatics is " + percentBioinformatics;
      JOptionPane.showMessageDialog( null, result );
      
      System.exit(0);
      
   }
}
