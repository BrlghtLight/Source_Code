/*
     Author: Marcus Walbridge
     Date: 
     Program: RightTriangle.java
     Description: 
*/

import java.util.Scanner;

public class RightTriangle
{
   public static void main(String [] args)
   
   {
       
      Scanner console = new Scanner(System.in);       
      
          //variables
      
      double side1, side2, side3;
      
      while(true)
      {
      
         System.out.print("\nEnter side 1(-1 to exit): ");
         side1 = console.nextDouble();
         
         if(side1==-1)
         {
            break;
         }
      
         System.out.print("Enter side 2: ");
         side2 = console.nextDouble();
      
         //call the method
         
         if(side1 > 0 && side2 > 0)
         {
            side3 = hypotenuse( side1, side2 );        
            System.out.printf("Side3: %.2f", side3);
         }
         else
         {
            System.out.println("Error, try again");
         }
      }
   }//end main
   
    //method definition
    //calculate the side 3 of a right triangle
    
   public static double hypotenuse( double side1, double side2 )
   {
      double side3;
       
      side3 = Math.sqrt( Math.pow(side1, 2) + Math.pow(side2, 2) );
       
      return side3;
   }
    
}//end class