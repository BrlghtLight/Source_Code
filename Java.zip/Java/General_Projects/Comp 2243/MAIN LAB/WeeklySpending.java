/*
     Author: Marcus Walbridge
     Date: 8-23-17
     Program: MilkCarton.java
     Description: Calculate the cartons needed, and the cost, and the profit.
*/

import java.util.Scanner;

public class WeeklySpending
{
   static final int CATEGORY_SIZE = 3;
   static final int WEEK_SIZE = 7;
   static Scanner console = new Scanner(System.in);
   public static void main(String [] args)
   { 
         //create a 3x7 table
      double [][] spendingTable = new double[CATEGORY_SIZE][WEEK_SIZE];       
         
      String [] category = {"Food", "Gas", "Misc"};
      String [] dayOfWeek = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
      
         //call inputData
      inputData(spendingTable, category, dayOfWeek);
         
         //call printData
      printData(spendingTable, category, dayOfWeek);
         
         //call totalSpending
      totalSpending(spendingTable, category);
         
         //call largestSpending
      largestSpending(spendingTable, category);
   
   }//end main
   
      //input data method
   public static void inputData(double [][] spendingTable, String [] category, String [] dayOfWeek) {
     
      for(int i = 0; i < spendingTable.length; i++) {
         
         System.out.println("\nEnter daily spending on " + category[i]);
                  
         for(int x = 0; x < spendingTable[i].length; x++) {
            
            System.out.print(dayOfWeek[x] + ": $");
            spendingTable[i][x] = console.nextDouble();   
         
         }//end nested loop
      
      }//end first loop
   
   }//end inputData method
   
     //print table
   public static void printData(double [][] spendingTable, String [] category, String [] dayOfWeek) {
      
      System.out.printf("%-23s", " ");
         
         //print day
      for(int i = 0; i < dayOfWeek.length; i++) {
         
         System.out.print(dayOfWeek[i] + "    ");
         
      }//end for loop
       
      System.out.println(); 
      
      for(int i = 0; i < spendingTable.length; i++) {
         
         System.out.printf("%n%-20s", category[i]); 
         
         for(int x = 0; x < spendingTable[i].length; x++) {   
            
            System.out.printf("%7.2f", spendingTable[i][x]);
            
         }//end nested loop
      
      }//end first loop
   
   }//end printData method
   
      //totalSpending method
   public static void totalSpending(double [][] spendingTable, String [] category) {
   
      double sum, overall = 0;
   
      for(int i = 0; i < spendingTable.length; i++) {
         
         sum = 0;
         
         for(int x = 0; x < spendingTable[i].length; x++) {   
            
            sum += spendingTable[i][x];
            
         }//end nested loop
         
         System.out.println();
         
         System.out.printf("Total spending on " + category[i] + ": %.2f", sum);
         System.out.println();
         
         overall += sum;
         
      }//end first loop
    
      System.out.printf("Overall Spending: $%.2f", overall);
      System.out.println();
       
   }//end totalSpending method
    
    //largestSpending method
   public static void largestSpending(double [][] spendingTable, String [] category) {
       
      int maxIndex; //column index
       
      for(int i = 0; i < spendingTable.length; i++) {
         
         maxIndex = 0;
         
         for(int x = 1; x < spendingTable[i].length; x++) {   
            
            if(spendingTable[i][x] > spendingTable[i][maxIndex]) {
             
               maxIndex = x;   
            
            }   
            
         }//end nested loop
         
         System.out.println("\nThe largest spending on " + category[i] + ": $" + spendingTable[i][maxIndex]);
         
      }//end first loop
   
   }//end largestSpending method
   
}//end class