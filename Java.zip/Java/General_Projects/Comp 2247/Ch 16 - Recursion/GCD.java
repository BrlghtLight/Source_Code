import java.util.*;

public class GCD

{

   static Scanner console = new Scanner(System.in);

   public static void main(String [] args)
   
   {
   
       //variables
      int m;
      int n;
      int result;
       
      System.out.print("Enter m or n: ");
      m = console.nextInt();
      n = console.nextInt();
       
      result = calculateGCD(m, n);
       
      System.out.println("GCD: " + result);
   
   }//end main
 
   public static int calculateGCD(int m, int n) {
      
      int r;
         
      r = m % n;
         
      if(r == 0) {
            
         return n;
            
      } else {
      
         return calculateGCD(n, r);
      
      }
   
   }//end calculcate GCD
 
}//end class
