/*
Author: Marcus Walbridge
Date: 03-02-2018
Course: Comp 2247
Program: RecursiveCommittee.java
Description: Collect user input for total people 
             & total people in a committee; use exception handling
             and recursion to make sure correct info is inputted and 
             total number of possible committees is calculated
*/

import java.util.*;

public class RecursiveCommittee

{

   static Scanner console = new Scanner(System.in);

   public static void main(String [] args)
   
   {
   
       //variables
      int result;
      int totalPeople = 0;
      int totalCommittee = 0;
      boolean flag = true;
      
      while(flag) {
        
         try {    
         
         //collect user input
            System.out.print("\nEnter number of people to choose from: ");
            totalPeople = console.nextInt();
         
            if(totalPeople < 0) {                  
               throw new Exception("n");
            }
            
            flag = false;
               
         } catch(InputMismatchException e) {
                  
            console.next();
            System.out.print("\nInvalid input, enter a number\n");        
               
         } catch(Exception e) {
               
            System.out.println("\n" + e.toString());
            char errorCode = e.toString().charAt(e.toString().length()-1);
               
            if(errorCode == 'n') {        
               System.out.println("\nNumber of people cannot be negative");                    
            }
         } 
      
      }//end while
      
      //reinitialize flag
      flag = true;
      
      while(flag) {
      
         try {
         
         //collect user input
            System.out.print("\nEnter number of people in the committee: ");
            totalCommittee = console.nextInt();
         
            if(totalCommittee < 0) {                  
               throw new Exception("n");
            }
              
            flag = false;
               
         } catch(InputMismatchException e) {
                  
            console.next();
            System.out.print("\nInvalid input, enter a number\n");        
               
         } catch(Exception e) {
               
            System.out.println("\n" + e.toString());
            char errorCode = e.toString().charAt(e.toString().length()-1);
               
            if(errorCode == 'n') {        
               System.out.println("\nNumber of people cannot be negative");                    
            }
         
         } 
      
      }//end while
      
      result = computeCommittee(totalPeople, totalCommittee);
      
      if(result > 1) {
      System.out.println("\n----------------------------------------"
                         + "\nThe answer is: " + result + " different committees");
      } else {
         System.out.println("\n----------------------------------------"
                            + "\nThe answer is: " + result + " possible committee");
      }
   }//end main
 
   public static int computeCommittee(int totalPeople, int totalCommittee) {
                                
      if(totalCommittee == totalPeople || totalCommittee == 0) {
         return 1;
      } else if(totalCommittee > totalPeople) {
         return 1;
      } else {
         return computeCommittee(totalPeople - 1, totalCommittee - 1) + computeCommittee(totalPeople - 1, totalCommittee);
      }
      
   }//end computeCommittee
 
}//end class
