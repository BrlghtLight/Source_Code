/*
Author: Marcus Walbridge
Date: 03-02-2018
Course: Comp 2247
Program: RecursiveMethods.java
Description: Collect user input and 
             call two recursive methods to solve two problems:
             multiply by adding repeatedly &
             adding recursively (Example: if 3, 1 + 2 + 3 = result).
*/

import java.util.*;

public class RecursiveMethods {

   static Scanner console = new Scanner(System.in);
    
   public static void main(String [] args) {
      
      //declare variables    
      int n1;
      int n2;
      int result;
      
      //collect user input
      System.out.print("Enter number 1: ");
      n1 = console.nextInt();
      
      System.out.print("Enter number 2: ");
      n2 = console.nextInt();
      
      //first recursive call
      result = calProduct(n1, n2);
      System.out.println("\nResult: " + result + "\n");
        
      //collect user input for calSum
      System.out.print("Enter a number: ");
      n1 = console.nextInt();
      
      if(n1 >= 0) {
         result = calSum(n1);
      
         System.out.println("\nResult: " + result + "\n");
         System.out.print("--- Operations Complete ---");
      } else {
         System.out.println("\n- Integer cannot be negative, Try again -");
      }
      
   }//end main
    
   public static int calProduct(int n1, int n2) {
    
      if (n1 == 0 || n2 == 0) {
         return 0;
      }
      
      else if( n2 < 0 ) {
         return - n1 + calProduct(n1, n2 + 1);
      } else {
         return n1 + calProduct(n1, n2 - 1);
      }
       
   }//end calProduct

   public static int calSum(int n1) {
   
      if(n1 == 0) {
      
         return 0;
      
      } else {
         
         return n1 + calSum(n1 - 1);
         
      }
   
   }//end calSum 

}//end class