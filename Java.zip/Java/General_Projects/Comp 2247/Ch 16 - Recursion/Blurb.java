import java.util.*;

public class Blurb {

   private Random rand;
      
      //constructor
   public Blurb() {
      rand = new Random();
   }

   public static void main(String [] args) {   
      Blurb alien = new Blurb();   
      System.out.println(alien.generateBlurb());  
   }//end main
   
   public String generateBlurb() {
      //stringbuilder is mutable
      StringBuilder blurb = new StringBuilder();
      
      blurb.append(getWhoozit());
      blurb.append(getWhatzits());
      
      return blurb.toString();
   }
   
   public String getWhoozit() {
      StringBuilder whoozit = new StringBuilder();
      whoozit.append("x");
      whoozit.append(getYs());
      
      return whoozit.toString();
   }
   
   public String getYs() { 
      StringBuilder y = new StringBuilder();
      
      boolean stop = rand.nextBoolean(); //random boolean
      
      if(!stop) {
         //recursive call to getYs()
         y.append(getYs());
      } else {
         return y.toString();
      }
      
      y.append("y");
      
      return y.toString();
   
   }//end getYs()

   public String getWhatzits() {
      StringBuilder whatzits = new StringBuilder();
      whatzits.append(getWhatzit());
      boolean stop = rand.nextBoolean();
      
      if(!stop) {
         //recursive
         whatzits.append(getWhatzits());
      } else {
         return whatzits.toString();
      }
      
      return whatzits.toString();
      
   }//end getWhatzits() 

   public String getWhatzit() {
      StringBuilder whatzit = new StringBuilder();
      whatzit.append("q");
      boolean flag = rand.nextBoolean();
      if(flag) {
         whatzit.append("z");
      } else {
         whatzit.append("d");
      }
      whatzit.append(getWhoozit());
      return whatzit.toString();
   }//end getWhatzit()

}//end class