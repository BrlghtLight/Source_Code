import java.util.*;

public class PowerOfInteger

{

   static Scanner console = new Scanner(System.in);

   public static void main(String [] args)
  
   {
    
      int base, exponent, answer;
       
      System.out.print("Enter Base: ");
      base = console.nextInt();
      
      System.out.print("Enter Exponent: ");
      exponent = console.nextInt();
      
      answer = power (base, exponent);
      
      System.out.println("Answer: " + answer);

                         
   }//end main

   public static int power(int base, int exponent) {
   
      if(exponent == 1) 
      
         return base;
      
      else if(exponent == 0) 
      
         return 1;
         return base * power(base, exponent - 1); 
      
      
   
   }
    
}//end class
