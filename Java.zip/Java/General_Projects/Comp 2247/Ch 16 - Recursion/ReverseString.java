import java.util.*;

public class ReverseString {

   static Scanner console = new Scanner(System.in);
    
   public static void main(String [] args) {
    
      String string;
    
      System.out.print("Enter: ");
      string = console.next();
    
      reverse(string, 0, string.length());      
            
   }//end main
    
   public static void reverse(String string, int index, int size) {
    
     if((size - index) == 1) {
     
        System.out.print(string.charAt(index));
     
     } else {
     
        reverse(string, index + 1, size);
        System.out.print(string.charAt(index));
        
     }
    
   }//end reverse

}//end class