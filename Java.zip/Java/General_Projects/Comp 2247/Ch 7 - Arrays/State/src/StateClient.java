/*
 *Author: Marcus Walbridge  
 *Date: 1/22/2018
 *Assignment: Assignment #1
 *Description: Console Client Program for StateProject
 *             Allow user to output all state information
 *             Calculate and output total population of all state
 *             Find and output the state with the largest population
 *             Capable of searching for a specific state
 *             Sort all states into regions and output them in lists
 */

import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;
import java.util.ArrayList;

public class StateClient {

    public static void main(String[] args) throws IOException {

        Scanner console = new Scanner(System.in);

        //Create inventory array
        ArrayList<State> stateList = new ArrayList<State>();

        String inputFileName;

        while (true) {
            JFileChooser open = new JFileChooser("./");
            int status = open.showOpenDialog(null);

            if (status == JFileChooser.APPROVE_OPTION) {
                //open button is clicked
                inputFileName = open.getSelectedFile().getAbsolutePath();
                break;
            }

        }//End while loop

        //Read data from the data file
        Scanner inFile = new Scanner(new FileReader(inputFileName));

        //Remove the data file headings
        for (int i = 0; i < 8; i++) {
            inFile.next();
        }

        //variables
        String stateName;
        String abbreviation;
        String capital;
        String nickName;
        String region;

        int year;
        int population;
        int area;
        int input;

        boolean flag = true;

        //Read data, create object, and populate the array
        while (inFile.hasNext()) {
            stateName = inFile.next();
            abbreviation = inFile.next();
            capital = inFile.next();
            nickName = inFile.next();
            year = inFile.nextInt();
            population = inFile.nextInt();
            area = inFile.nextInt();
            region = inFile.next();

            //create object
            stateList.add(new State(stateName, abbreviation, capital, nickName,
                    year, population, area, region));

        }//End while loop

        while (flag) {

            showMenu();
            System.out.print("Enter a command (Numbers 1-10, 0): ");
            input = console.nextInt();

            switch (input) {
                case 1:

                    System.out.printf("%nState Name:      "
                            + "Abbreviation:   "
                            + "Capital:          "
                            + "Nick Name:            "
                            + "Year:   "
                            + "Population     "
                            + "Area:       "
                            + "Region:      "
                            + "Density:%n%n");

                    for (int i = 0; i < stateList.size(); i++) {

                        System.out.println(stateList.get(i).toString().replaceAll("_", " ")
                                + ",    " + stateList.get(i).calculateDensity());

                    }//end for loop

                    break;

                case 2:

                    System.out.println("\n****************************************");
                    System.out.println("Total Population: " + calculateTotalPop(stateList));
                    System.out.println("****************************************");

                    break;

                case 3:

                    System.out.println("\n****************************************");

                    System.out.println("State with Largest Population: \n" + "\nState Name:      "
                            + "Abbreviation:   "
                            + "Capital:          "
                            + "Nick Name:            "
                            + "Year:   "
                            + "Population    "
                            + "Area:       "
                            + "Region:       "
                            + "Density:\n"
                            + stateList.get(findMaxPopulation(stateList))
                                    .toString().replaceAll("_", " ")
                            + "    " + stateList.get(findMaxPopulation(stateList)).calculateDensity());

                    System.out.println("****************************************");

                    break;

                case 4:

                    System.out.println("\n****************************************");
                    System.out.print("Enter a State to search: ");

                    String searched = console.next();
                    int foundIndex = search(stateList, searched);

                    if (foundIndex == -1) {

                        System.out.println(searched + " is not found.");

                    } else {

                        System.out.print("\nState Name:      "
                                + "Abbreviation:   "
                                + "Capital:          "
                                + "Nick Name:            "
                                + "Year:   "
                                + "Population   "
                                + "Area:         "
                                + "Region:      "
                                + "Density:\n");
                        System.out.println(stateList.get(foundIndex).toString().replaceAll("_", " ")
                                + "  "
                                + stateList.get(foundIndex).calculateDensity());

                    }
                    System.out.println("****************************************");

                    break;

                case 5:

                    //Regions' states print out in vertical list vs. 
                    //horizontal list
                    System.out.println("");
                    regions(stateList);

                    break;

                case 6:
                    quickSortPopulationAscending(stateList, 0, stateList.size() - 1);
                    System.out.println("\nSorted");
                    break;

                case 7:
                    selectionSortPopulationDescending(stateList);
                    System.out.println("\nSorted");
                    break;

                case 8:
                    quickSortCapitalAscending(stateList, 0, stateList.size() - 1);
                    System.out.println("\nSorted");
                    break;

                case 9:
                    selectionSortCapitalDescending(stateList);
                    System.out.println("\nSorted");
                    break;

                case 10:

                    quickSortCapitalAscending(stateList, 0, stateList.size() - 1);

                    System.out.print("Enter a capital to search: ");
                    String key = console.next();

                    foundIndex = binarySearchRecursion(stateList, 0, stateList.size() - 1, key);

                    System.out.println("Found Item @ Index: " + foundIndex);
                    System.out.println(stateList.get(foundIndex).toString());

                    break;

                case 0:

                    flag = false;

                    break;

                default:

                    System.out.println("\n****************************************");
                    System.out.println("\nError, Invalid entry, "
                            + "Please try again.");
                    System.out.println("\n****************************************");

                    break;

            }//End switch

        }//end while

    }//end main   

    //calculate total population
    public static int calculateTotalPop(ArrayList<State> stateList) {

        int totalPopulation = 0;

        for (int i = 0; i < stateList.size(); i++) {
            totalPopulation += stateList.get(i).getPopulation();
        }

        return totalPopulation;

    }//end calculateTotalPop

    //find largest population
    public static int findMaxPopulation(ArrayList<State> stateList) {

        int maxPopulationIndex = 0;

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(maxPopulationIndex).getPopulation()
                    < stateList.get(i).getPopulation()) {

                maxPopulationIndex = i;

            }

        }//end for loop

        return maxPopulationIndex;

    }//end findMaxPopulation

    //search method
    public static int search(ArrayList<State> stateList, String searched) {

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getStateName().equalsIgnoreCase(searched)) {
                return i;
            }

        }//end for loop

        return -1;

    }//end search method

    //print regions method
    public static void regions(ArrayList<State> stateList) {

        int stateCount = 0;

        final String REGION_1;
        final String REGION_2;
        final String REGION_3;
        final String REGION_4;
        final String REGION_5;
        final String REGION_6;
        final String REGION_7;

        REGION_1 = "South_Central";
        REGION_2 = "Pacific";
        REGION_3 = "Mountain";
        REGION_4 = "New_England";
        REGION_5 = "Middle_Atlantic";
        REGION_6 = "South_Atlantic";
        REGION_7 = "North_Central";

        System.out.println("\n****************************************");
        System.out.println(REGION_1 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_1)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_1);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_2 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_2)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_2);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_3 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_3)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_3);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_4 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_4)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_4);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_5 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_5)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_5);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_6 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_6)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_6);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_7 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_7)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_7);

    }//end regions method

    //quick sort
    public static void quickSortPopulationAscending(ArrayList<State> stateList, int left, int right) {
        if (left < right) {
            int q = partitionPopulationAscending(stateList, left, right);
            quickSortPopulationAscending(stateList, left, q);
            quickSortPopulationAscending(stateList, q + 1, right);
        }
    }//end quickSort

    //partition method
    public static int partitionPopulationAscending(ArrayList<State> stateList, int left, int right) {
        int x = stateList.get(left).getPopulation(); //pivot
        int i = left - 1;
        int j = right + 1;

        while (true) {
            j--;
            while (stateList.get(j).getPopulation() > x) {
                j--;
            }

            i++;

            while (stateList.get(i).getPopulation() < x) {
                i++;
            }
            if (i < j) {
                State temp = stateList.get(j);
                stateList.set(j, stateList.get(i));
                stateList.set(i, temp);
            } else {
                return j;
            }
        }//end while

    }//end partition method

    public static void selectionSortPopulationDescending(ArrayList<State> stateList) {

        int index = 0;

        for (int x = 0; x < stateList.size() - 1; x++) {

            index = x;

            for (int i = x + 1; i < stateList.size(); i++) {

                if (stateList.get(i).getPopulation() > stateList.get(index).getPopulation()) {
                    index = i;
                }

            }//end for loop

            //swap
            State temp = stateList.get(x);
            stateList.set(x, stateList.get(index));
            stateList.set(index, temp);

        }//end for loop 

    }//end selectionSort method

    //quick sort
    public static void quickSortCapitalAscending(ArrayList<State> stateList, int left, int right) {
        if (left < right) {
            int q = partitionCapitalAscending(stateList, left, right);
            quickSortCapitalAscending(stateList, left, q);
            quickSortCapitalAscending(stateList, q + 1, right);
        }
    }

    //partition method
    public static int partitionCapitalAscending(ArrayList<State> stateList, int left, int right) {
        String x = stateList.get(left).getCapital(); //pivot
        int i = left - 1;
        int j = right + 1;

        while (true) {
            j--;
            while (stateList.get(j).getCapital().compareToIgnoreCase(x) > 0) {
                j--;
            }

            i++;

            while (stateList.get(i).getCapital().compareToIgnoreCase(x) < 0) {
                i++;
            }
            if (i < j) {
                State temp = stateList.get(j);
                stateList.set(j, stateList.get(i));
                stateList.set(i, temp);
            } else {
                return j;
            }
        }//end while

    }//end partition method

    public static void selectionSortCapitalDescending(ArrayList<State> stateList) {

        int index;

        for (int x = 0; x < stateList.size() - 1; x++) {

            index = x;

            for (int i = x + 1; i < stateList.size(); i++) {

                if (stateList.get(i).getCapital().compareToIgnoreCase(stateList.get(index).getCapital()) > 0) {
                    index = i;
                }

            }//end for loop

            //swap
            State temp = stateList.get(x);
            stateList.set(x, stateList.get(index));
            stateList.set(index, temp);

        }//end for loop 

    }//end selectionSort method

    //binary search
    public static int binarySearchRecursion(ArrayList<State> stateList, int left, int right, String key) {

        int middle = (left + right) / 2;

        int foundIndex = -1;

        if (stateList.get(middle).getCapital().compareToIgnoreCase(key) == 0) {

            foundIndex = middle;

        } else if (key.compareToIgnoreCase(stateList.get(middle).getCapital()) < 0) {
            if (left <= middle - 1) {
                foundIndex = binarySearchRecursion(stateList, left, middle - 1, key);
            }
        } else {
            if (right >= middle + 1) {
                foundIndex = binarySearchRecursion(stateList, middle + 1, right, key);
            }
        }

        return foundIndex;

    }//end binary search

    //create state program menu
    private static void showMenu() {

        System.out.print("\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
                + "\n"
                + "1 --- Output the US state information\n"
                + "2 --- Output the total population\n"
                + "3 --- Find the state with the largest population\n"
                + "4 --- Search a state and output its information\n"
                + "5 --- Output states in each region\n"
                + "6 --- Sort the state list based on the population in ascending order\n"
                + "7 --- Sort the state list based on the population in descending order\n"
                + "8 --- Sort the state list based on the capital name in ascending order\n"
                + "9 --- Sort the state list based on the capital name in descending order\n"
                + "10 -- Search the state list based on the capital name and output the state information\n"
                + "0 --- Exit\n"
                + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

    }//end showMenu

}//end class
