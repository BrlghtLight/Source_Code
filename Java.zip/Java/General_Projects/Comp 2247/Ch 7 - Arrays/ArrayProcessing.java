import java.util.*;

public class ArrayProcessing
{
   public static void main(String [] args)
   {
      Scanner console = new Scanner(System.in);
   	  
      Random rand = new Random();
   	  
      int [] list = new int[25];
   
      for (int i = 0; i < list.length; i++)
      {
            //list[i] = (int)(Math.random() * 500 +1);
         list[i] = rand.nextInt(500) + 1;    //0 to 499, 1 to 500
      }
   	  
      System.out.println("\nAll Elements:\n");
      printArray( list );
      
         //call average method
      System.out.println();
      System.out.printf("\nAverage: %.2f", calculateArray(list));
   			  
         //call indexOfSmallest
      int minIndex = indexOfSmallest(list);
      
      System.out.println();
      System.out.println("Smallest Value: " + list[minIndex] + 
                         " at index " + minIndex);  
        //call countEven
      System.out.println("Even Elements: " + evenNumbers(list));
                         
   }//end main

   public static void printArray(int[] list)
   {
      for (int i = 0; i < list.length; i++)
         System.out.print(list[i] + " ");
   }
    
      //calculate and return the average value of the array of elements
   public static double calculateArray(int[] list) {
      int total = 0;      
      
      for(int i = 0; i < list.length; i++) {
         total += list[i];
         
      }//end for loop
      
      return total / (double)list.length;
      
   }//end calculateArray
   
      //find the index of the smallest value in the array
   public static int indexOfSmallest(int[] list) {
      int minIndex = 0;
     
      for(int i = 0; i < list.length; i++) {
         
         if(list[i] < list[minIndex]) {
            
            minIndex = i;
            
         }
            
      }//end for loop
      
      return minIndex;
      
   }//end indexOfSmallest
   
      //count even number elements
   public static int evenNumbers(int[] list) {
      int evenCount = 0;
      
      for(int i = 0; i < list.length; i++) {
         
         if(list[i] % 2 == 0) {
            evenCount++;
               
         }
         
      }//end for loop
      
      return evenCount;
      
   }//end evenNumbers 
    
}//end main
