import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

public class SearchNames

{

   public static void main(String [] args) throws IOException

   {

      Scanner console = new Scanner(System.in);
   	  
         //create an ArrayList for girl names
      ArrayList<String> girlNameList = new ArrayList<String>();
      
         //retrieve the command list argument
      String girlNameFile = args[0];
      
         //call readData method to populate girlNameList
      readData( girlNameList, girlNameFile );
      
      System.out.print("Enter a girl's name to search: ");
      String name = console.next();
      
         //call search method
      int foundIndex = search(girlNameList, name);
      
      if(foundIndex == -1) {
        
         System.out.println("Not found");
      
      } else {
         
         System.out.println("Found at index " + foundIndex);
      
      }
   
   } //end main
   
   
      //readData method
   private static void readData(ArrayList list, String fileName) throws IOException {
      
       Scanner inFile = new Scanner( new File(fileName) );
       
       while(inFile.hasNext()) {
        
            //read a name and place it into the array list
          list.add(inFile.next());
          
       }
       
       inFile.close();
   }
   
      //search method
   private static int search(ArrayList list, String name) {
   
      for(int i=0; i<list.size(); i++) {
     
         if(list.get(i).toString().equalsIgnoreCase(name)) {
            return i; //found
     
         }
     
      }//end for loop
      
      return -1; //not found
  
   }//end search method

}//end class