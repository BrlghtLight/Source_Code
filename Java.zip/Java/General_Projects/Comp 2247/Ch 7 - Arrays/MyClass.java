public class MyClass implements SomeInterface {

   //MyClass must provide code blocks for abstract methods
   public int getSum(int n1, int n2, int n3) {
       return n1 + n2 + n3;
   }
   
   public double getAverage(int x, int y) {
       return (x + y) / 2.0;
   }
   
   public void printMessage() {
       System.out.println("Hello World!");
   }

}