/*

*/

import java.util.Scanner;
import java.util.ArrayList;

public class FlowerClient{

   static final int SIZE = 3;

   public static void main(String [] args) {
   
      Scanner console = new Scanner(System.in);
   
         //create an ArrayList object
      ArrayList<Flower> flowerList = new ArrayList<Flower>();
      
      for(int i = 0; i < SIZE; i++) {
         
         System.out.println("\n\nEnter the information for Flower : " + (i + 1));
         
            //collect flower info
         System.out.print("\nEnter name: ");
         String name = console.next();
         
         System.out.print("Enter pedals: ");
         int pedals = console.nextInt(); 
        
         System.out.print("Enter cost: $");
         double cost = console.nextDouble();
         
            //create a Flower object & add it to the flowerList
         flowerList.add(new Flower(name, pedals, cost));
         
      }//end for loop
   
         //output
      for(int i = 0; i < flowerList.size(); i++) {
         
         System.out.println(flowerList.get(i));
         
      }//end for loop
      
         //find index of most expensive flower
      int maxIndex = 0;
      
      for(int i = 0; i < flowerList.size(); i++) {
       
         if(flowerList.get(i).getPrice() > flowerList.get(maxIndex).getPrice()) {
            
            maxIndex = i;
            
         } 
      
      }//end for loop
   
      System.out.println("Most expensive flower: " + flowerList.get(maxIndex).getName());
   
         //use set method to replace a flower
      Flower replaced = flowerList.set(1, new Flower( "Sun Flower", 25, 4.99));
      System.out.println("Replaced flower: " + replaced);
      
         //remove the first flower
      System.out.println("Removed flower: " + flowerList.remove(0));
      
         //print the remaining flowers
      for(int i = 0; i < flowerList.size(); i++) {
         
         System.out.println(flowerList.get(i));
         
      }//end for loop
   
   }//end main

}//end class