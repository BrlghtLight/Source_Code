/*

*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

public class NameSearch {

   public static void main(String [] args) throws IOException {
   
      Scanner console = new Scanner(System.in);
   
         //create an ArrayList for girl names
      ArrayList<String> girlNameList = new ArrayList<String>();
      
         //retrieve the command list argument
      String girlNameFile = args[0];    
         
         //call readData method, populates girlNameList
      readData(girlNameList, girlNameFile);
      
            
   }//end main

      //readData method
   private static void readData(ArrayList list, String fileName) throws IOException {
   
      Scanner inFile = new Scanner(new File(fileName));
      
      while(inFile.hasNext()) {
      
            //read a name and place into array list
         list.add(inFile.next());
      
      }//end while
      
      inFile.close();
   
   }//end readData method

}//end class