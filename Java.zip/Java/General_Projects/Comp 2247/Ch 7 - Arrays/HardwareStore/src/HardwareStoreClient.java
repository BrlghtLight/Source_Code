
import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;

public class HardwareStoreClient {

    static final int SIZE = 15;

    public static void main(String[] args) throws IOException {

        //Create inventory array
        Inventory[] itemList = new Inventory[15];

        String inputFileName;

        while (true) {
            JFileChooser open = new JFileChooser("./");
            int status = open.showOpenDialog(null);

            if (status == JFileChooser.APPROVE_OPTION) {
                //open button is clicked
                inputFileName = open.getSelectedFile().getAbsolutePath();
                break;
            }

        }//End while loop

        //Read data from the data file
        Scanner inFile = new Scanner(new FileReader(inputFileName));

        //Remove the data file headings
        for (int i = 0; i < 4; i++) {
            inFile.next();
        }

        //Local variables
        int pid;
        String pName;
        int pieces;
        double unitPrice;
        int x = 0;

        //Read data, create object, and populate the array
        while (inFile.hasNext()) {
            pid = inFile.nextInt();
            pName = inFile.next();
            pieces = inFile.nextInt();
            unitPrice = inFile.nextDouble();

            //create object
            itemList[x] = new Inventory(pid, pName, pieces, unitPrice);
            x++;

        }//End while loop

        boolean flag = true;
        int input;
        Scanner console = new Scanner(System.in);

        while (flag) {
            showMenu();

            System.out.print("Enter a command: ");
            input = console.nextInt();

            switch (input) {
                case 1:
                    for (int i = 0; i < itemList.length; i++) {
                        System.out.println(itemList[i]);
                    }

                    break;

                case 2:
                    double sum = 0;

                    for (int i = 0; i < itemList.length; i++) {
                        sum += itemList[i].calculateInStockValue();

                    }//end for loop

                    System.out.printf("%nTotal In-Stock Value: $%.2f", sum);

                    break;

                case 3:
                    int maxIndex = 0;

                    for (int i = 0; i < itemList.length; i++) {
                        if (itemList[maxIndex].calculateInStockValue()
                                < itemList[i].calculateInStockValue()) {

                            maxIndex = i;
                        }
                    }

                    System.out.println("\nHighest In-Stock Value Item:\n");
                    System.out.println(itemList[maxIndex]);

                    break;

                case 4:
                    System.out.println("Lowest In-Stock Items: \n");

                    for (int i = 0; i < itemList.length; i++) {
                        if (itemList[i].getNumberOfPieces() < 10) {
                            System.out.println(itemList[i]);
                        }

                    }//end for loop

                    break;

                case 5:
                    System.out.print("\nEnter a product to search: ");

                    String searched = console.next();
                    int foundIndex = search(itemList, searched);

                    if (foundIndex == -1) {
                        System.out.println(searched + " is not found.");
                    } else {
                        System.out.println(itemList[foundIndex]);
                    }

                    break;

                case 6:
                    selectionSort(itemList);
                    System.out.println("\nSorted");
                    break;

                case 7:
                    selectionSort(itemList);
                    System.out.print("Enter an item to search: ");
                    String key = console.next();

                    foundIndex = binarySearchRecursion(itemList, 0, itemList.length - 1, key);

                    System.out.println("Found Item @ Index: " + foundIndex);
                    System.out.println(itemList[foundIndex]);

                    break;

                case 8:
                    quickSort(itemList, 0, itemList.length - 1);
                    
                    System.out.println("The array has been sorted");
                    break;

                case 0:
                    flag = false;

                    break;

                default:
                    System.out.println("Error, Invalid entry, "
                            + "Please try again.");

                    break;
            }//End switch

        }//End while

    }//End main

    //create store menu
    private static void showMenu() {
        System.out.print("\n\n"
                + "1 - Output the inventory\n"
                + "2 - Output the total inventory\n"
                + "3 - Find the item with the highest in-stock value\n"
                + "4 - Find the lowest in-stock item\n"
                + "5 - Search an item\n"
                + "6 - Selection Sort\n"
                + "7 - Binary Search\n"
                + "8 - Quick Sort\n"
                + "0 - Exit\n\n");
    }//end menu

    //search method
    public static int search(Inventory[] itemList, String searched) {
        for (int i = 0; i < itemList.length; i++) {
            if (itemList[i].getItemName().equalsIgnoreCase(searched)) {
                return i;
            }
        }

        return -1;

    }//end search method

    //selection sort method
    public static void selectionSort(Inventory[] list) {

        int index = 0;
        Inventory temp;

        for (int x = 0; x < list.length - 1; x++) {

            index = x;

            for (int i = x + 1; i < list.length; i++) {

                if (list[i].getItemName().compareToIgnoreCase(list[index].getItemName()) < 0) {

                    index = i;

                }

            }//end for loop

            //swap
            temp = list[x];
            list[x] = list[index];
            list[index] = temp;

        }//end for loop 

    }//end selectionSort method

    //binary search
    public static int binarySearchRecursion(Inventory[] list, int left, int right, String key) {

        int middle = (left + right) / 2;

        int foundIndex = -1;

        if (list[middle].getItemName().compareToIgnoreCase(key) == 0) {

            foundIndex = middle;

        } else if (key.compareToIgnoreCase(list[middle].getItemName()) < 0) {
            if (left <= middle - 1) {
                foundIndex = binarySearchRecursion(list, left, middle - 1, key);
            }
        } else {
            if (right >= middle + 1) {
                foundIndex = binarySearchRecursion(list, middle + 1, right, key);
            }
        }

        return foundIndex;

    }//end binary search

    //quick sort
    public static void quickSort(Inventory[] list, int left, int right) {
        if (left < right) {
            int q = partition(list, left, right);
            quickSort(list, left, q);
            quickSort(list, q + 1, right);
        }
    }

    //partition method
    public static int partition(Inventory[] list, int left, int right) {
        String x = list[left].getItemName(); //pivot
        int i = left - 1;
        int j = right + 1;

        while (true) {
            j--;
            while (list[j].getItemName().compareToIgnoreCase(x) > 0) {
                j--;
            }

            i++;

            while (list[i].getItemName().compareToIgnoreCase(x) < 0) {
                i++;
            }
            if (i < j) {
                Inventory temp = list[j];
                list[j] = list[i];
                list[i] = temp;
            } else {
                return j;
            }
        }//end while

    }//end method

}//End class
