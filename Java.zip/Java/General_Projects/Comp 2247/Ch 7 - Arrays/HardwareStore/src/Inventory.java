
import java.util.logging.Logger;

/**
 * @author Marcus Walbridge Date: 1-8-2018 Name: Inventory.java Description
 *
 */
public class Inventory {

    //Data members - instance variables
    private int pid;
    private String itemName;
    private int numberOfPieces;
    private double unitPrice;

    //Default constructor
    public Inventory() {
        //default values will be assigned
        //to the data members
    }

    //Overloaded constructor
    public Inventory(int pid, String itemName, int numberOfPieces, double unitPrice) {
        this.pid = pid;
        this.itemName = itemName;
        this.numberOfPieces = numberOfPieces;
        this.unitPrice = unitPrice;
    }

    //Getters and setters
    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getNumberOfPieces() {
        return numberOfPieces;
    }

    public void setNumberOfPieces(int numberOfPieces) {
        this.numberOfPieces = numberOfPieces;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    //Calculate stock value
    public double calculateInStockValue(){
        return this.numberOfPieces * this.unitPrice;
    }
    
    //toString
    @Override
    public String toString() {
        return String.format("%-5d %-16s %,-12d $%,-7.2f",
                pid,
                itemName,
                numberOfPieces,
                unitPrice,
                this.calculateInStockValue());
    }//End toString

}//End class
