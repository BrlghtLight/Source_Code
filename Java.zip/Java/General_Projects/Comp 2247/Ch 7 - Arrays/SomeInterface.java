public interface SomeInterface {

       //abstract methods
    public int getSum(int n1, int n2, int n3);
    
    public double getAverage(int x, int y);
    
    public void printMessage();

}//end interface