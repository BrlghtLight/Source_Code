import java.util.Scanner;

public class HeapPriorityQueueClient {

   static final Scanner console = new Scanner(System.in);
   
   public static void main(String[] args) {
   
      HeapPriorityQueue<Integer> priorityQueue = new HeapPriorityQueue<Integer>();
      
      priorityQueue.enqueue(8);
      priorityQueue.enqueue(18);
      priorityQueue.enqueue(3);
      priorityQueue.enqueue(13);
      priorityQueue.enqueue(29);
      priorityQueue.enqueue(19);
      priorityQueue.enqueue(2);
      priorityQueue.enqueue(7);  
     
      System.out.println("\n" + priorityQueue.toString() + "\n");
      System.out.println(priorityQueue.dequeue() + " is removed");
      System.out.println("\n" + priorityQueue.toString() + "\n");
      
   }//end main
   
}//end class
