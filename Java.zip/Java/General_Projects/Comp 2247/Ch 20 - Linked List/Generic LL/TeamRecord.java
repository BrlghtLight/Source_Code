import java.util.LinkedList;

public class TeamRecord <E extends Comparable<E>>  {

   //data members
   private String teamName;
   private int totalWin;
   private int totalLoss;
   
   //default constructor
   public TeamRecord() {
      teamName = "Default";
      totalWin = 0;
      totalLoss = 0;
   } 
   
   //overloaded constructor
   public TeamRecord(String teamName, int totalWin, int totalLoss) {
      this.teamName = teamName;
      this.totalWin = totalWin;
      this.totalLoss = totalLoss;
   }
   
   //getters
   public String getTeamName() {
      return teamName;
   }
   
   public int getTotalWin() {
      return totalWin;
   }
   
   public int getTotalLoss() {
      return totalLoss;
   }
   
   //setters
   public void setTeamName(String teamName) {
      this.teamName = teamName;
   }
   
   public void setTotalWin(int totalWin) {
      this.totalWin = totalWin;
   }
   
   public void setTotalLoss(int totalLoss) {
      this.totalLoss = totalLoss;
   }  
   
   //compare method
   public boolean compare(Object obj)
{
    if(obj==null)
        return false;
    if(obj==this)
        return true;
    if(obj.getClass() != getClass())
        return false;

    TeamRecord team = (TeamRecord)obj;
    if(zomb.getTeamName().equals(teamName)) {
        return true;
    } else { 
        return false;
}
public  int hashCode() { 
   return 0;
}
   
   //toString method
   public String toString() {
      return "Team Name: " + teamName + "\n"
             + "Total Wins: " + totalWin + "\n" 
             + "Total Losses: " + totalLoss;
   }
   
}//end teamrecord
