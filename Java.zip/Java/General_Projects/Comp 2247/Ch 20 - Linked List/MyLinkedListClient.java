public class MyLinkedListClient {

   public static void main(String [] args) {
   
      //create linked list of string
      MyLinkedList<String> airportList = new MyLinkedList<String>();
      
      //addFirst
      airportList.addFirst("ATL");
      airportList.addFirst("BOS");
      airportList.addFirst("STL");
      airportList.addFirst("MSP");
      airportList.addFirst("RST");
      
      //traverse
      System.out.println(airportList.traverse());
      
      //selection sort
      airportList.selectionSort();
      
      //traverse	
      System.out.println(airportList.traverse());
   	
   	//removeFirst
      System.out.println(airportList.removeFirst() + " is removed.");
      System.out.println(airportList.removeFirst() + " is removed.");
      System.out.println(airportList.removeFirst() + " is removed.");
      System.out.println(airportList.removeFirst() + " is removed.");
      System.out.println(airportList.removeFirst() + " is removed.");
      System.out.println(airportList.removeFirst() + " is removed.");
      
      //traverse 
      System.out.println(airportList.traverse());       
      
   }//end main

}//end of class







