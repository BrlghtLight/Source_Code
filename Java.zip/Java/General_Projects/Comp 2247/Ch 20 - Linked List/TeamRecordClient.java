import java.util.Scanner;

public class TeamRecordClient {

   public static void main(String [] args) {
      
      Scanner console = new Scanner(System.in);
      
      //create linked list of string
      MyLinkedList<TeamRecord> teamList = new MyLinkedList<TeamRecord>();
      
      //variables
      boolean flag = true;
      int input;
      
      String teamName;
      int totalWin;
      int totalLoss;
      
      while(flag) {
         
         showMenu();
         
         System.out.print("| Enter a Command: ");
         input = console.nextInt();
         
         switch(input) {
         
            case 1:
               System.out.print("| Enter the team name: ");
               teamName = console.nextLine();
               
               System.out.print("| Enter the total wins: ");
               totalWin = console.nextInt();
               
               System.out.print("| Enter the total losses: ");
               totalLoss = console.nextInt();
                              
               teamList.addFirst(new TeamRecord(teamName, totalWin, totalLoss));

               break;
               
            case 2:
               System.out.println("| " + teamList.removeFirst() + " is removed |");
 
               break;
               
            case 3:
               break;
               
            case 4:
               System.out.println(teamList.traverse());
               
               break;
               
            case 5:
               break;
               
            case 6:
               teamList.selectionSort();
               System.out.println("| Sorted               |");
               break;
            
            case 7:
               break;
               
            case 0:
               System.out.println("|                                        |" + "\n"
                                 + "|Exiting . . .                           |" + "\n"
                                 + "|________________________________________|");
               flag = false;
               break;
               
            default:
               System.out.println("- Invalid input, Try again -");
               break;
               
         }//end switch
         
      }//end while
      
   }//end main
   
   public static void showMenu() {
   
      System.out.println("__________________________________________" + "\n"
                       + "|                                        |" + "\n"
                       + "| Team Record Client                     |" + "\n"
                       + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n" 
                       + "| 1 --- Add First                        |" + "\n"
                       + "| 2 --- Remove First                     |" + "\n"
                       + "| 3 --- Add Last                         |" + "\n"
                       + "| 4 --- Traverse                         |" + "\n"
                       + "| 5 --- Search                           |" + "\n"
                       + "| 6 --- Selection Sort                   |" + "\n"
                       + "| 7 --- Quick Sort                       |" + "\n"
                       + "| 0 --- Exit                             |" + "\n"
                       + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
                       + "|________________________________________|");
   }//end showMenu
   
}//end of class







