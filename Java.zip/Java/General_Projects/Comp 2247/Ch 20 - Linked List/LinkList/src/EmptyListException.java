/*
 *Author: Marcus Walbridge  
 *Date: 04/07/2018
 *Assignment: Assignment #6
 *Description: Generic Linked List of Comparable Objects
 *             TeamRecordClient.java
 *             TeamRecord.java
 *             Node.java
 *             MyLinkedList.java
 *             EmptyListException.java
 *             Menu Driven: Create a generic linked list, add first and last, 
 *             traverse, sort, remove search
 */

public class EmptyListException extends RuntimeException{
	
   public EmptyListException(String m) {
		super(m);
	}
   
}
