/*
 *Author: Marcus Walbridge  
 *Date: 04/07/2018
 *Assignment: Assignment #6
 *Description: Generic Linked List of Comparable Objects
 *             TeamRecordClient.java
 *             TeamRecord.java
 *             Node.java
 *             MyLinkedList.java
 *             EmptyListException.java
 *             Menu Driven: Create a generic linked list, add first and last, 
 *             traverse, sort, remove search
 */
import java.util.Scanner;

public class TeamRecordClient {

    public static void main(String[] args) {

        Scanner console = new Scanner(System.in);

        //create linked list of string
        MyLinkedList<String> teamList = new MyLinkedList<>();

        //variables
        boolean flag = true;
        boolean flag2 = true;
        int input;

        String teamName;
        int totalWin;
        int totalLoss;

        while (flag) {

            showMenu();

            System.out.print("|Enter a Command: ");
            input = console.nextInt();

            switch (input) {

                case 1:
                    System.out.print("|Enter the team name: ");
                    teamName = console.next();

                    do {
                        System.out.print("|Enter the total wins: ");
                        totalWin = console.nextInt();

                        if (totalWin < 0) {
                            System.out.println("|Total Wins can't be negative, Try again");
                        } else {
                            flag2 = false;
                        }

                    } while (flag2);

                    flag2 = true;

                    do {

                        System.out.print("|Enter the total losses: ");
                        totalLoss = console.nextInt();

                        if (totalLoss < 0) {
                            System.out.println("|Total Wins can't be negative, Try again");
                        } else {
                            flag2 = false;
                        }

                    } while (flag2);

                    flag2 = true;

                    TeamRecord team = new TeamRecord(teamName, totalWin, totalLoss);
                    teamList.addFirst(team.getTeamName());

                    break;

                case 2:
                    System.out.println("| " + teamList.removeFirst() + " is removed                           |");

                    break;

                case 3:
                    System.out.print("|Enter the team name: ");
                    teamName = console.next();

                    do {
                        System.out.print("|Enter the total wins: ");
                        totalWin = console.nextInt();

                        if (totalWin < 0) {
                            System.out.println("|Total Wins can't be negative, Try again");
                        } else {
                            flag2 = false;
                        }

                    } while (flag2);

                    flag2 = true;

                    do {

                        System.out.print("|Enter the total losses: ");
                        totalLoss = console.nextInt();

                        if (totalLoss < 0) {
                            System.out.println("|Total Wins can't be negative, Try again");
                        } else {
                            flag2 = false;
                        }

                    } while (flag2);

                    flag2 = true;

                    team = new TeamRecord(teamName, totalWin, totalLoss);
                    teamList.addLast(team.getTeamName());

                    break;

                case 4:
                    System.out.println(teamList.traverse());

                    break;

                case 5:

                    System.out.print("|Enter a Team to search: ");
                    String searched = console.next();

                    boolean validator = teamList.search(searched);

                    if (validator = true) {
                        System.out.println("|" + searched + " was found                             |");
                    } else {
                        System.out.println("|" + searched + " Not Found");
                    }

                    break;

                case 6:
                    teamList.selectionSort();
                    System.out.println("| Sorted                                 |");
                    break;

                case 0:
                    System.out.println("|                                        |" + "\n"
                            + "|Exiting . . .                           |" + "\n"
                            + "|________________________________________|");
                    flag = false;
                    break;

                default:
                    System.out.println("|Invalid input, Try again                |");
                    break;

            }//end switch

        }//end while

    }//end main

    public static void showMenu() {

        System.out.println("__________________________________________" + "\n"
                + "|                                        |" + "\n"
                + "| Team Record Client                     |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
                + "| 1 --- Add First                        |" + "\n"
                + "| 2 --- Remove First                     |" + "\n"
                + "| 3 --- Add Last                         |" + "\n"
                + "| 4 --- Traverse                         |" + "\n"
                + "| 5 --- Search                           |" + "\n"
                + "| 6 --- Selection Sort                   |" + "\n"
                + "| 0 --- Exit                             |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
                + "|________________________________________|");
    }//end showMenu

}//end of class

