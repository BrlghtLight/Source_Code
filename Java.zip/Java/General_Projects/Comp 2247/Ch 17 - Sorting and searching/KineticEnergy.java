
import java.util.*;

public class KineticEnergy

{
   static Scanner console = new Scanner(System.in);

   public static void main(String[] args)
   
   {
    
       //variables
      double kineticEnergy;
      double mass = 0;
      double velocity = 0;
      
      int input;
      boolean flag = true;
       
     
      while(flag) {
       
         showMenu();
         
         System.out.print("Enter an Option: ");
         input = console.nextInt();
       
         switch(input) {
         
         
            case 1:
               
               //collect user input
               System.out.print("Enter the velocity of the object " 
                                + "(Meters per second): ");
                 
               try {
               
                  velocity = console.nextDouble();
               
                  if(velocity < 0) {
                   
                     throw new Exception("n");
                  
                  }
               
               } catch(InputMismatchException e) {
                  
                  console.next();
                  System.out.print("\nInvalid input, enter a number");        
               
               } catch(Exception e) {
               
                  System.out.println("\n" + e.toString());
               
                  char errorCode = e.toString().charAt(e.toString().length()-1);
               
                  if(errorCode == 'n') {
                  
                     System.out.println("Velocity must be greater than zero.");
                  
                  }
               
               }
               
               //collect user input
               System.out.print("Enter the mass of the object " 
                                + "(Kg): ");
                 
               try {
               
                  mass = console.nextDouble();
               
                  if(mass < 0) {
                   
                     throw new Exception("n");
                  
                  }
               
               } catch(InputMismatchException e) {
                  
                  console.next();
                  System.out.print("\nInvalid input, enter a number");        
               
               } catch(Exception e) {
               
                  System.out.println("\n" + e.toString());
               
                  char errorCode = e.toString().charAt(e.toString().length()-1);
               
                  if(errorCode == 'n') {
                  
                     System.out.println("Mass must be greater than zero.");
                  
                  }
               
               }
            
               if(mass > 0 && velocity > 0) {
                  kineticEnergy = 0.5 * mass * (velocity * velocity);
                  System.out.printf("%nKinetic Energy: %.2f", kineticEnergy);
               }
               break;
         
            case 0: 
               System.out.println("\nExiting . . .");
               flag = false;
               break;
            
            default: 
               System.out.println("Invalid Input, Try again");
               break;      
         
         }//end switch   
      
      }//end while 
       
   }//end main
   
   public static void showMenu() {
   
      System.out.println("\n********************" 
                          + "\n1: Calculate Kinetic Energy" 
                          + "\n0: Exit"
                          + "\n********************"); 
   
   }//end showMenu
    
}//end class

