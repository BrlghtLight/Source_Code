/*
 *Author: Marcus Walbridge  
 *Date: 1/22/2018
 *Assignment: Assignment #1
 *Description: GUI Client Program for StateProject
 *             Allow user to select and read a data file
 *             Allow user to output all state information
 *             Calculate and output total population of all state
 *             Find and output the state with the largest population
 *             Capable of searching for a specific state
 *             Sort all states into regions and output them in lists
 */

import java.awt.Font;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class StateFrame extends javax.swing.JFrame {

    public StateFrame() {
        initComponents();

        largestPopButton.setEnabled(false);
        infoButton.setEnabled(false);
        clearButton.setEnabled(false);
        readButton.setEnabled(false);
        regionButton.setEnabled(false);
        searchButton.setEnabled(false);
        totalPopButton.setEnabled(false);

    }

    static final int ARRAY_SIZE = 50;
    String inputFileName;

    State[] stateList = new State[ARRAY_SIZE];

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        outputArea = new javax.swing.JTextArea();
        infoButton = new javax.swing.JButton();
        totalPopButton = new javax.swing.JButton();
        largestPopButton = new javax.swing.JButton();
        searchButton = new javax.swing.JButton();
        regionButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        selectButton = new javax.swing.JButton();
        readButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(255, 255, 255)));

        titleLabel.setFont(new java.awt.Font("Papyrus", 3, 48)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("                  State Program");
        titleLabel.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 255, 255), new java.awt.Color(0, 0, 0)), javax.swing.BorderFactory.createMatteBorder(3, 4, 4, 3, new java.awt.Color(0, 0, 0))));

        outputArea.setColumns(20);
        outputArea.setRows(5);
        jScrollPane1.setViewportView(outputArea);

        infoButton.setBackground(new java.awt.Color(255, 255, 255));
        infoButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        infoButton.setText("US State Info");
        infoButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 51, 51)));
        infoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                infoButtonActionPerformed(evt);
            }
        });

        totalPopButton.setBackground(new java.awt.Color(0, 0, 0));
        totalPopButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        totalPopButton.setForeground(new java.awt.Color(255, 255, 255));
        totalPopButton.setText("Total Population");
        totalPopButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 255, 255)));
        totalPopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalPopButtonActionPerformed(evt);
            }
        });

        largestPopButton.setBackground(new java.awt.Color(255, 255, 255));
        largestPopButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        largestPopButton.setText("Find Largest Population");
        largestPopButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 51, 51)));
        largestPopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                largestPopButtonActionPerformed(evt);
            }
        });

        searchButton.setBackground(new java.awt.Color(0, 0, 0));
        searchButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        searchButton.setForeground(new java.awt.Color(255, 255, 255));
        searchButton.setText("Search States");
        searchButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 255, 255)));
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });

        regionButton.setBackground(new java.awt.Color(255, 255, 255));
        regionButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        regionButton.setText("Regional State Info");
        regionButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 51, 51)));
        regionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regionButtonActionPerformed(evt);
            }
        });

        clearButton.setBackground(new java.awt.Color(0, 0, 0));
        clearButton.setFont(new java.awt.Font("Papyrus", 1, 11)); // NOI18N
        clearButton.setForeground(new java.awt.Color(255, 255, 255));
        clearButton.setText("Clear");
        clearButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 255, 255)));
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        selectButton.setBackground(new java.awt.Color(255, 255, 255));
        selectButton.setFont(new java.awt.Font("Papyrus", 1, 14)); // NOI18N
        selectButton.setText("Select");
        selectButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 51, 51)));
        selectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectButtonActionPerformed(evt);
            }
        });

        readButton.setBackground(new java.awt.Color(255, 255, 255));
        readButton.setFont(new java.awt.Font("Papyrus", 1, 12)); // NOI18N
        readButton.setText("Read");
        readButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 51, 51)));
        readButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 851, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(clearButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(regionButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(searchButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(largestPopButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(totalPopButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(infoButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(selectButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(readButton, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titleLabel)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(infoButton, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(totalPopButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(largestPopButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(regionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(selectButton, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                            .addComponent(readButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void infoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_infoButtonActionPerformed

        outputArea.append("\nState Name:      "
                + "Abbreviation:   "
                + "Capital:          "
                + "Nick Name:            "
                + "Year:   "
                + "Population     "
                + "Area:       "
                + "Region:      "
                + "Density:\n\n");

        for (int i = 0; i < stateList.length; i++) {

            outputArea.append(stateList[i].toString().replaceAll("_", " ")
                    + ",   "
                    + stateList[i].calculateDensity());

            outputArea.append("\n");

        }//end for loop
    }//GEN-LAST:event_infoButtonActionPerformed

    private void totalPopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalPopButtonActionPerformed
        int totalPopulation = 0;

        for (int i = 0; i < stateList.length; i++) {
            totalPopulation += stateList[i].getPopulation();
        }

        outputArea.append("\n****************************************");
        outputArea.append("\nTotal Population of All States: " + totalPopulation);
        outputArea.append("\n****************************************");
    }//GEN-LAST:event_totalPopButtonActionPerformed

    private void largestPopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_largestPopButtonActionPerformed

        int maxPopulationIndex = 0;

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[maxPopulationIndex].getPopulation()
                    < stateList[i].getPopulation()) {

                maxPopulationIndex = i;

            }

        }//end for loop

        outputArea.append("\n****************************************"
                + "****************************************"
                + "****************************************");

        outputArea.append("\nState with Largest Population: \n"
                + "\nState Name:      "
                + "Abbrev.:       "
                + "Capital:           "
                + "Nick Name:            "
                + "Year:    "
                + "Population   "
                + "Area:       "
                + "Region:    "
                + "Density:\n" + stateList[maxPopulationIndex]
                        .toString().replaceAll("_", " ")
                + " " + stateList[maxPopulationIndex].calculateDensity());

        outputArea.append("\n****************************************"
                + "****************************************"
                + "****************************************");
    }//GEN-LAST:event_largestPopButtonActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed

        int foundIndex;
        String searched;

        searched = JOptionPane.showInputDialog("Enter a  to search: ");
        foundIndex = search(stateList, searched);

        outputArea.append("\n****************************************"
                + "****************************************"
                + "****************************************\n");

        if (foundIndex == -1) {

            outputArea.append(searched + " is not found.");

        } else {

            outputArea.append("State Name:      "
                    + "Abbrev.:       "
                    + "Capital:           "
                    + "Nick Name:            "
                    + "Year:    "
                    + "Population   "
                    + "Area:       "
                    + "Region:    "
                    + "Density:\n");
            outputArea.append(stateList[foundIndex]
                    .toString().replaceAll("_", " ")
                    + " "
                    + stateList[foundIndex].calculateDensity());

        }
        outputArea.append("\n****************************************"
                + "****************************************"
                + "****************************************");

    }//GEN-LAST:event_searchButtonActionPerformed

    private static int search(State[] stateList, String searched) {
        for (int i = 0; i < stateList.length; i++) {
            if (stateList[i].getStateName().equalsIgnoreCase(searched)) {
                return i;
            }
        }//end for loop

        return -1;

    }//end search method

    private void regionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regionButtonActionPerformed
        int stateCount = 0;

        final String REGION_1;
        final String REGION_2;
        final String REGION_3;
        final String REGION_4;
        final String REGION_5;
        final String REGION_6;
        final String REGION_7;

        REGION_1 = "South_Central";
        REGION_2 = "Pacific";
        REGION_3 = "Mountain";
        REGION_4 = "New_England";
        REGION_5 = "Middle_Atlantic";
        REGION_6 = "South_Atlantic";
        REGION_7 = "North_Central";

        outputArea.append("\n\n****************************************");
        outputArea.append("\n" + REGION_1 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_1)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_1);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_2 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_2)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_2);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_3 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_3)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_3);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_4 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_4)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_4);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_5 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_5)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_5);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_6 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_6)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_6);
        outputArea.append("\n****************************************");

        stateCount = 0;

        outputArea.append("\n" + REGION_7 + " States: \n");

        for (int i = 0; i < stateList.length; i++) {

            if (stateList[i].getRegion().equals(REGION_7)) {
                outputArea.append("\n" + stateList[i]
                        .getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        outputArea.append("\n\n" + stateCount + " States in " + REGION_7);
    }//GEN-LAST:event_regionButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        outputArea.setText("");
    }//GEN-LAST:event_clearButtonActionPerformed

    private void selectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectButtonActionPerformed

        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JFileChooser open = new JFileChooser("./");
        int status = open.showOpenDialog(null);

        if (status == JFileChooser.APPROVE_OPTION) {
            //open button is clicked
            inputFileName = open.getSelectedFile().getAbsolutePath();
            outputArea.append(inputFileName + " is selected.");
            readButton.setEnabled(true);

        } else {
            outputArea.append("No file selected.");
        }
    }//GEN-LAST:event_selectButtonActionPerformed

    private void readButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readButtonActionPerformed
        try {
            //Read data from the data file
            Scanner inFile = new Scanner(new FileReader(inputFileName));

            //Remove the data file headings
            for (int i = 0; i < 8; i++) {
                inFile.next();
            }

            //Local variables
            String stateName;
            String abbreviation;
            String capital;
            String nickName;
            String region;

            int count = 0;
            int year;
            int population;
            int area;
            int input;

            //Read data, create object, and populate the array
            while (inFile.hasNext()) {

                stateName = inFile.next();
                abbreviation = inFile.next();
                capital = inFile.next();
                nickName = inFile.next();
                year = inFile.nextInt();
                population = inFile.nextInt();
                area = inFile.nextInt();
                region = inFile.next();

                //create object
                stateList[count] = new State(stateName, abbreviation, capital,
                        nickName, year, population,
                        area, region);
                count++;

            }//End while loop

            outputArea.append("\n\nThe Data has been read.");

        }//end try
        catch (IOException e) {
            outputArea.append("Error");
        }//end catch

        largestPopButton.setEnabled(true);
        infoButton.setEnabled(true);
        clearButton.setEnabled(true);
        regionButton.setEnabled(true);
        searchButton.setEnabled(true);
        totalPopButton.setEnabled(true);

    }//GEN-LAST:event_readButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StateFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clearButton;
    private javax.swing.JButton infoButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton largestPopButton;
    private javax.swing.JTextArea outputArea;
    private javax.swing.JButton readButton;
    private javax.swing.JButton regionButton;
    private javax.swing.JButton searchButton;
    private javax.swing.JButton selectButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JButton totalPopButton;
    // End of variables declaration//GEN-END:variables
}
