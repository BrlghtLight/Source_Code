/*
 *Author: Marcus Walbridge  
 *Date: 1/22/2018
 *Assignment: Assignment #1
 *Description: Class definition for StateProject
 */

public class State {

    //data members
    private String stateName;
    private String abbreviation;
    private String capital;
    private String nickName;
    private int year;
    private int population;
    private int area;
    private String region;

    //default constructor
    public State() {

    }

    //overloaded contructor
    public State(String stateName, String abbreviation, String capital,
            String nickName, int year, int population,
            int area, String region) {

        this.stateName = stateName;
        this.abbreviation = abbreviation;
        this.capital = capital;
        this.nickName = nickName;
        this.year = year;
        this.population = population;
        this.area = area;
        this.region = region;
    }

    //getters and setters
    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    //calculate population density
    public double calculateDensity() {

        /*
        
        I don't have calculate density representing any decimal values
        because you could end up with, for example, half a person 
        per unit of area which didn't seem realistic?
        
         */
        return this.population / this.area;

    }//end calculateDensity

    //toString
    @Override
    public String toString() {
        return String.format("%-15s, %-14s, %-16s, %-20s, %-6d, %-12d, %-10d, %-10s",
                stateName,
                abbreviation,
                capital,
                nickName,
                year,
                population,
                area,
                region);
    }

}//end class
