/*
 *Author: Marcus Walbridge  
 *Date: 1/22/2018
 *Assignment: Assignment #1
 *Description: Console Client Program for StateProject
 *             Allow user to output all state information
 *             Calculate and output total population of all state
 *             Find and output the state with the largest population
 *             Capable of searching for a specific state
 *             Sort all states into regions and output them in lists
 */

import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;
import java.util.ArrayList;

public class StateClient {

    public static void main(String[] args) throws IOException {

        Scanner console = new Scanner(System.in);

        //Create inventory array
        ArrayList<State> stateList = new ArrayList<State>();

        String inputFileName;

        while (true) {
            JFileChooser open = new JFileChooser("./");
            int status = open.showOpenDialog(null);

            if (status == JFileChooser.APPROVE_OPTION) {
                //open button is clicked
                inputFileName = open.getSelectedFile().getAbsolutePath();
                break;
            }

        }//End while loop

        //Read data from the data file
        Scanner inFile = new Scanner(new FileReader(inputFileName));

        //Remove the data file headings
        for (int i = 0; i < 8; i++) {
            inFile.next();
        }

        //variables
        String stateName;
        String abbreviation;
        String capital;
        String nickName;
        String region;

        int year;
        int population;
        int area;
        int input;

        boolean flag = true;

        //Read data, create object, and populate the array
        while (inFile.hasNext()) {
            stateName = inFile.next();
            abbreviation = inFile.next();
            capital = inFile.next();
            nickName = inFile.next();
            year = inFile.nextInt();
            population = inFile.nextInt();
            area = inFile.nextInt();
            region = inFile.next();

            //create object
            stateList.add(new State(stateName, abbreviation, capital, nickName, 
                    year, population, area, region));
            
        }//End while loop

        while (flag) {

            showMenu();
            System.out.print("Enter a command (Numbers 1, 2, 3, 4, 5, 0): ");
            input = console.nextInt();

            switch (input) {
                case 1:

                    System.out.printf("%nState Name:      "
                            + "Abbreviation:   "
                            + "Capital:          "
                            + "Nick Name:            "
                            + "Year:   "
                            + "Population     "
                            + "Area:       "
                            + "Region:      "
                            + "Density:%n%n");

                    for (int i = 0; i < stateList.size(); i++) {

                        System.out.println(stateList.get(i).toString().replaceAll("_", " ")
                                + ",    " + stateList.get(i).calculateDensity());

                    }//end for loop

                    break;

                case 2:

                    System.out.println("\n****************************************");
                    System.out.println("Total Population: " + calculateTotalPop(stateList));
                    System.out.println("****************************************");

                    break;

                case 3:

                    System.out.println("\n****************************************");

                    System.out.println("State with Largest Population: \n" + "\nState Name:      "
                            + "Abbreviation:   "
                            + "Capital:          "
                            + "Nick Name:            "
                            + "Year:   "
                            + "Population    "
                            + "Area:       "
                            + "Region:       "
                            + "Density:\n"
                            + stateList.get(findMaxPopulation(stateList))
                                    .toString().replaceAll("_", " ")
                            + "    " + stateList.get(findMaxPopulation(stateList)).calculateDensity());

                    System.out.println("****************************************");

                    break;

                case 4:

                    System.out.println("\n****************************************");
                    System.out.print("Enter a State to search: ");

                    String searched = console.next();
                    int foundIndex = search(stateList, searched);

                    if (foundIndex == -1) {

                        System.out.println(searched + " is not found.");

                    } else {

                        System.out.print("\nState Name:      "
                                + "Abbreviation:   "
                                + "Capital:          "
                                + "Nick Name:            "
                                + "Year:   "
                                + "Population   "
                                + "Area:         "
                                + "Region:      "
                                + "Density:\n");
                        System.out.println(stateList.get(foundIndex).toString().replaceAll("_", " ")
                                + "  "
                                + stateList.get(foundIndex).calculateDensity());

                    }
                    System.out.println("****************************************");

                    break;

                case 5:

                    //Regions' states print out in vertical list vs. 
                    //horizontal list
                    System.out.println("");
                    regions(stateList);

                    break;

                case 0:

                    flag = false;

                    break;

                default:

                    System.out.println("\n****************************************");
                    System.out.println("\nError, Invalid entry, "
                            + "Please try again.");
                    System.out.println("\n****************************************");

                    break;

            }//End switch

        }//end while

    }//end main   

    //calculate total population
    public static int calculateTotalPop(ArrayList<State> stateList) {

        int totalPopulation = 0;

        for (int i = 0; i < stateList.size(); i++) {
            totalPopulation += stateList.get(i).getPopulation();
        }

        return totalPopulation;

    }//end calculateTotalPop

    //find largest population
    public static int findMaxPopulation(ArrayList<State> stateList) {

        int maxPopulationIndex = 0;

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(maxPopulationIndex).getPopulation()
                    < stateList.get(i).getPopulation()) {

                maxPopulationIndex = i;

            }

        }//end for loop

        return maxPopulationIndex;

    }//end findMaxPopulation

    //search method
    public static int search(ArrayList<State> stateList, String searched) {

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getStateName().equalsIgnoreCase(searched)) {
                return i;
            }

        }//end for loop

        return -1;

    }//end search method

    //print regions method
    public static void regions(ArrayList<State>
            stateList) {

        int stateCount = 0;
     
        final String REGION_1;
        final String REGION_2;
        final String REGION_3;
        final String REGION_4;
        final String REGION_5;
        final String REGION_6;
        final String REGION_7;

        REGION_1 = "South_Central";
        REGION_2 = "Pacific";
        REGION_3 = "Mountain";
        REGION_4 = "New_England";
        REGION_5 = "Middle_Atlantic";
        REGION_6 = "South_Atlantic";
        REGION_7 = "North_Central";

        System.out.println("\n****************************************");
        System.out.println(REGION_1 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_1)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_1);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_2 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_2)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_2);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_3 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_3)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_3);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_4 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_4)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_4);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_5 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_5)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_5);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_6 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_6)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_6);
        System.out.println("\n****************************************");

        stateCount = 0;

        System.out.println(REGION_7 + " States: \n");

        for (int i = 0; i < stateList.size(); i++) {

            if (stateList.get(i).getRegion().equals(REGION_7)) {
                System.out.println(stateList.get(i).getStateName().replaceAll("_", " "));
                stateCount++;
            }

        }//end for loop

        System.out.println("\n" + stateCount + " States in " + REGION_7);

    }//end regions method

    //create state program menu
    private static void showMenu() {

        System.out.print("\n\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
                + "\n"
                + "1 --- Output the US state information\n"
                + "2 --- Output the total population\n"
                + "3 --- Find the state with the largest population\n"
                + "4 --- Search a state and output its information\n"
                + "5 --- Output states in each region\n"
                + "0 --- Exit\n"
                + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

    }//end showMenu

}//end class
