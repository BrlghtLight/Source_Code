import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

public class GirlNamesProgram
{
   public static void main(String [] args) throws IOException  
   {
      Scanner console = new Scanner(System.in);
      
      boolean flag = true;
      int input;
      int foundIndex = 0;
      
      //create an ArrayList for girl names
      ArrayList<String> girlNameList = new ArrayList<String>();
      
      //retrieve the command list argument
      String girlNameFile = args[0];
      
      //call readData method to populate girlNameList
      readData(girlNameList, girlNameFile);
      
      while(flag) {
         
         showMenu();
         
         System.out.print("Enter a command: ");
         input = console.nextInt();
         
         switch(input) {
            
            case 1:
               for (int i = 0; i < girlNameList.size(); i++) {
                  System.out.println(girlNameList.get(i));
               }//end for loop
               break;
             
            case 2:
               selectionSort(girlNameList);
               System.out.println("\n- Sorted -");
               break;
             
            case 3:
               selectionSort(girlNameList);
            
               try {
               
                  System.out.print("Enter an item to search: ");
                  String key = console.next();
               
                  foundIndex = binarySearchRecursion(girlNameList, 0, girlNameList.size() - 1, key);
               
                  if(foundIndex == -1) {
                     throw new Exception("n");
                  }
                  
               } catch (InputMismatchException e) {
                  
                  console.next();
                  System.out.print("\nInvalid input, enter a name\n");   
               
               } catch (Exception e) {
                 
                  System.out.println("\n" + e.toString());
               
                  char errorCode = e.toString().charAt(e.toString().length()-1);
               
                  if(errorCode == 'n') {
                  
                     System.out.println("Name is not popular");
                  
                  }
               
               }
               
               if( foundIndex != -1) {
                  System.out.println("\nFound Item @ Index: " + foundIndex);
                  System.out.println(girlNameList.get(foundIndex));
               }
               else {
               
               }
               
               break;
            
            case 0:
               flag = false;
               break;
            
            default: 
               System.out.println("- Invalid input, try again -");
               break;
         
         }//end switch
      
      }//end while
         
   } //end main
    
   //readData method
   private static void readData(ArrayList girlNameList, String fileName) throws IOException {
      
      Scanner inFile = new Scanner( new File(fileName) );
       
      while(inFile.hasNext()) {
         //read a name and place it into the array list
         girlNameList.add(inFile.next());   
      }      
      inFile.close();
   }//end read data method
   
   //selection sort method
   public static void selectionSort(ArrayList girlNameList) {
   
      int index = 0;
      String temp;
   
      for (int x = 0; x < girlNameList.size() - 1; x++) {
      
         index = x;
      
         for (int i = x + 1; i < girlNameList.size(); i++) {
         
            if (((String)girlNameList.get(i)).compareToIgnoreCase(((String)girlNameList.get(index))) < 0) {
               index = i;
            }
         
         }//end for loop
      
            //swap
         temp = (String)girlNameList.get(x);
         girlNameList.set(x, girlNameList.get(index));
         girlNameList.set(index, temp);
      
      }//end for loop 
   
   }//end selectionSort method
   
   //binary search
   public static int binarySearchRecursion(ArrayList girlNameList, int left, int right, String key) {
   
      int middle = (left + right) / 2;
   
      int foundIndex = -1;
   
      if (((String)girlNameList.get(middle)).compareToIgnoreCase(key) == 0) {
      
         foundIndex = middle;
      
      } else if (key.compareToIgnoreCase((String)girlNameList.get(middle)) < 0) {
         if (left <= middle - 1) {
            foundIndex = binarySearchRecursion(girlNameList, left, middle - 1, key);
         }
      } else {
         if (right >= middle + 1) {
            foundIndex = binarySearchRecursion(girlNameList, middle + 1, right, key);
         }
      }
   
      return foundIndex;
   
   }//end binary search

   public static void showMenu() {
   
      System.out.println("\n---  Name List Program  ---\n" 
                         + "\n1 --- Print name list"
                         + "\n2 --- Sort name list"
                         + "\n3 --- Search\n");
   
   }//end show menu method

}//end class