import java.util.*;

public class SortingAndSearchingPrimitive {

   public static void main(String [] args) {
   
      Scanner console = new Scanner(System.in);
   	  
      Random rand = new Random();
   	  
      int [] list = new int[25];
   
      for (int i = 0; i < list.length; i++) {
            //list[i] = (int)(Math.random() * 500 +1);
         list[i] = rand.nextInt(500) + 1;    //0 to 499, 1 to 500
      }
   	  
      System.out.println("\nAll Elements:");
      printArray( list );
      
      //call selectionsort method
      selectionSort(list);
      
      System.out.println("\n");
      printArray(list);  
      
      //binary search
      System.out.print("\n\nEnter a key to search: ");
      int key = console.nextInt();
      
      int foundIndex = binarySearchRecursion(list, 0, list.length - 1, key);
      
      if(foundIndex == -1) {
      
         System.out.println("Not Found.");
      
      } else {
      
         System.out.println("Found @ Index: " + foundIndex);
      
      }
      
   }//end main

   public static void printArray(int[] list) {
      for (int i = 0; i < list.length; i++) {
         System.out.print(list[i] + " ");
      }
   }
   
   //selection sort method
   public static void selectionSort(int [] list) {
   
      int index = 0;
      int temp;
   
   
      for(int x = 0; x < list.length - 1; x++) {
        
         index = x;
        
         for(int i = x + 1; i < list.length; i++) {
         
            if(list[i] < list[index]) {
               
               index = i;
               
            }
         
         }//end for loop
      
              //swap
         temp = list[x];
         list[x] = list[index];
         list[index] = temp;
      
      }//end for loop 
   
   }//end selectionSort method
   
   //binary search
   public static int binarySearchRecursion(int [] list, int left, int right, int key) {
   
      int middle = (left + right) / 2;
      
      int foundIndex = -1;
      
      if(list[middle] == key) {
      
         foundIndex = middle;
      
      } else if(key < list[middle]) {
         if(left <= middle - 1) {
            foundIndex = binarySearchRecursion(list, left, middle - 1, key);
         }
      } else {
         if(right >= middle + 1) {
            foundIndex = binarySearchRecursion(list, middle + 1, right, key);
         }
      }      
   
      return foundIndex;
   }//end binary search
   
} //end class
