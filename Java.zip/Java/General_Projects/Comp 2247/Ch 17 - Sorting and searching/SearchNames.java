import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

public class GirlNamesProgram
{
   public static void main(String [] args) throws IOException  
   {
      Scanner console = new Scanner(System.in);
      
      boolean flag = true;
      int input;
   	  
      //create an ArrayList for girl names
      ArrayList<String> girlNameList = new ArrayList<String>();
      
      //retrieve the command list argument
      String girlNameFile = args[0];
      
      //call readData method to populate girlNameList
      readData(girlNameList, girlNameFile);
      
      while(flag) {
         
         showMenu();
         
         System.out.print("Enter a command: ");
         input = console.nextInt();
         
         switch(input) {
            
            case 1:
            
               break;
             
            case 2:
            
               break;
             
            case 3:
               System.out.print("Enter a girl's name to search: ");
               String name = console.next();
            
               //call search method
               int foundIndex = search(girlNameList, name);
            
               if(foundIndex == -1) {
                  System.out.println("\nNot found");
               } else {
                  System.out.println("\nFound at index " + foundIndex);             
               }
               break;
            
            case 0:
               flag = false;
               break;
            
            default: 
               System.out.println("- Invalid input, try again -");
               break;
         
         }//end switch
      
      }//end while
         
   } //end main
    
   //readData method
   private static void readData(ArrayList list, String fileName) throws IOException {
      
      Scanner inFile = new Scanner(new File(fileName));
       
      while(inFile.hasNext()) {
         //read a name and place it into the array list
         list.add(inFile.next());   
      }      
      inFile.close();
   }//end read data method
   
   //search method
   private static int search(ArrayList list, String name) {
   
      for(int i=0; i<list.size(); i++) {
      
         if(list.get(i).toString().equalsIgnoreCase(name)) {
            return i; //found      
         }
      
      }//end for loop
      
      return -1; //not found
   
   }//end search method

   public static void showMenu() {
   
      System.out.println("---  Name List Program  ---" 
                         + "\n1: Print name list"
                         + "\n2: Sort name list"
                         + "\n3: Search");
   
   }//end show menu method

}//end class