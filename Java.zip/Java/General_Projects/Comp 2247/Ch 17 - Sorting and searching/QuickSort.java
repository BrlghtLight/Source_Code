import java.util.*;

public class QuickSort {

   public static void main(String [] args) {
   
      Scanner console = new Scanner(System.in);
   	  
      Random rand = new Random();
      
      int [] list = new int[25];
      
      for(int i = 0; i < list.length; i++) {
         list[i] = rand.nextInt(500) + 1;
      }
            
      System.out.println("\nAll Elements: ");
      printArray(list);
      
      //call quicksort
      quickSort(list, 0, list.length - 1);
      
      System.out.println("\nAll Elements: ");
      printArray(list);
      
   }//end main
 
   public static void printArray(int[] list) {
      for(int i = 0; i < list.length; i++) {
         System.out.print(list[i] + " ");
      }
   }
   
   //quick sort
   public static void quickSort(int[] list, int left, int right) {
      if(left < right) {
         int q = partition(list, left, right);
         quickSort(list, left, q);
         quickSort(list, q + 1, right);
      }
   }
   
   //partition method
   public static int partition(int[] list, int left, int right) {
      int x = list[left]; //pivot
      int i = left - 1;
      int j = right + 1;
      
      while(true) {
         j--;
         while(list[j] > x) {
            j--;
         }
         
         i++;
         
         while(list[i] < x) {
            i++;
         }
         if(i < j) {
            int temp = list[j];
            list[j] = list[i];
            list[i] = temp;
         } else {
            return j;
         }
      }//end while
      
   }//end method
      
} //end class
