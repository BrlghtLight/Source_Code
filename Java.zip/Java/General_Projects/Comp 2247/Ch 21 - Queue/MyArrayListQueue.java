
import java.util.ArrayList;

public class MyArrayListQueue<E> implements QueueInterface<E> {

   private ArrayList<E> queue;
   private int front;
   private int rear;
  
   private int capacity;
  
   public static final int CAPACITY = 10; //default
  
  //default constructor
   public MyArrayListQueue() {
      this(CAPACITY);
   }  
  
  //overloaded constructor
   public MyArrayListQueue(int n) {
      capacity = n;
      queue = new ArrayList<E>();
      front = rear = 0;
   }
  
   public boolean isEmpty() {
      return (front == rear);
   }
  
   public int size() {
      return queue.size();
   }
  
   public void enqueue(E obj) {
      queue.add(rear, obj);
      rear++;
   }
  
   public E peek() throws EmptyQueueException {
      if(isEmpty()) {
         throw new EmptyQueueException("Empty Queue");
      }
      return queue.get(front);
   }

   public E dequeue() throws EmptyQueueException {
      if(isEmpty()) {
         throw new EmptyQueueException("Empty Queue");
      }
      rear--;
      return queue.remove(front);
   }
   
   //toString()
   public String toString() {
      return "" + queue;
   }
   
}//end class

