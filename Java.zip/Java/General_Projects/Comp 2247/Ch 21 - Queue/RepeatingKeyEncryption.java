/*
 Author:
 Date:
 Program:
 Description:

 */

import java.util.*;

public class RepeatingKeyEncryption {

   public static void main(String[] args) {
   
      //declare variables
      String message = "Knowledge is Power";
      int [] key = {6, 7, 3, 1, 8};
      
      //call encrypt method
      System.out.println("\nEncrypted Message: " + encrypt(message, key));
   
   }//end main
   
   public static String encrypt(String message, int [] key) {
   
     //variables
      String encoded = "";
      int keyValue;
     
     //declare queue
      Queue<Integer> keyQueue = new LinkedList<Integer>();
     
     //load the key values to keyQueue
      for(int i = 0; i < key.length; i++) {
        
         keyQueue.add(key[i]);
        
      }//end for loop 
     
     //encrypt the message
      for(int i = 0; i < message.length(); i++) {       
        //dequeue
         keyValue = keyQueue.remove();
        //ASCII
         encoded += (char)(message.charAt(i) + keyValue);       
        //enqueue
         keyQueue.add(keyValue);
      }//end for loop
   
      return encoded;
      
   }//end encrypt method
   
}//end class

