/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that uses shifting key encryption to encrypt a text file
             Key utilizes an ArrayList queue, Create an output file for the
             encrypted messaged.  Print on the screen the decoded version of the
             text file.
*/
import java.util.ArrayList;

public class ArrayListQueue<E> implements QueueInterface<E> {

   private ArrayList<E> queue;
   private int front;
   private int rear;
  
   private int capacity;
  
   public static final int CAPACITY = 10; //default
  
  //default constructor
   public ArrayListQueue() {
      this(CAPACITY);
   }  
  
  //overloaded constructor
   public ArrayListQueue(int n) {
      capacity = n;
      queue = new ArrayList<>();
      front = rear = 0;
   }
  
   @Override
   public boolean isEmpty() {
      return (front == rear);
   }
  
   @Override
   public int size() {
      return queue.size();
   }
  
   @Override
   public void enqueue(E obj) {
      queue.add(rear, obj);
      rear++;
   }
  
   @Override
   public E peek() {
      if(isEmpty()) {
         throw new EmptyQueueException("Empty Queue");
      }
      return queue.get(front);
  }

    @Override
   public E dequeue() throws EmptyQueueException {
      if(isEmpty()) {
         throw new EmptyQueueException("Empty Queue");
      }
      rear--;
      return queue.remove(front);
   }
   
   //toString()
   @Override
   public String toString() {
      return "" + queue;
   }
   
}//end class

