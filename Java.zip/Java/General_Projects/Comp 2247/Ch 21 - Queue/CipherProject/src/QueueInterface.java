/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that uses shifting key encryption to encrypt a text file
             Key utilizes an ArrayList queue, Create an output file for the
             encrypted messaged.  Print on the screen the decoded version of the
             text file.
*/
public interface QueueInterface<E> {
  
  public int size();

  public boolean isEmpty();

  public E peek();

  public void enqueue (E element);

  public E dequeue();

}
