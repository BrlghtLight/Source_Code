/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that uses shifting key encryption to encrypt a text file
             Key utilizes an ArrayList queue, Create an output file for the
             encrypted messaged.  Print on the screen the decoded version of the
             text file.
*/
import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;
import java.util.Scanner;
import java.util.stream.Stream;

public class Client {

   public static void main(String[] args) throws FileNotFoundException, IOException {
   
      Scanner console = new Scanner(System.in);
   
      //variables
      String encoded = "";
      String input;
      String message = "";
      String inputFileName;
      String outputFileName = "EncryptedText.txt";
      String encrypted;
   
      String keyValue;
      boolean flag = true;
   
      int [] keyList = new int[15];
      
      while (flag) {
         menu();
         System.out.print("\n|"
                + "\n|Enter a Command: ");
         input = console.next();
      
         switch (input) {
         
            case "key":
               //collect key from user
               System.out.println("|Enter a Key(Use Commas): ");
               keyValue = console.next();
               
               keyList = Stream.of(keyValue.split(",")).mapToInt(Integer::parseInt).toArray();
            
               System.out.println("|Key has been Collected");
               break;
         
            case "read":
            
               while (true) {
                  JFileChooser open = new JFileChooser("./");
                  int status = open.showOpenDialog(null);
                  if (status == JFileChooser.APPROVE_OPTION) {
                     //open button is clicked
                     inputFileName = open.getSelectedFile().getAbsolutePath();
                     break;
                  }
               
               }//End while loop
            
               //Read data from the data file
               Scanner inFile = new Scanner(new FileReader(inputFileName));
            
               //Read data and store the message to be encrypted
               while (inFile.hasNext()) {
                  message += inFile.nextLine();
               }//End while loop
            
               System.out.println("|Message: " + message);
            
               break;
         
            case "encrypt":
               //Call the method to create the file output object
               createFileOutputObject(outputFileName, false, message, keyList);
               System.out.println("|Encryped, New Txt File Made");
               break;
         
            case "decrypt":
               keyList = null;
               //RE-collect key from user
               //collect key from user
               System.out.println("|Enter a Key: ");
               keyValue = console.next();
               
               keyList = Stream.of(keyValue.split(",")).mapToInt(Integer::parseInt).toArray();
               
               System.out.println(Arrays.toString(keyList));
               
               while (true) {
                  JFileChooser open = new JFileChooser("./");
                  int status = open.showOpenDialog(null);
                  if (status == JFileChooser.APPROVE_OPTION) {
                     //open button is clicked
                     inputFileName = open.getSelectedFile().getAbsolutePath();
                     break;
                  }
               
               }//End while loop
               
               //Read data from the data file
               inFile = new Scanner(new FileReader(inputFileName));
               
               message = "";
               
               //Read data and store the message to be decrypted
               while (inFile.hasNext()) {
                  message += inFile.nextLine();
               }//End while loop
               
               System.out.println("|"
                      + decrypt(message, keyList));
               break;
         
            case "exit":
               System.out.println("|Exiting....");
               flag = false;
               break;
         
            default:
               System.out.println("|" + "\n"
                      + "|Invalid Command, Try again" + "\n"
                      + "|");
         
         }//end switch
      
      }//end while
   
   }//end main

   public static String encrypt(String message, int [] keyList) {
   
      //variables
      String encoded = "";
      int keyValue;
   
      //declare queue
      Queue<Integer> keyQueue = new LinkedList<>();
   
      //load the key values to keyQueue
      for (int i = 0; i < keyList.length; i++) {
         keyQueue.add(keyList[i]);
      }//end for loop
   
      //encrypt the message
      for (int i = 0; i < message.length(); i++) {
         //dequeue
         keyValue = keyQueue.remove();
         //ASCII
         encoded += (char)(message.charAt(i) + keyValue);
         //enqueue
         keyQueue.add(keyValue);
      }//end for loop
   
      return encoded;
   
   }//end encrypt method

   public static String decrypt(String message, int [] keyList) {
   
      //variables
      String decoded = "";
      int keyValue;
   
      //declare queue
      Queue<Integer> keyQueue = new LinkedList<>();
   
      //load the key values to keyQueue
      for (int i = 0; i < keyList.length; i++) {
         keyQueue.add(keyList[i]);
      }//end for loop
   
      //encrypt the message
      for (int i = 0; i < message.length(); i++) {
         //dequeue
         keyValue = keyQueue.remove();
         //ASCII
         decoded += (char)(message.charAt(i) - keyValue);
         //enqueue
         keyQueue.add(keyValue);
      }//end for loop
      return decoded;
   }//end encrypt method

   //Return the outFile object (PrintWriter)
   public static void createFileOutputObject(String outputFileName, boolean flag,
           String message, int [] keyList) throws IOException {
   
      FileWriter fw = new FileWriter(outputFileName, flag);
      try (PrintWriter outFile = new PrintWriter(fw)) {
         outFile.print("" + encrypt(message, keyList));
      }
   }//End createFileOutputObject method

   public static void menu() {
      System.out.print(
             "__________________________________________" + "\n"
             + "|                                        |" + "\n"
             + "| Shifting Key Client                    |" + "\n"
             + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
             + "| key --- Enter a Key                    |" + "\n"
             + "| read --- Read a Message File           |" + "\n"
             + "| encrypt --- Encrypt & Create New File  |" + "\n"
             + "| decrypt --- Decrypt and Print          |" + "\n"
             + "| exit --- End Program                   |" + "\n"
             + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
             + "|________________________________________|"
         );
   }

}//end class
