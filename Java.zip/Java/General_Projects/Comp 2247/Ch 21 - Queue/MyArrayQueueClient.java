public class MyArrayQueueClient {

    public static void main(String[] args) {

	   
		
		
		
		
		
    } //end main
	
}//end class

