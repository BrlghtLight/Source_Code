public class MyArrayListQueueClient {

   public static void main(String[] args) {
   
      //declare arraylist queue
      MyArrayListQueue<String> customerQueue = new MyArrayListQueue<String>();
      
      //call enqueue
      customerQueue.enqueue("Tom");
      customerQueue.enqueue("Ben");
      customerQueue.enqueue("Mary");
      customerQueue.enqueue("Jon");
      customerQueue.enqueue("Steve");
      
      System.out.println("\nQueue: " + customerQueue);
      
      //dequeue
      System.out.println("\nServing Customer: " + customerQueue.dequeue());
      System.out.println("\nServing Customer: " + customerQueue.dequeue());
      
      System.out.println("\nQueue: " + customerQueue);
   }
}

