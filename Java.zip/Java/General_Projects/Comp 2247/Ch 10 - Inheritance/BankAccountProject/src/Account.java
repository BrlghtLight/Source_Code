/*
 *Author: Marcus Walbridge
 *Course: COMP 2247
 *Date: 2/14/2018
 *Assignment: 3
 *Description: Inheritance hierarchy for a banking account system
               Abstract super class and two subclasses
               Account with CheckingAccount and Savings Account
               Menu driven client program, allows user to create both
               Checking and Savings accounts, credit deposit or debit withdrawal
               and print their information
 */

public abstract class Account {

    //data members
    private double balance;

    //default constructor
    public Account() {
    }

    //overloaded constructor
    public Account(double balance) {
        if (balance >= 0) {
            this.balance = balance;
        } else {
            System.out.println("\n--- Invalid, Balance set to $0.00 ---");
            this.balance = 0;
        }
    }

    //getters and setters
    public double getBalance() {
        return balance;
    }

    protected void setBalance(double balance) {
        this.balance = balance;
    }

    public abstract void debit(double withdraw);

    public abstract void credit(double deposit);

    @Override
    public String toString() {
        return "--- Balance: " + String.format("$%.2f", balance) + " ---";
    }

}//end class
