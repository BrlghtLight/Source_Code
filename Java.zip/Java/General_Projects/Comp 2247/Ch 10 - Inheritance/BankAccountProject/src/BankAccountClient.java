/*
 *Author: Marcus Walbridge
 *Course: COMP 2247
 *Date: 2/14/2018
 *Assignment: 3
 *Description: Inheritance hierarchy for a banking account system
               Abstract super class and two subclasses
               Account with CheckingAccount and Savings Account
               Menu driven client program, allows user to create both
               Checking and Savings accounts, credit deposit or debit withdrawal
               and print their information
 */

import java.util.ArrayList;
import java.util.Scanner;

public abstract class BankAccountClient extends Account {

    public static void main(String[] args) {

        Scanner console = new Scanner(System.in);

        //create array list of accounts
        ArrayList<Account> accountList = new ArrayList<Account>();

        //variables
        boolean bankMenuFlag = true;
        boolean savingMenuFlag = true;
        boolean checkingMenuFlag = true;

        int bankSystemInput;
        int savingMenuInput;
        int checkingMenuInput;
        int accountCount = 0;
        int accountID;

        double interest;
        double balance;
        double feePerTransaction;
        double withdrawal;
        double deposit;

        while (bankMenuFlag) {

            showMenu();

            System.out.print("Enter a command: ");
            bankSystemInput = console.nextInt();

            switch (bankSystemInput) {

                //--------------------------------------------------------------
                //CASE 1
                //--------------------------------------------------------------
                case 1:
                    if (accountCount < 10) {
                        System.out.println("\n--- New Savings Account ---");

                        System.out.print("\nStarting Balance: $");
                        balance = console.nextDouble();
                        System.out.print("Interest Rate: %");
                        interest = console.nextDouble();

                        if (interest >= 0) {
                            accountList.add(new SavingsAccount(interest, balance));
                            accountCount++;

                            System.out.println("\nNew Savings Account created"
                                    + "\nCurrent Account ID: "
                                    + (accountID = (accountCount - 1)));

                            while (savingMenuFlag) {

                                savingsMenu();

                                System.out.print("\nEnter a Command: ");
                                savingMenuInput = console.nextInt();

                                switch (savingMenuInput) {
                                    case 1:

                                        System.out.print("\nAmount to Deposit(credit): $");
                                        deposit = console.nextDouble();

                                        accountList.get(accountID).credit(deposit);

                                        System.out.println(accountList.get(accountID).toString());

                                        break;

                                    case 2:

                                        System.out.print("\nAmount to Withdraw(debit): $");
                                        withdrawal = console.nextDouble();

                                        accountList.get(accountID).debit(withdrawal);

                                        System.out.println(accountList.get(accountID).toString());

                                        break;

                                    case 3:

                                        System.out.println("Interest: $"
                                                + ((SavingsAccount) accountList.get(accountID)).calculateInterest());

                                        break;

                                    case 0:
                                        savingMenuFlag = false;
                                        break;

                                    default:
                                        System.out.println("\n--- Invalid Option, "
                                                + "Try again ---");
                                        break;
                                }//end savings menu switch

                            }//end savings while

                        } else {
                            System.out.println("\n--- Invalid interest, "
                                    + "Try again ---");
                        }
                    } else {
                        System.out.println("\n~~~ Maximum Accounts Reached ~~~");
                    }
                    break;

                //--------------------------------------------------------------
                //CASE 2
                //--------------------------------------------------------------
                case 2:
                    if (accountCount < 10) {
                        System.out.println("\n--- New Checking Account ---");

                        System.out.print("\nStarting Balance: $");
                        balance = console.nextDouble();
                        System.out.print("Fee per Transaction: $");
                        feePerTransaction = console.nextDouble();

                        if (feePerTransaction >= 0) {
                            accountList.add(new CheckingAccount(balance, feePerTransaction));
                            accountCount++;

                            System.out.println("\nNew Checking Account created"
                                    + "\nCurrent Account ID: "
                                    + (accountID = (accountCount - 1)));

                            checkingMenu();

                            while (checkingMenuFlag) {

                                System.out.println();

                                System.out.print("Enter a Command: ");
                                checkingMenuInput = console.nextInt();

                                switch (checkingMenuInput) {
                                    case 1:

                                        System.out.print("\nAmount to Deposit(credit): $");
                                        deposit = console.nextDouble();

                                        accountList.get(accountID).credit(deposit);

                                        System.out.println(accountList.get(accountID).toString());

                                        break;

                                    case 2:

                                        System.out.print("\nAmount to Withdraw(debit): $");
                                        withdrawal = console.nextDouble();

                                        accountList.get(accountID).debit(withdrawal);

                                        System.out.println(accountList.get(accountID).toString());

                                        break;

                                    case 0:
                                        checkingMenuFlag = false;
                                        break;

                                    default:
                                        System.out.println("\n--- Invalid input, "
                                                + "Try again ---");
                                        break;
                                }//end checking menu switch

                            }//end checking while

                        } else {
                            System.out.println("\n--- Invalid Fee, Try again ---");
                        }
                    } else {
                        System.out.println("\n~~~ Maximum Accounts Reached ~~~");
                    }
                    break;

                //--------------------------------------------------------------
                //CASE 3
                //--------------------------------------------------------------
                case 3:

                    //hard coded accounts
                    accountList.add(new CheckingAccount(1, 8));
                    accountList.add(new CheckingAccount(2, 7));
                    accountList.add(new CheckingAccount(3, 6));
                    accountList.add(new CheckingAccount(4, 5));
                    accountList.add(new CheckingAccount(5, 4));
                    accountList.add(new CheckingAccount(6, 3));
                    accountList.add(new CheckingAccount(7, 2));
                    accountList.add(new CheckingAccount(8, 1));

                    accountCount = 10;

                    if (accountCount < 10) {
                        System.out.println("\nThere are less than 10 accounts "
                                + "created, Please create more.");
                    } else {
                        for (int i = 0; i < accountList.size(); i++) {
                            System.out.print("\n"
                                    + accountList.get(i).toString());

                            if (i % 2 == 0) {

                                System.out.println();

                            }
                        }
                    }

                    break;

                //--------------------------------------------------------------
                //CASE 0
                //--------------------------------------------------------------
                case 0:
                    System.out.println("\nExiting...");
                    bankMenuFlag = false;
                    break;

                //--------------------------------------------------------------
                //DEFAULT CASE
                //--------------------------------------------------------------
                default:
                    System.out.println("\n--- Invalid Input, Try again ---");
                    break;

            }//end switch

        }//end while

    }//end main

    public static void showMenu() {

        System.out.println("\n*************************************************"
                + "*************************"
                + "\n| Bank Account System:                                                   |"
                + "\n|---------------------------------------------------------"
                + "---------------|"
                + "\n| 1: Create a Savings Account                                            |"
                + "\n| 2: Create a Checking Account                                           |"
                + "\n| 3: Print List of Accounts                                              |"
                + "\n| 0: Exit                                                                |"
                + "\n**********************************************************"
                + "****************");

    }//end showMenu

    public static void savingsMenu() {

        System.out.println("\n******************************************************"
                + "\n| Bank Account System:                               |"
                + "\n|----------------------------------------------------|"
                + "\n| 1: Credit Return Transaction                       |"
                + "\n| 2: Withdrawal Transaction                          |"
                + "\n| 3: Calculate Interest                              |"
                + "\n| 0: Exit this Account                               |"
                + "\n******************************************************");

    }//end savingsMenu

    public static void checkingMenu() {

        System.out.println("\n******************************************************"
                + "\n| Bank Account System:                               |"
                + "\n|----------------------------------------------------|"
                + "\n| 1: Credit Return Transaction                       |"
                + "\n| 2: Withdrawal Transaction                          |"
                + "\n| 0: Exit this Account                               |"
                + "\n******************************************************");

    }//end checkingMenu

}//end class
