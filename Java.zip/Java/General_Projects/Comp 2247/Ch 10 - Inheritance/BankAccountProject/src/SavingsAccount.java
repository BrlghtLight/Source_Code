/*
 *Author: Marcus Walbridge
 *Course: COMP 2247
 *Date: 2/14/2018
 *Assignment: 3
 *Description: Inheritance hierarchy for a banking account system
               Abstract super class and two subclasses
               Account with CheckingAccount and Savings Account
               Menu driven client program, allows user to create both
               Checking and Savings accounts, credit deposit or debit withdrawal
               and print their information
 */

public class SavingsAccount extends Account {

    //data members
    private double interestRate;

    //default constructor
    public SavingsAccount() {
    }

    //overloaded constructor
    public SavingsAccount(double interestRate) {
        this.interestRate = interestRate;
    }

    //getters and setters
    public SavingsAccount(double interestRate, double balance) {
        super(balance);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public double calculateInterest() {

        //convert user inputted % to decimal form
        return Double.parseDouble(String.format("%.2f",
                (.01 * interestRate) * super.getBalance()));

    }//end calculateInterest

    @Override
    public void debit(double withdraw) {
        if (withdraw <= super.getBalance() && withdraw >= 0) {
            super.setBalance(super.getBalance() - withdraw);
            System.out.println("--- Amount Withdrawn: $"
                    + String.format("%.2f", withdraw) + "  ---");
        } else {
            System.out.println("--- Invalid Withdrawal Amount, Try again ---");
        }
    }

    @Override
    public void credit(double deposit) {
        if (deposit >= 0) {
            super.setBalance(super.getBalance() + deposit);
            System.out.println("--- Amount Credited: $"
                    + String.format("%.2f", deposit) + " ---");
        } else {
            System.out.println("--- Deposit cannot be Negative, Try again ---");
        }
    }

    @Override
    public String toString() {
        return super.toString() + "\n"
                + "--- Interest Rate: %" + String.format("%.2f", interestRate);
    }//end toString

}//end class
