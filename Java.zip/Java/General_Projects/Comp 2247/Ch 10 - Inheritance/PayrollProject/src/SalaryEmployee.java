public class SalaryEmployee {
    
}
