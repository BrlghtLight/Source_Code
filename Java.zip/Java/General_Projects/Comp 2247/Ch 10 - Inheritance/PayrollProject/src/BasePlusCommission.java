
public class BasePlusCommission extends CommissionEmployee {

    //data members
    private double baseSalary;

    public BasePlusCommission() {
    }

    public BasePlusCommission(double baseSalary, double sales, double rate, int id, String firstName, String lastName) {
        super(sales, rate, id, firstName, lastName);
        this.baseSalary = baseSalary;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    //override earnings method
    public double earnings() {

        return this.baseSalary
                + super.earnings();

    }//end earnings methods

    @Override
    public String toString() {
        return super.toString()
                + "Base Salary: " + baseSalary;
    }

}//end class
