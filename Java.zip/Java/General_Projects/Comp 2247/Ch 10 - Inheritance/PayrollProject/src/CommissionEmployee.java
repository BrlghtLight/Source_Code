
public class CommissionEmployee extends Employee {

    //data members
    private double sales;
    private double rate;

    public CommissionEmployee() {
    }

    public CommissionEmployee(double sales, double rate, int id, String firstName, String lastName) {
        super(id, firstName, lastName);
        this.sales = sales;
        this.rate = rate;
        
        //this.lastName = "Changed";
    }

    public double getSales() {
        return sales;
    }

    public void setSales(double sales) {
        this.sales = sales;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    //override earnings method
    @Override
    public double earnings() {

        return this.sales * this.rate;

    }//end earnings method

    @Override
    public String toString() {
        return super.toString()
                + "Sales: " + sales + "\n"
                + "Commission Rate: " + rate;
    }

}//end class
