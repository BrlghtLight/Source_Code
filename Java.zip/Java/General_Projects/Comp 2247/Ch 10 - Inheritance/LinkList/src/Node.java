public class Node<E extends Comparable<E>>{

   //data member
   private E element;
   private Node<E> next;

   //default constructor
   public Node() {
      this(null, null);
   }
   
   //overloaded constructor
   public Node(E element, Node<E> next) {
      this.element = element;
      this.next = next;
   }
   
   //setters and getters
   public void setElement(E element) {
      this.element = element;
   }
   
   public void setNext(Node<E> next) {
      this.next = next;
   }
   
   public E getElement() {
      return element;
   } 
   
   public Node<E> getNext() {
      return next;
   }
   
}//end class
