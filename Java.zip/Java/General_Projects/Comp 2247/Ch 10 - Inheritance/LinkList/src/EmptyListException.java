public class EmptyListException extends RuntimeException{
	
   public EmptyListException(String m) {
		super(m);
	}
   
}
