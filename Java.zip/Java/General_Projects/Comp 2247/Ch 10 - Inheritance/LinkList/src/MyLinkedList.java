//This linked list works for the generic comparable objects

public class MyLinkedList<E extends Comparable<E>> {

    //data members
    private Node<E> head;
    private Node<E> tail;
    private int size;

    //default constructor
    public MyLinkedList() {
        head = null;
        tail = head;
        size = 0;
    }

    //size method
    public int size() {
        return size;
    }

    //isEmpty method
    public boolean isEmpty() {
        if (head == null) {
            return true;
        }
        return false;
    }

    //addFirst method will add a new node as the first node
    public void addFirst(E element) {

        //step 1: Creating a new node for the element
        Node<E> temp = new Node<>(element, null);

        if (isEmpty()) {
            head = temp;
            tail = head;
        } else {
            temp.setNext(head);//step 2
            head = temp;//step 3
        }

        size++;//step 4

    }//end addFirst

    //removeFirst method, remove and return the first node
    public E removeFirst() throws EmptyListException {
        if (isEmpty()) {
            throw new EmptyListException("The linked list is empty");
        }
        Node<E> temp = head; //step 1

        //if the list has only one node, do something with the tail reference.
        tail = head;

        head = head.getNext(); //head = head.next step 2
        temp.setNext(null); //temp.next = null step 3

        E result = temp.getElement(); //retrieve the object step 4

        size--;

        temp = null;

        return result;
    }

    //add the new node as the last node
    public void addLast(E element) {
        //homework
        //use tail reference to add new node
        //do not traverse
        //step 1: Creating a new node for the element
        Node<E> temp = new Node<>(element, null);

        if (isEmpty()) {
            tail = temp;
            head = tail;
        } else {
            tail.setNext(temp);//step 2
            tail = tail.getNext();//step 3
        }
        size++;//step 4
    }

    //traverse (like toString())
    //returns linked list as a string
    public String traverse() {
        if (isEmpty()) {
            return "|Empty List                              |";
        }

        Node<E> temp = head;

        String result = "Head -->";

        int i = size;

        while (i > 0) {
            result += temp.getElement() + "-->";
            temp = temp.getNext();
            i--;
        }//end while

        return result;

    }//end traverse

    //selection sort method
    public void selectionSort() {

        Node<E> minNode;
        Node<E> tempHead;
        Node<E> tempHeadNext;

        tempHead = head;
        tempHeadNext = head.getNext();

        for (int x = 0; x < size - 1; x++) {

            minNode = tempHead;

            for (int i = x + 1; i < size - 1; i++) {

                if ((tempHeadNext.getElement()).compareTo(minNode.getElement()) < 0) {

                    minNode = tempHeadNext;

                }

                tempHeadNext = tempHeadNext.getNext(); //move to the next node

            }//end for loop

            //swap
            E temp = tempHead.getElement();
            tempHead.setElement(minNode.getElement());
            minNode.setElement(temp);

            tempHead = tempHead.getNext();
            tempHeadNext = tempHead.getNext();

        }//end for loop 

    }//end selectionSort method

    /*
    //quickSort
    public void quickSort(teamList, int left, int right) {

        if (left < right) {
            int q = partition(teamList, left, right);
            quickSort(list, left, q);
            quickSort(list, q + 1, right);
        }

    }//end quickSort

    //partition
    public static int partition(int[] list, int left, int right) {
        int x = list[left]; //pivot
        int i = left - 1;
        int j = right + 1;

        while (true) {
            j--;
            while (list[j] > x) {
                j--;
            }

            i++;

            while (list[i] < x) {
                i++;
            }
            if (i < j) {
                int temp = list[j];
                list[j] = list[i];
                list[i] = temp;
            } else {
                return j;
            }
    
        }//end while
    
    }//end partition
     */
    //search  
    private boolean search(E searched) {

        if (isEmpty()) {
            return false;
        }

        Node<E> temp = head;

        String result = "Head -->";

        int i = size;

        while (i > 0) {
            result += temp.getElement() + "-->";
            temp = temp.getNext();

            i--;

        }//end while

        return true;

    }//end search

    //add a new node as the second node
    public void addSecond(E element) {

        //create new node for the element 
        Node<E> temp = new Node<>(element, null);

        if (isEmpty()) {
            System.out.println("The list is empty");
        } else {
            //pseudo: temps next = head.next
            temp.setNext(head.getNext());

            //heads next = temp
            head.setNext(temp);

            temp = null;
            size++;
        }

    }//end addSecond

    //remove the second node and return the element object
    public E removeSecond() throws Exception {

        if (size < 2) {
            throw new Exception("The list has less than two nodes");
        }

        Node<E> temp = head.getNext();

        head.setNext(temp.getNext());

        //temps next to null
        temp.setNext(null);
        size--;

        E element = temp.getElement();
        temp = null;

        return element;

    }//end remove second

}//end of class
