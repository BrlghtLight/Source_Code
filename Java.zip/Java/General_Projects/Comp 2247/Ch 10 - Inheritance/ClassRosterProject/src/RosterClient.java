
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author marcu
 */
public class RosterClient {

    public static void main(String[] args) {

        ArrayList<Student> studentList = new ArrayList<Student>();

        studentList.add(new Undergraduate("Tom"));
        studentList.add(new Graduate("Keemstar"));
        studentList.add(new Undergraduate("Leafy"));
        studentList.add(new Graduate("FilthyFrank"));
        studentList.add(new Undergraduate("Idubbbbz"));

        int[] scoreList1 = {78, 80, 76};
        int[] scoreList2 = {23, 65, 99};

        studentList.get(0).setTestList(scoreList2);
        studentList.get(1).setTestList(scoreList1);
        studentList.get(2).setTestList(scoreList2);
        studentList.get(3).setTestList(scoreList1);
        studentList.get(4).setTestList(scoreList2);

        //process the studentList polymorphically
        for(int i = 0; i < studentList.size(); i++) {
            studentList.get(i).calculateGrade();
            System.out.println(studentList.get(i).toString());
        }//end for loop
        
    }//end main

}//end class
