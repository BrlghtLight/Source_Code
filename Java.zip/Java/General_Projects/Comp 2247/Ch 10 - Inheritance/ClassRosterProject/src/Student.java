/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marcu
 */
public abstract class Student {

    //data members
    private String name;
    private String grade;
    private int[] testList;

    protected final static int NUM_OF_TESTS = 3;

    public Student() {
    }

    public Student(String name) {
        this.name = name;
        this.testList = new int[NUM_OF_TESTS];
        this.grade = "Unknown";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int[] getTestList() {
        return testList;
    }

    public void setTestList(int[] testList) {
        this.testList = testList;
    }

    abstract public void calculateGrade();

    @Override
    public String toString() {
        return "Name: " + name + "\n"
                + "Grade: " + grade;
    }

}
