public class BinarySearchTreeClient {
    
    public static void main(String [] args) {
        //create a Binary Search Tree
        BinarySearchTree<Integer> Tree = new BinarySearchTree<>();
        
        Tree.insertNode(8);
        Tree.insertNode(4);
        Tree.insertNode(32);
        Tree.insertNode(7);
        Tree.insertNode(3);
        Tree.insertNode(37);
        Tree.insertNode(2);
        Tree.insertNode(11);
        Tree.insertNode(12);
        
        System.out.println("\nIn-Order Traverse: ");
        
        Tree.inorderTraverse();
        
        System.out.println();
    
    }//end main
    
}//end class
