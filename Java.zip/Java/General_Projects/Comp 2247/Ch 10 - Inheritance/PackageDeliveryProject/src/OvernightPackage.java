/*
*Authors: Marcus Walbridge & Jacob Wilder
*Course: Comp 2247
*Assignment: 3 (Group)
*Date: 2/14/2018
*Description: inheritance hierarchy containing super class Package 
              and subclasses RegularPackage, TwoDayPackage and OvernightPackage.
              Package has abstract method calculateCost overidden by subclasses.
              Client program allowing user to create multiple packages and
              proccess them polymorphically
*/
public class OvernightPackage extends Package {

    //data members
    private double feePerOunce;

    public OvernightPackage() {
    }
    
    public OvernightPackage(double feePerOunce, int packageID, String sFirstName, String sLastName, String rFirstName, String rLastName, double weightOunces, double costPerOunce) {
        super(packageID, sFirstName, sLastName, rFirstName, rLastName, weightOunces, costPerOunce);
        if (feePerOunce > 0) {
            this.feePerOunce = feePerOunce;
        } else {
            this.feePerOunce = 0;
        }
    }

    public double getFeePerOunce() {
        return feePerOunce;
    }

    public void setFeePerOunce(double feePerOunce) {
        if (feePerOunce > 0) {
            this.feePerOunce = feePerOunce;
        } else {
            this.feePerOunce = 0;
        }
    }

    public double calculateCost() {
        return (feePerOunce + super.getCostPerOunce()) * super.getWeightOunces();
    }

    @Override
    public String toString() {
        return super.toString() + "\n"
                + "Additional Fee: " + String.format("$%.2f", feePerOunce);
    }

}
