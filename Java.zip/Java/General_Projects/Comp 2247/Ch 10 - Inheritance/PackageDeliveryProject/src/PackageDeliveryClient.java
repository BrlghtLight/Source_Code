/*
*Authors: Marcus Walbridge & Jacob Wilder
*Course: Comp 2247
*Assignment: 3 (Group)
*Date: 2/14/2018
*Description: inheritance hierarchy containing super class Package 
              and subclasses RegularPackage, TwoDayPackage and OvernightPackage.
              Package has abstract method calculateCost overidden by subclasses.
              Client program allowing user to create multiple packages and
              proccess them polymorphically
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class PackageDeliveryClient extends Package {

    public static void main(String[] args) throws IOException {

        Scanner console = new Scanner(System.in);

        //polymorphic referance
        ArrayList<Package> packageList = new ArrayList<Package>();

        //variables
        int userInput;
        boolean flag = true;
        boolean validationFlag = true;

        //package information
        int ID;
        double weight;
        double costPerOunce;
        double rate = 0;
        double flatFee;
        double feePerOunce;

        String sFirst;
        String sLast;
        String rFirst;
        String rLast;

        //output the menu
        showMenu();

        while (flag) {

            //allow user to enter an option
            System.out.print("\nEnter a Command: ");
            userInput = console.nextInt();

            switch (userInput) {

                case 1:

                    //collect package info
                    //ensure no negative fees or IDs are entered
                    do {
                        System.out.print("\nEnter the Rate of the Regular Package: $");
                        rate = console.nextDouble();
                        System.out.print("Enter Package ID: ");
                        ID = console.nextInt();

                        if (rate < 0 || ID < 0) {
                            System.out.println("\nInvalid Fee or ID, Try again");
                        } else {
                            validationFlag = false;
                        }

                    } while (validationFlag);

                    System.out.print("Enter Sender's First Name: ");
                    sFirst = console.next();
                    System.out.print("Enter Sender's Last Name: ");
                    sLast = console.next();

                    System.out.print("Enter Receiver's First Name: ");
                    rFirst = console.next();
                    System.out.print("Enter Receiver's Last Name: ");
                    rLast = console.next();

                    //ensure weight and cost per ounce are not negative
                    validationFlag = true;

                    do {
                        System.out.print("Enter the Package's Weight: ");
                        weight = console.nextDouble();
                        System.out.print("Enter Cost per Ounce: $");
                        costPerOunce = console.nextDouble();

                        if (weight < 0 || costPerOunce < 0) {
                            System.out.print("\nInvalid Weight or Cost per Ounce, Try again\n\n");
                        } else {
                            validationFlag = false;
                        }
                    } while (validationFlag);

                    //create regular package and add it to the package list
                    packageList.add(new RegularPackage(rate, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce));

                    System.out.println("\n~~~ Regular Package added ~~~");

                    System.out.print("\nPackage information:");
                    System.out.print("\n\n" + new RegularPackage(rate, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce).toString());

                    showMenu();
                    break;

                case 2:

                    //collect package info
                    //ensure flat fee and package ID are not negative
                    validationFlag = true;

                    do {
                        System.out.print("\nEnter Flat Fee: $");
                        flatFee = console.nextDouble();
                        System.out.print("Enter Package ID: ");
                        ID = console.nextInt();

                        if (flatFee < 0 || ID < 0) {
                            System.out.println("\nInvalid Flat Fee or ID, Try again");
                        } else {
                            validationFlag = false;
                        }
                    } while (validationFlag);

                    System.out.print("Enter Sender's First Name: ");
                    sFirst = console.next();
                    System.out.print("Enter Sender's Last Name: ");
                    sLast = console.next();

                    System.out.print("Enter Receiver's First Name: ");
                    rFirst = console.next();
                    System.out.print("Enter Receiver's Last Name: ");
                    rLast = console.next();

                    //ensure package weight and cost per ounce are not negative
                    validationFlag = true;

                    do {
                        System.out.print("Enter Package Weight: ");
                        weight = console.nextDouble();
                        System.out.print("Enter Cost per Ounce: $");
                        costPerOunce = console.nextDouble();

                        if (weight < 0 || costPerOunce < 0) {
                            System.out.println("\nInvalid Weight or Cost per Ounce, Try again\n\n");
                        } else {
                            validationFlag = false;
                        }
                    } while (validationFlag);

                    //add two day package to the package list
                    packageList.add(new TwoDayPackage(flatFee, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce));

                    System.out.println("\n~~~ Two Day Package added ~~~");

                    System.out.println("\nPackage information: ");
                    System.out.println("\n\n" + (new TwoDayPackage(flatFee, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce).toString()));

                    showMenu();
                    break;

                case 3:

                    //collect package info
                    //ensure fee per ounce and ID are not negative
                    validationFlag = true;

                    do {
                        System.out.print("\nEnter Fee per Ounce: ");
                        feePerOunce = console.nextDouble();
                        System.out.print("Enter Package ID: ");
                        ID = console.nextInt();

                        if (feePerOunce < 0 || ID < 0) {
                            System.out.println("\nInvalid Fee per Ounce or ID, Try again");
                        } else {
                            validationFlag = false;
                        }

                    } while (validationFlag);

                    System.out.print("Enter Sender's First Name: ");
                    sFirst = console.next();
                    System.out.print("Enter Sender's Last Name: ");
                    sLast = console.next();

                    System.out.print("Enter Receiver's First Name: ");
                    rFirst = console.next();
                    System.out.print("Enter Receiver's Last Name: ");
                    rLast = console.next();

                    //ensure package weight and cost per ounce are not negative
                    validationFlag = true;

                    do {
                        System.out.print("Enter Package Weight: ");
                        weight = console.nextDouble();
                        System.out.print("Enter Cost per Ounce: $");
                        costPerOunce = console.nextDouble();

                        if (weight < 0 || costPerOunce < 0) {
                            System.out.println("\nInvalid Weight or Cost per Ounce, Try again\n\n");
                        } else {
                            validationFlag = false;
                        }
                    } while (validationFlag);

                    //add overnight package to the package list
                    packageList.add(new TwoDayPackage(feePerOunce, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce));

                    System.out.println("\n~~~ Over-Night Package added ~~~");

                    System.out.println("\nPackage information: ");
                    System.out.println("\n\n" + (new OvernightPackage(rate, ID, sFirst,
                            sLast, rFirst, rLast, weight, costPerOunce).toString()));

                    showMenu();
                    break;

                case 4:

                    for (int i = 0; i < packageList.size(); i++) {

                        System.out.print("\n\n" + packageList.get(i).toString());

                    }//end for loop

                    showMenu();
                    break;

                case 0:
                    flag = false;
                    break;

                default:
                    System.out.println("\n~~~ Invalid entry, try again ~~~");

                    showMenu();
                    break;

            }//end switch

        }//end while loop

    }//end main class

    private static void showMenu() {
        System.out.println("\n**************************************************************************"
                + "\n| Package Delivery System:                                               |"
                + "\n|------------------------------------------------------------------------|"
                + "\n| 1: Create a regular package object and add it into the package list    |"
                + "\n| 2: Create a two-day package object and add it into the package list    |"
                + "\n| 3: Create an overnight package object and add it into the package list |"
                + "\n| 4: Print information for all packages in the package list              |"
                + "\n| 0: Exit                                                                |"
                + "\n**************************************************************************");
    }//end showMenu method

}//end PackageDeliveryClient
