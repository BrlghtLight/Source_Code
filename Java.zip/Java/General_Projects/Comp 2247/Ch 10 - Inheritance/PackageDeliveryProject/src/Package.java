/*
*Authors: Marcus Walbridge & Jacob Wilder
*Course: Comp 2247
*Assignment: 3 (Group)
*Date: 2/14/2018
*Description: inheritance hierarchy containing super class Package 
              and subclasses RegularPackage, TwoDayPackage and OvernightPackage.
              Package has abstract method calculateCost overidden by subclasses.
              Client program allowing user to create multiple packages and
              proccess them polymorphically
*/
public abstract class Package {

    //data members
    private int packageID;
    private String sFirstName;
    private String sLastName;
    private String rFirstName;
    private String rLastName;
    private double weightOunces;
    private double costPerOunce;

    public Package() {
    }

    public Package(int packageID, String sFirstName, String sLastName, String rFirstName, String rLastName, double weightOunces, double costPerOunce) {
        this.packageID = packageID;
        this.sFirstName = sFirstName;
        this.sLastName = sLastName;
        this.rFirstName = rFirstName;
        this.rLastName = rLastName;
        if (weightOunces > 0) {
            this.weightOunces = weightOunces;
        } else {
            this.weightOunces = 0;
        }
        if (costPerOunce > 0) {
            this.costPerOunce = costPerOunce;
        } else {
            this.costPerOunce = 0;
        }
    }

    public int getPackageID() {
        return packageID;
    }

    public void setPackageID(int packageID) {
        this.packageID = packageID;
    }

    public String getsFirstName() {
        return sFirstName;
    }

    public void setsFirstName(String sFirstName) {
        this.sFirstName = sFirstName;
    }

    public String getsLastName() {
        return sLastName;
    }

    public void setsLastName(String sLastName) {
        this.sLastName = sLastName;
    }

    public String getrFirstName() {
        return rFirstName;
    }

    public void setrFirstName(String rFirstName) {
        this.rFirstName = rFirstName;
    }

    public String getrLastName() {
        return rLastName;
    }

    public void setrLastName(String rLastName) {
        this.rLastName = rLastName;
    }

    public double getWeightOunces() {
        return weightOunces;
    }

    public void setWeightOunces(double weightOunces) {
        if (weightOunces > 0) {
            this.weightOunces = weightOunces;
        } else {
            this.weightOunces = 0;
        }
    }

    public double getCostPerOunce() {
        return costPerOunce;
    }

    public void setCostPerOunce(double costPerOunce) {
        if (costPerOunce > 0) {
            this.costPerOunce = costPerOunce;
        } else {
            this.costPerOunce = 0;
        }
    }

    abstract public double calculateCost();

    @Override
    public String toString() {
        return "Sender: " + sFirstName + " " + sLastName +
                 "\nRecipient: " + rFirstName + " " + rLastName +
                 "\nWeight (oz): " + weightOunces + " oz" +
                 "\nCost per ounce: " + costPerOunce;
    }

}
