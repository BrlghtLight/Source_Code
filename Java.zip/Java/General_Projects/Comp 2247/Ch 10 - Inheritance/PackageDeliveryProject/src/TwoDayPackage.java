/*
*Authors: Marcus Walbridge & Jacob Wilder
*Course: Comp 2247
*Assignment: 3 (Group)
*Date: 2/14/2018
*Description: inheritance hierarchy containing super class Package 
              and subclasses RegularPackage, TwoDayPackage and OvernightPackage.
              Package has abstract method calculateCost overidden by subclasses.
              Client program allowing user to create multiple packages and
              proccess them polymorphically
*/
public class TwoDayPackage extends Package {

    //data members
    private double flatFee;

    public TwoDayPackage() {
    }

    public TwoDayPackage(double flatFee, int packageID, String sFirstName,
            String sLastName, String rFirstName, String rLastName,
            double weightOunces, double costPerOunce) {
        super(packageID, sFirstName, sLastName, rFirstName, rLastName,
                weightOunces, costPerOunce);

        if (flatFee > 0) {
            this.flatFee = flatFee;
        } else {
            this.flatFee = 0;
        }
    }

    public double getFlatFee() {
        return flatFee;
    }

    public void setFlatFee(double flatFee) {
        if (flatFee > 0) {
            this.flatFee = flatFee;
        } else {
            this.flatFee = 0;
        }
    }

    @Override
    public double calculateCost() {
        double cost;
        cost = flatFee + (super.getWeightOunces() * super.getCostPerOunce());

        return cost;
    }

    @Override
    public String toString() {
        return super.toString() + "\n"
                + "Flat Fee: " + String.format("$%.2f", flatFee);
    }

}//end TwoDayPackage Class
