/*
*Authors: Marcus Walbridge & Jacob Wilder
*Course: Comp 2247
*Assignment: 3 (Group)
*Date: 2/14/2018
*Description: inheritance hierarchy containing super class Package 
              and subclasses RegularPackage, TwoDayPackage and OvernightPackage.
              Package has abstract method calculateCost overidden by subclasses.
              Client program allowing user to create multiple packages and
              proccess them polymorphically
*/
public class RegularPackage extends Package {

    //data members
    private double shippingRate;

    public RegularPackage() {
    }

    public RegularPackage(double shippingRate, int packageID, String sFirstName, String sLastName, String rFirstName, String rLastName, double weightOunces, double costPerOunce) {
        super(packageID, sFirstName, sLastName, rFirstName, rLastName, weightOunces, costPerOunce);
        this.shippingRate = shippingRate;
    }

    public double getShippingRate() {
        return shippingRate;
    }

    public void setShippingRate(double shippingRate) {
        this.shippingRate = shippingRate;
    }

    public double calculateCost() {
        return shippingRate * super.getCostPerOunce() * super.getWeightOunces();
    }

    @Override
    public String toString() {
        return super.toString() + "\nThe Rate: " + shippingRate
               + "\nTotal cost: $" + calculateCost();
    }
}
