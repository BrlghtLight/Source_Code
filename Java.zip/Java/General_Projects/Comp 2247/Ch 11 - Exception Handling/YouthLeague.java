
import java.util.*;

public class YouthLeague
{
   static Scanner console = new Scanner(System.in);

   public static void main(String[] args)
   {
    
       //variables
      int age;
       
      while(true) { 
         System.out.print("Enter an age (12-18): ");
       
         try {
         
            age = console.nextInt();
         
            if(age <= 0) {
            
               throw new Exception("n");
            
            } else if(age < 12) {
            
               throw new Exception("y");
            
            } else if(age > 18) {
            
               throw new Exception("o");
            
            }
         
            
            System.out.println("Done.");
            break;
         
         } catch(InputMismatchException e) {
           
            console.next();
            System.out.print("Invalid input, enter an integer.");
         
         } catch(Exception e) {
         
            System.out.println(e.toString());
         
            char errorCode = e.toString().charAt(e.toString().length()-1);
         
            if(errorCode == 'n') {
            
               System.out.println("Age must be greater than zero.");
            
            }
            if(errorCode == 'y') {
            
               System.out.println("Too young to join the Youth League");
            
            }
            if(errorCode == 'o') {
            
               System.out.println("Too old to join the Youth League");
            
            }
         
         }
         
      }//end while 
       
   }//end main
    
}//end class

