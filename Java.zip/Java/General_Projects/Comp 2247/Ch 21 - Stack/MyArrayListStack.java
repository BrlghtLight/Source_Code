import java.util.*;

@SuppressWarnings("unchecked")

public class MyArrayListStack<E> implements StackInterface<E> {

  //data members
   private ArrayList<E> list;
   public static final int CAPACITY = 12;
   private int capacity;
   private int top;
  
  //default constructor
   public MyArrayListStack() {
      this(CAPACITY);
   }//end default constructor
  
  //overloaded constructor
   public MyArrayListStack(int n) {
      capacity = n;
      list = new ArrayList<E>(capacity);
      top = -1;
   }//end overloaded constructor 
     
  //size method
   public int size() {
      return top + 1;
   }//end size method   
  
  //isEmpty method
   public boolean isEmpty() {
      if(top == -1) {
         return true;
      }
      return false;
   }//end isEmpty method
   
   //push method
   public void push(E element) {
      top++;
      list.add(top, element);
   }//end push method
   
   //peek method
   public E peek() throws EmptyStackException {
      if(isEmpty()) {
         throw new EmptyStackException("Empty Stack");
      }
      return list.get(top);
   }//end peek method
   
   //pop method
   public E pop() throws EmptyStackException {
      if(isEmpty()) {
         throw new EmptyStackException("Empty Stack");
      }
      
      E temp = list.remove(top);
      top--;
      return temp; 
   
   }//end pop method
  
   public String toString() {
      String result = "";
      
      for(int i = top; i >= 0; i--) {
         result += list.get(i) + "\n";
         
      }//end for loop
      
      return result;
      
   }//end toString
     
}//end of class













