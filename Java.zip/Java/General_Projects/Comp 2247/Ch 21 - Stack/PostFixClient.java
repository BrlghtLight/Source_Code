import java.util.*;

//@SuppressWarnings("unchecked")

public class PostFixClient {
		
   public static void main(String[] args) {
   
      Scanner console = new Scanner(System.in);
      
      //create a stack (MyArrayList) object
      MyArrayListStack<Integer> intStack = new MyArrayListStack<Integer>();
      
      //variables
      String expression;
      String token;
      int operand1, operand2, result = 0;
      String [] tokenList;
      
      //input
      System.out.println("Enter a valid postfix expression: ");
      expression = console.nextLine();
      
      tokenList = expression.split(" ");
      
      for(int i = 0; i < tokenList.length; i++) {
         
         token = tokenList[i]; 
         
         if(token.equals("+") ||
            token.equals("-") || 
            token.equals("*") || token.equals("/")) {
            
            operand2 = intStack.pop();
            operand1 = intStack.pop();
            
               //calculate the result
            result = calculate(operand1, operand2, token);
               
            intStack.push(result);
            
         } else {
            intStack.push(Integer.parseInt(token));    
         }
         
      }//end for loop
   
      System.out.println("Answer: " + result);
   
   }//end of main

   public static int calculate(int operand1, int operand2, String operator) {
   
      int answer = 0;
      
      switch(operator) {
      
         case "+":
            answer = operand1 + operand2;
            break;
         case "-":
            answer = operand1 - operand2;
            break;
         case "*":
            answer = operand1 * operand2;
            break;
         case "/":
            answer = operand1 / operand2;
            break;
      }//end switch
   
      return answer;
   
   }//end calculate

}//end of class













