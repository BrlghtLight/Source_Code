import java.util.*;
import java.util.Stack;

//@SuppressWarnings("unchecked")

public class PalindromeClient {
		
   public static void main(String[] args) {
   
      Scanner console = new Scanner(System.in);
   
      //create a Stack object
      Stack<Character> stack1 = new Stack<Character>();
      Stack<Character> stack2 = new Stack<Character>();
      
      String input;
      
      System.out.println("Enter a string: ");
      input = console.nextLine();
      
      input = input.replaceAll("\\W", ""); //remove white psace and punc.
      
      input = input.toUpperCase();
      
      //push each letter to stack 1 from left to right
      for(int i = 0; i < input.length(); i++) {
         stack1.push(input.charAt(i));
      }//end for loop          
   
      //push each letter to stack2 from the right to left
      for(int i = input.length() - 1; i >= 0; i--) {
         stack2.push(input.charAt(i));
      }//end for loop
   
      //call method to evaluate 
      boolean flag = evaluate(stack1, stack2);
      
      if(flag) {
         System.out.println("Yes, it is a palindrome");
      } else {
         System.out.println("No, not a palindrome");
      }
  
   }//end main

   public static boolean evaluate(Stack stack1, Stack stack2) {
      
      while(!stack1.isEmpty()) {
      
         if(stack1.pop() != stack2.pop()) {
             return false;
         }
      
      }//end while
      
      return true;
   }//end evaluate

}//end of class













