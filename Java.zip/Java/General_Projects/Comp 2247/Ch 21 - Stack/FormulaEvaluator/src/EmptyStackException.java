/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that allows user to enter a formula. 
             Evaluates a formula, and tells user if it is valid or 
             not in regard to the paranthesis.  Menu driven, paranthesis stored
             in a stack.
*/
public class EmptyStackException extends RuntimeException {

    public EmptyStackException(String error) {
        super(error);
    }

}//end class
