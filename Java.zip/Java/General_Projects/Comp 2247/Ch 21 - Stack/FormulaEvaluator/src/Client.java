/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that allows user to enter a formula. 
             Evaluates a formula, and tells user if it is valid or 
             not in regard to the paranthesis.  Menu driven, paranthesis stored
             in a stack.
*/
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        Scanner console = new Scanner(System.in);

        final char PARANTHESIS1 = '(';
        final char PARANTHESIS2 = ')';

        boolean flag = true;
        ArrayListStack<String> formulaStack = new ArrayListStack<>();

        int input;
        String formula = "None";

        while (flag) {

            menu();

            System.out.print("\n|Enter a Command: ");
            input = console.nextInt();

            switch (input) {

                case 1:
                    System.out.print("|Enter a Formula: ");
                    formula = console.next();

                    if (formula.equals("None") != true) {
                        System.out.println("|" + "\n"
                                + "|Formula has been Entered" + "\n"
                                + "|");
                    } else {
                        formula = "None";
                    }

                    break;

                case 2:
                    System.out.println("|Pushing the Formula to the stack");
                    System.out.println("|Evaluating....");

                    for (int i = 0; i < formula.length(); i++) {

                        if (formula.charAt(i) == PARANTHESIS1) {
                            formulaStack.push(Character.toString(PARANTHESIS1));
                        } else if (formula.charAt(i) == PARANTHESIS2) {
                            if (formulaStack.isEmpty()) {
                                System.out.println("|Cannot pop from an empty stack");
                                formula = "False";
                            } else {
                                formulaStack.pop();
                            }
                        }

                    }//end for loop

                    if (formula.equals("False") != true && formula.equals("None") != true) {
                        if (formulaStack.isEmpty()) {
                            System.out.println("|Formula is valid");
                        } else if (formulaStack.isEmpty() != true) {
                            System.out.println("|Formula is not valid");
                        }
                    } else if (formula.equals("None")) {
                        System.out.println("|No formula was entered");
                    } else if (formula.equals("False")) {
                        System.out.println("|Formula is not valid");
                    }

                    formula = "None";

                    break;

                case 0:
                    System.out.println("|Exiting....");
                    flag = false;
                    break;

                default:
                    System.out.println("|Invalid Input, Try Again");
                    break;

            }//end switch

        }//end while loop

    }//end of main()

    public static void menu() {
        System.out.print(
                "__________________________________________" + "\n"
                + "|                                        |" + "\n"
                + "| Formula Evaluator Client               |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
                + "| 1 --- Enter a Formula                  |" + "\n"
                + "| 2 --- Evaluate the Formula             |" + "\n"
                + "| 0 --- Exit                             |" + "\n"
                + "| ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ |" + "\n"
                + "|________________________________________|"
        );
    }

}//end of class
