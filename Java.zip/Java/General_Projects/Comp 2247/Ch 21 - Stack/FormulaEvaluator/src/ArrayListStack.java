/*
Author: Marcus Walbridge
Professor: Jim Ma
Course: Comp 2247
Assignment: Assignment 7
Date: 4/25/2018
Description: Program that allows user to enter a formula. 
             Evaluates a formula, and tells user if it is valid or 
             not in regard to the paranthesis.  Menu driven, paranthesis stored
             in a stack.
*/
import java.util.*;

@SuppressWarnings("unchecked")

public class ArrayListStack<E> implements StackInterface<E> {

  //data members
   private ArrayList<E> list;
   public static final int CAPACITY = 12;
   private int capacity;
   private int top;
  
  //default constructor
   public ArrayListStack() {
      this(CAPACITY);
   }//end default constructor
  
  //overloaded constructor
   public ArrayListStack(int n) {
      capacity = n;
      list = new ArrayList<E>(capacity);
      top = -1;
   }//end overloaded constructor 
     
  //size method
   @Override
   public int size() {
      return top + 1;
   }//end size method   
  
  //isEmpty method
   @Override
   public boolean isEmpty() {
      if(top == -1) {
         return true;
      }
      return false;
   }//end isEmpty method
   
   //push method
   @Override
   public void push(E element) {
      top++;
      list.add(top, element);
   }//end push method
   
   //peek method
   @Override
   public E peek() throws EmptyStackException {
      if(isEmpty()) {
         throw new EmptyStackException("Empty Stack");
      }
      return list.get(top);
   }//end peek method
   
   //pop method

    /**
     *
     * @return
     * @throws EmptyStackException
     */
   @Override
   public E pop() throws EmptyStackException {
      if(isEmpty()) {
         throw new EmptyStackException("Empty Stack");
      }
      
      E temp = list.remove(top);
      top--;
      return temp; 
   
   }//end pop method
  
   @Override
   public String toString() {
      String result = "";
      
      for(int i = top; i >= 0; i--) {
         result += list.get(i) + "\n";
         
      }//end for loop
      
      return result;
      
   }//end toString
     
}//end of class













