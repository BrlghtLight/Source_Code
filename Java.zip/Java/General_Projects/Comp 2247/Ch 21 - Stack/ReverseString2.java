import java.util.*;
import java.util.Stack;

//@SuppressWarnings("unchecked")

public class ReverseString {
		
   public static void main(String[] args) {
   
      Scanner console = new Scanner(System.in);
   
      //create a Stack object
      Stack<String> stackOne = new Stack<String>();
      
      //variables
      String input;
      String token;
      String [] tokenList;
      
      //input a string
      System.out.print("Enter a string: ");
      input = console.nextLine();
      
      //split the input string into the token list
      tokenList = input.split(" ");
      
      //push each token into the stack
      for(int i = 0; i < tokenList.length; i++) {
         stackOne.push(tokenList[i]);         
      }
      
      //print the stack
      System.out.println("\n\nIn reverse order: ");
      
     //print 
     while(!stackOne.isEmpty()) {
        System.out.print(stackOne.pop() + " ");
     }
      
   }//end main

}//end of class













