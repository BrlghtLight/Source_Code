/*
 *Author: Marcus Walbridge  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Date, person and student classes.  Utilized by a GUI client
               to collect user input and create a student object.  
               Updates phone number, prints the student object's information and
               can reset the program to start over(clear student object).
 */

import java.util.ArrayList;

public class Student {

    //data members
    private int id;
    private String major;
    private double gpa;
   
    //aggregation
    PersonInfo person;
    MyDate birthDate;
    MyDate admissionDate;

    //default cosntructor
    public Student() {
    }

    //overloaded constructor
    public Student(int id, String major, double gpa, PersonInfo person, 
            MyDate birthDate, MyDate admissionDate) {
        
        this.id = id;
        this.major = major;
        if (this.gpa >= 0) {
            this.gpa = gpa;
        } else {
            this.gpa = 0;
        }
        this.person = person;
        this.birthDate = birthDate;
        this.admissionDate = admissionDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        if (this.gpa >= 0) {
            this.gpa = gpa;
        } else {
            this.gpa = 0;
        }
    }

    public PersonInfo getPerson() {
        return person;
    }

    public void setPerson(PersonInfo person) {
        this.person = person;
    }

    public MyDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(MyDate birthDate) {
        this.birthDate = birthDate;
    }

    public MyDate getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(MyDate admissionDate) {
        this.admissionDate = admissionDate;
    }

    @Override
    public String toString() {
        return "Student:\n"
                + "ID: " + id + "\n"
                + "Major: " + major + "\n"
                + String.format("GPA: %.2f", gpa) + "\n"
                + person + "\n" 
                + "Birth Date: " + birthDate + "\n"
                + "Admission Date: " + admissionDate;
    }

}//end class
