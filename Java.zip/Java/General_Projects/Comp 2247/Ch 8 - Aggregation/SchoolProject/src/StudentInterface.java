/*
 *Author: Marcus Walbridge  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Date, person and student classes.  Utilized by a GUI client
               to collect user input and create a student object.  
               Updates phone number, prints the student object's information and
               can reset the program to start over(clear student object).
 */

import java.util.ArrayList;

public class StudentInterface extends javax.swing.JFrame {

    //data members
    Student someStudent;
    MyDate birthDate;
    MyDate admissionDate;
    ArrayList<Student> studentList = new ArrayList<Student>();

    public StudentInterface() {

        initComponents();

        updateButton.setEnabled(false);
        printButton.setEnabled(false);
        clearButton.setEnabled(false);
        resetButton.setEnabled(false);
        outputArea.setEditable(false);

    }//end StudentInterface

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backgroundPanel = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        outputArea = new javax.swing.JTextArea();
        firstLabel = new javax.swing.JLabel();
        lastLabel = new javax.swing.JLabel();
        genderLabel = new javax.swing.JLabel();
        phoneLabel = new javax.swing.JLabel();
        birthLabel = new javax.swing.JLabel();
        idLabel = new javax.swing.JLabel();
        majorLabel = new javax.swing.JLabel();
        gpaLabel = new javax.swing.JLabel();
        admissionLabel = new javax.swing.JLabel();
        firstNameField = new javax.swing.JTextField();
        lastNameField = new javax.swing.JTextField();
        genderField = new javax.swing.JTextField();
        phoneField = new javax.swing.JTextField();
        birthField = new javax.swing.JTextField();
        idField = new javax.swing.JTextField();
        majorField = new javax.swing.JTextField();
        gpaField = new javax.swing.JTextField();
        admissionField = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Student Program");

        backgroundPanel.setBackground(new java.awt.Color(0, 0, 0));
        backgroundPanel.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 255, 0)));

        titleLabel.setFont(new java.awt.Font("Sylfaen", 3, 24)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(0, 255, 0));
        titleLabel.setText("Student Program");

        outputArea.setColumns(20);
        outputArea.setRows(5);
        jScrollPane1.setViewportView(outputArea);

        firstLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        firstLabel.setForeground(new java.awt.Color(51, 255, 0));
        firstLabel.setText("First Name:");

        lastLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        lastLabel.setForeground(new java.awt.Color(51, 255, 0));
        lastLabel.setText("Last Name:");

        genderLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        genderLabel.setForeground(new java.awt.Color(51, 255, 0));
        genderLabel.setText("Gender:");

        phoneLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        phoneLabel.setForeground(new java.awt.Color(51, 255, 0));
        phoneLabel.setText("Phone Number:");

        birthLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        birthLabel.setForeground(new java.awt.Color(51, 255, 0));
        birthLabel.setText("Birth Date:");

        idLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        idLabel.setForeground(new java.awt.Color(51, 255, 0));
        idLabel.setText("Student ID:");

        majorLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        majorLabel.setForeground(new java.awt.Color(51, 255, 0));
        majorLabel.setText("Major:");

        gpaLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        gpaLabel.setForeground(new java.awt.Color(51, 255, 0));
        gpaLabel.setText("GPA:");

        admissionLabel.setFont(new java.awt.Font("Sylfaen", 0, 12)); // NOI18N
        admissionLabel.setForeground(new java.awt.Color(51, 255, 0));
        admissionLabel.setText("Admission Date:");

        addButton.setBackground(new java.awt.Color(0, 0, 0));
        addButton.setFont(new java.awt.Font("Sylfaen", 1, 12)); // NOI18N
        addButton.setForeground(new java.awt.Color(51, 255, 0));
        addButton.setText("Add Student");
        addButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 255, 0)));
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setBackground(new java.awt.Color(0, 0, 0));
        updateButton.setFont(new java.awt.Font("Sylfaen", 1, 12)); // NOI18N
        updateButton.setForeground(new java.awt.Color(51, 255, 0));
        updateButton.setText("Update Phone");
        updateButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 255, 0)));
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        printButton.setBackground(new java.awt.Color(0, 0, 0));
        printButton.setFont(new java.awt.Font("Sylfaen", 1, 12)); // NOI18N
        printButton.setForeground(new java.awt.Color(51, 255, 0));
        printButton.setText("Print Info");
        printButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 255, 0)));
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });

        clearButton.setBackground(new java.awt.Color(0, 0, 0));
        clearButton.setFont(new java.awt.Font("Sylfaen", 1, 12)); // NOI18N
        clearButton.setForeground(new java.awt.Color(51, 255, 0));
        clearButton.setText("Clear");
        clearButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 255, 0)));
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        resetButton.setBackground(new java.awt.Color(0, 0, 0));
        resetButton.setFont(new java.awt.Font("Sylfaen", 1, 12)); // NOI18N
        resetButton.setForeground(new java.awt.Color(51, 255, 0));
        resetButton.setText("Reset");
        resetButton.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(51, 255, 0)));
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundPanelLayout = new javax.swing.GroupLayout(backgroundPanel);
        backgroundPanel.setLayout(backgroundPanelLayout);
        backgroundPanelLayout.setHorizontalGroup(
            backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(backgroundPanelLayout.createSequentialGroup()
                            .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(firstLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(phoneLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(birthLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(idLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(majorLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(gpaLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(admissionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                                .addComponent(lastLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(genderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(33, 33, 33)
                            .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(majorField)
                                .addComponent(idField)
                                .addComponent(birthField)
                                .addComponent(phoneField)
                                .addComponent(genderField)
                                .addComponent(lastNameField)
                                .addComponent(firstNameField)
                                .addComponent(gpaField)
                                .addComponent(admissionField, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
                            .addGap(10, 10, 10)
                            .addComponent(jScrollPane1))
                        .addGroup(backgroundPanelLayout.createSequentialGroup()
                            .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(printButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(resetButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        backgroundPanelLayout.setVerticalGroup(
            backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(titleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(backgroundPanelLayout.createSequentialGroup()
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(firstLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(firstNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lastLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lastNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(genderLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(genderField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(phoneLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phoneField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(birthLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(birthField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(majorLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(majorField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(gpaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gpaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(admissionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(admissionField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(backgroundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(updateButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(printButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(clearButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(resetButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backgroundPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backgroundPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        //local variables
        String firstName;
        String lastName;
        String gender;
        String phoneNumber;
        String birthDay;
        int ID;
        String major;
        double gpa;
        String admissionDay;

        //retrieve information from user
        firstName = firstNameField.getText();
        lastName = lastNameField.getText();
        gender = genderField.getText();
        phoneNumber = phoneField.getText();
        birthDay = birthField.getText();
        ID = Integer.parseInt(idField.getText());
        major = majorField.getText();
        gpa = Double.parseDouble(gpaField.getText());
        admissionDay = admissionField.getText();

        int startMonth = Integer.parseInt(birthDay.substring(0,
                birthDay.indexOf("/")));
        
        int startDay = Integer.parseInt(birthDay.
                substring(birthDay.indexOf("/")
                        + 1, birthDay.lastIndexOf("/")));
        
        int startYear = Integer.parseInt(birthDay.
                substring(birthDay.lastIndexOf("/")
                        + 1));

        int endMonth = Integer.parseInt(admissionDay.substring(0,
                admissionDay.indexOf("/")));
        
        int endDay = Integer.parseInt(admissionDay.
                substring(admissionDay.indexOf("/")
                        + 1, admissionDay.lastIndexOf("/")));
        
        int endYear = Integer.parseInt(admissionDay.
                substring(admissionDay.lastIndexOf("/")
                        + 1));

        studentList.add(new Student(ID, major, gpa,
                new PersonInfo(firstName, lastName, gender, phoneNumber),
                new MyDate(startMonth, startDay, startYear),
                new MyDate(endMonth, endDay, endYear)));

        //print the new student's info
        for (int i = 0; i < studentList.size(); i++) {

            outputArea.append("\n" + studentList.get(i));

        }//end for loop

        //enable other buttons now that a student is added
        updateButton.setEnabled(true);
        printButton.setEnabled(true);
        clearButton.setEnabled(true);
        resetButton.setEnabled(true);

        //disable fields until reset button is pressed
        firstNameField.setEditable(false);
        lastNameField.setEditable(false);
        genderField.setEditable(false);
        birthField.setEditable(false);
        idField.setEditable(false);
        majorField.setEditable(false);
        gpaField.setEditable(false);
        admissionField.setEditable(false);
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        outputArea.setText("");
        studentList.get(0).getPerson().setPhoneNumber(phoneField.getText());
        outputArea.setText("\nPhone Number Updated.\n");
    }//GEN-LAST:event_updateButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        //print the new student's info
        for (int i = 0; i < studentList.size(); i++) {

            outputArea.setText("\n" + studentList.get(i));

        }//end for loop
    }//GEN-LAST:event_printButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        outputArea.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        genderField.setText("");
        phoneField.setText("");
        birthField.setText("");
        idField.setText("");
        majorField.setText("");
        gpaField.setText("");
        admissionField.setText("");
    }//GEN-LAST:event_clearButtonActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        //clear student list so program is reset
        studentList.clear();

        firstNameField.setText("");
        lastNameField.setText("");
        genderField.setText("");
        phoneField.setText("");
        birthField.setText("");
        idField.setText("");
        majorField.setText("");
        gpaField.setText("");
        admissionField.setText("");
        outputArea.setText("");

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        printButton.setEnabled(false);
        clearButton.setEnabled(false);
        resetButton.setEnabled(false);

        firstNameField.setEditable(true);
        lastNameField.setEditable(true);
        genderField.setEditable(true);
        birthField.setEditable(true);
        idField.setEditable(true);
        majorField.setEditable(true);
        gpaField.setEditable(true);
        admissionField.setEditable(true);
    }//GEN-LAST:event_resetButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StudentInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StudentInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StudentInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StudentInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentInterface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JTextField admissionField;
    private javax.swing.JLabel admissionLabel;
    private javax.swing.JPanel backgroundPanel;
    private javax.swing.JTextField birthField;
    private javax.swing.JLabel birthLabel;
    private javax.swing.JButton clearButton;
    private javax.swing.JLabel firstLabel;
    private javax.swing.JTextField firstNameField;
    private javax.swing.JTextField genderField;
    private javax.swing.JLabel genderLabel;
    private javax.swing.JTextField gpaField;
    private javax.swing.JLabel gpaLabel;
    private javax.swing.JTextField idField;
    private javax.swing.JLabel idLabel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lastLabel;
    private javax.swing.JTextField lastNameField;
    private javax.swing.JTextField majorField;
    private javax.swing.JLabel majorLabel;
    private javax.swing.JTextArea outputArea;
    private javax.swing.JTextField phoneField;
    private javax.swing.JLabel phoneLabel;
    private javax.swing.JButton printButton;
    private javax.swing.JButton resetButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
