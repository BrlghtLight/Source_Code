/*
 *Author: Marcus Walbridge  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Date, person and student classes.  Utilized by a GUI client
               to collect user input and create a student object.  
               Updates phone number, prints the student object's information and
               can reset the program to start over(clear student object).
 */

public class PersonInfo {

    //data members
    private String firstName;
    private String lastName;
    private String gender;
    protected String phoneNumber;

    //default constructor
    public PersonInfo() {
    }

    //overloaded constructor
    public PersonInfo(String firstName, String lastName, String gender, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber (String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "First Name: " + firstName + "\n"
                + "Last Name: " + lastName + "\n"
                + "Gender: " + gender + "\n"
                + "Phone Number: " + phoneNumber;
    }

}//end class
