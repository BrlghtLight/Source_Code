/*
 *Author: Marcus Walbridge & Jacob Wilder  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Bill, Doctor, MyDate, Person and Patient classes.  Used by 
               HospitalClient to create patient and bill objects.  Menu driven
               client that can print the patient's info and the bill info after
               collecting user input.  ID and fees are validated.
 */

import java.util.Calendar;

public class Patient {

//data members
    private int patientID;
    private Person patient;
    private Doctor doctor;
    private MyDate patientBirth;
    private MyDate pAdmitDate;
    private MyDate pDischargeDate;

    public Patient() {
    }

    public Patient(int patientID, Person patient, Doctor doctor,
            MyDate patientBirth, MyDate pAdmitDate, MyDate pDischargeDate) {
        this.patientID = patientID;
        this.patient = patient;
        this.doctor = doctor;
        this.patientBirth = patientBirth;
        this.pAdmitDate = pAdmitDate;
        this.pDischargeDate = pDischargeDate;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public Person getPatient() {
        return patient;
    }

    public void setPatient(Person patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public MyDate getPatientBirth() {
        return patientBirth;
    }

    public void setPatientBirth(MyDate patientBirth) {
        this.patientBirth = patientBirth;
    }

    public MyDate getpAdmitDate() {
        return pAdmitDate;
    }

    public void setpAdmitDate(MyDate pAdmitDate) {
        this.pAdmitDate = pAdmitDate;
    }

    public MyDate getpDischargeDate() {
        return pDischargeDate;
    }

    public void setpDischargeDate(MyDate pDischargeDate) {
        this.pDischargeDate = pDischargeDate;
    }

    private int years = 0;

    public int calculatePatientAge() {
        Calendar cal = Calendar.getInstance();
        years = cal.get(Calendar.YEAR) - getPatientBirth().getYear();
        if (cal.get(Calendar.MONTH) < getPatientBirth().getMonth()) {
            years -= 1;
        }
        if (cal.get(Calendar.MONTH) == getPatientBirth().getMonth()) {
            if (cal.get(Calendar.DATE) < getPatientBirth().getDay()) {
                years -= 1;
            }
        }
        return years;
    }

    @Override
    public String toString() {
        return "\n\n--------------------------------"
                + "\nID: " + patientID
                + "\nPatient: " + patient
                + ", " + calculatePatientAge() + " years old"
                + "\n" + doctor
                + "\nPatient's Birth Date: " + patientBirth
                + "\nPatient's Admission Date: " + pAdmitDate
                + "\nPatient's Discharge Date: " + pDischargeDate
                + "\n--------------------------------";
    }
}
