/*
 *Author: Marcus Walbridge & Jacob Wilder  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Bill, Doctor, MyDate, Person and Patient classes.  Used by 
               HospitalClient to create patient and bill objects.  Menu driven
               client that can print the patient's info and the bill info after
               collecting user input.  ID and fees are validated.
 */

public class Bill {

    private int id;
    private double medicineFee;
    private double doctorFee;
    private double roomFee;

    public Bill() {
    }

    public Bill(int id, double medicineFee, double doctorFee, double roomFee) {
        this.id = id;
        this.medicineFee = medicineFee;
        this.doctorFee = doctorFee;
        this.roomFee = roomFee;

        //ensure the fees are not negative
        if (id < 0) {
            this.id = 0;
        }
        if (medicineFee < 0) {
            this.medicineFee = 0;
        }
        if (doctorFee < 0) {
            this.doctorFee = 0;
        }
        if (roomFee < 0) {
            this.roomFee = 0;
        }

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getMedicineFee() {
        return medicineFee;
    }

    public void setMedicineFee(double medicineFee) {
        this.medicineFee = medicineFee;
    }

    public double getDoctorFee() {
        return doctorFee;
    }

    public void setDoctorFee(double doctorFee) {
        this.doctorFee = doctorFee;
    }

    public double getRoomFee() {
        return roomFee;
    }

    public void setRoomFee(double roomFee) {
        this.roomFee = roomFee;
    }

    //get total bill
    public double calculateBill() {

        return (this.medicineFee + this.doctorFee + this.roomFee);

    }//end calculateBill

    @Override
    public String toString() {
        return "\n\n--------------------------------" + "\n"
                + "Bill:" + "\n"
                + "Patient ID: " + id + "\n"
                + String.format("Medicine Fee: $%.2f", medicineFee) + "\n"
                + String.format("Doctor Fee: $%.2f", doctorFee) + "\n"
                + String.format("Room Fee: $%.2f", roomFee) + "\n"
                + String.format("\n\nTotal charge: $%.2f", calculateBill())
                + "\n--------------------------------";
    }

}//end Bill
