/*
 *Author: Marcus Walbridge & Jacob Wilder  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Bill, Doctor, MyDate, Person and Patient classes.  Used by 
               HospitalClient to create patient and bill objects.  Menu driven
               client that can print the patient's info and the bill info after
               collecting user input.  ID and fees are validated.
 */

public class MyDate {

    //data members
    private int month;
    private int day;
    private int year;

    //default constructor
    public MyDate() {
    }

    //overloaded constructor
    public MyDate(int month, int day, int year) {
        this.month = month;
        this.day = day;
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return month + "/" + day + "/" + year;
    }

}//end class
