/*
 *Author: Marcus Walbridge & Jacob Wilder  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Bill, Doctor, MyDate, Person and Patient classes.  Used by 
               HospitalClient to create patient and bill objects.  Menu driven
               client that can print the patient's info and the bill info after
               collecting user input.  ID and fees are validated.
 */

import java.io.IOException;
import java.util.Scanner;

public class HospitalClient {

    public static void main(String[] args) throws IOException {

        Scanner console = new Scanner(System.in);

        //variables
        boolean flag = true;

        //initialize pID for upcoming do-while loop
        int pID = 0,
                input, aDay, aMonth, aYear, bDay,
                bMonth, bYear, dDay, dMonth, dYear;

        String pFirstName, pLastName, dFirstName, dLastName, dSpecialty,
                pBirthDate, admissionDate, dischargeDate;

        double pharmacyCharge, doctorFee, roomCharge;

        //user input
        System.out.println("*****************************"
                + "**************************");

        System.out.print("Hospital Billing System Program\n");

        //ensure ID is not negative
        do {
            System.out.print("\nEnter patient's ID: ");
            pID = console.nextInt();

            if (pID < 0) {
                System.out.println("\nInvalid ID, try again.");
            } else {
                flag = false;
            }

        } while (flag);

        System.out.print("Enter patient's first name: ");
        pFirstName = console.next();

        System.out.print("Enter patient's last name: ");
        pLastName = console.next();

        System.out.print("\n\nEnter doctor's first name: ");
        dFirstName = console.next();

        System.out.print("Enter doctors's last name: ");
        dLastName = console.next();

        System.out.print("Enter doctor's specialty: ");
        dSpecialty = console.next();

        //ensure a valid birth date is entered.
        System.out.print("\n\nEnter patients birth date (xx/xx/xxxx): ");
        pBirthDate = console.next();
        bMonth = Integer.parseInt(pBirthDate.substring(0, pBirthDate.indexOf("/")));
        bDay = Integer.parseInt(pBirthDate.substring(pBirthDate.indexOf("/") + 1, pBirthDate.lastIndexOf("/")));
        bYear = Integer.parseInt(pBirthDate.substring(pBirthDate.lastIndexOf("/") + 1));

        System.out.print("Enter patients admission date (xx/xx/xxxx): ");
        admissionDate = console.next();
        aMonth = Integer.parseInt(admissionDate.substring(0, admissionDate.indexOf("/")));
        aDay = Integer.parseInt(admissionDate.substring(admissionDate.indexOf("/") + 1, admissionDate.lastIndexOf("/")));
        aYear = Integer.parseInt(admissionDate.substring(admissionDate.lastIndexOf("/") + 1));

        System.out.print("Enter patients discharge date (xx/xx/xxxx): ");
        dischargeDate = console.next();
        dMonth = Integer.parseInt(dischargeDate.substring(0, dischargeDate.indexOf("/")));
        dDay = Integer.parseInt(dischargeDate.substring(dischargeDate.indexOf("/") + 1, dischargeDate.lastIndexOf("/")));
        dYear = Integer.parseInt(dischargeDate.substring(dischargeDate.lastIndexOf("/") + 1));

        flag = true;

        System.out.print("\n");

        do {

            //ensure fees aren't negative
            System.out.print("\nEnter pharmacy charge: ");
            pharmacyCharge = console.nextDouble();

            System.out.print("Enter doctor's fee: ");
            doctorFee = console.nextDouble();

            System.out.print("Enter room charge: ");
            roomCharge = console.nextDouble();

            if (pharmacyCharge < 0 || doctorFee < 0 || roomCharge < 0) {
                System.out.println("\nFees cannot be negative, Try again.");
            } else {
                flag = false;
            }

        } while (flag);

        System.out.println("*****************************"
                + "**************************");

        //create objects using user input
        Patient patient = new Patient(pID, new Person(pFirstName, pLastName),
                new Doctor(new Person(dFirstName, dLastName), dSpecialty),
                new MyDate(bMonth, bDay, bYear),
                new MyDate(aMonth, aDay, aYear),
                new MyDate(dMonth, dDay, dYear));

        Bill bill = new Bill(pID, pharmacyCharge, doctorFee, roomCharge);

        flag = true;

        //display menu for user
        while (flag) {

            showMenu();

            System.out.print("Please Enter a Command: ");
            input = console.nextInt();

            switch (input) {

                case 1:

                    System.out.print(patient + "");
                    break;

                case 2:

                    System.out.print(bill + "");
                    break;

                case 0:

                    flag = false;

                    break;

                default:

                    System.out.println("\nInvalid Command, try again.");

                    break;

            }//End switch

        }//end while

    }//end main method

    //create store menu
    private static void showMenu() {
        System.out.print("\n\n"
                + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
                + "1 --- Print Patient Information\n"
                + "2 --- Print Billing Information\n"
                + "0 --- Exit\n"
                + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    }//end menu

}//end HospitalClient
