/*
 *Author: Marcus Walbridge & Jacob Wilder  
 *Date: 2/05/2018
 *Assignment: Assignment #2
 *Description: Bill, Doctor, MyDate, Person and Patient classes.  Used by 
               HospitalClient to create patient and bill objects.  Menu driven
               client that can print the patient's info and the bill info after
               collecting user input.  ID and fees are validated.
 */

public class Person {

    private String firstName;
    private String lastName;

    public Person() {
    }

    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }

}
