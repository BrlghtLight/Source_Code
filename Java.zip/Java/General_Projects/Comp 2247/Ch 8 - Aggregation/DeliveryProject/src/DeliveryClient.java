
public class DeliveryClient {

    public static void main(String[] args) {

        Parcel p1;

        p1 = new Parcel(20090, 12.56, 5.4,
                new Person("Jon", "Doe", "123 Main St.", "SomeCity", "MN", "99121"),
                new Person("Mary", "Jane", "888 2nd St.", "AnotherCity", "MN", "99412"),
                new Date(1, 24, 2018),
                new Date(1, 26, 2018));

        System.out.println(p1);
        System.out.println("Delivery Cost: $" + p1.calculateDeliveryCost());
        System.out.println();

        //change delivery date
        p1.setDeliveryDate(new Date(1, 28, 2018));

        //print recipient's name
        System.out.println("Recipient: " 
                           + p1.getRecipient().getFirstName() + " "
                           + p1.getRecipient().getLastName());
        
    }//end main

}//end class
