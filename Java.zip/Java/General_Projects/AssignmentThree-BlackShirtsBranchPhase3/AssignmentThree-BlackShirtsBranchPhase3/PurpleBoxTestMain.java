package purpleBox;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Map.Entry;
import java.util.Scanner;

public class PurpleBoxTestMain {

	static Scanner console = new Scanner(System.in);

	public static void main(String[] args) {

		// variables
		PurpleBox purpleBox = new PurpleBox();
		purpleBox.setAllProducts(createProductList());
		purpleBox.setMovieList(createMovieList(purpleBox.getAllProducts()));
		purpleBox.setGameList(createGameList(purpleBox.getAllProducts()));
		purpleBox.setCart(createCart());
		createPromoCodes(purpleBox);

		while (true) {
			int result = printMenuTextVariableOptions("Welcome!\n\n" + "  1 -- Rent a Movie\n" + "  2 -- Rent a Game\n"
					+ "  3 -- View Cart / Checkout\n" + "  4 -- Login as Admin\n" + "  5 -- Exit PurpleBox\n", 1, 5);
			if (result == 1) {
				printProductMenu("Movie", "Action, Comedy, Documentary, Drama, Family, Horror, Romance, Sci-Fi",
						purpleBox.getMovieList(), purpleBox);
			} else if (result == 2) {
				printProductMenu("Game", "FPS, MMORPG, Strategy, Racing", purpleBox.getGameList(), purpleBox);
			} else if (result == 3) {
				while (true) {
					int cartChoice = printMenuTextVariableOptions("View Cart and Checkout\n" + "  1 -- View Cart\n"
							+ "  2 -- Checkout\n" + "  3 -- Return to Main Menu\n", 1, 3);
					if (cartChoice == 1) {
						System.out.println("Your current cart contains the following items: ");
						printProduct(purpleBox.getCart());
					} else if (cartChoice == 2) {
						purpleBox.checkout();
					} else if (cartChoice == 3) {
						break;
					}
				}
			} else if (result == 4) {
				while (true) {
					int adminChoice = printMenuTextVariableOptions("Admin Menu\n" + "  1 -- Add product to inventory\n"
							+ "  2 -- Remove product from inventory\n" + "  3 -- Change prices for DVDs\n"
							+ "  4 -- Change prices for Blu-rays\n" + "  5 -- Change prices for all games\n"
							+ "  6 -- Set Volume discount\n" + "  7 -- Add Promo Code\n" + "  8 -- Enable Unit\n"
							+ "  9 -- Return to Main Menu\n", 1, 9);
					if (adminChoice == 1) {
						while (true) {

							System.out.println("Enter product information to add to the inventory.");
							System.out.print("Please enter title: ");
							String name = console.nextLine();
							System.out.print("Please enter genre: ");
							String genre = console.nextLine();
							System.out.print("Please enter media type from the following: DVD, BluRay, PS4, Xbox ");
							String mediaType = console.nextLine();
							System.out.print("Please enter release date: ");
							String releaseDate = console.nextLine();
							System.out.print("Please enter metascore: ");
							int metaScore = console.nextInt();
							System.out.print("Please enter price: ");
							double price = console.nextDouble();

							boolean isAvailable = true;
							Product newProduct = new Product(name, genre, mediaType, releaseDate, metaScore, price,
									isAvailable);
							purpleBox.addProductToInventory(newProduct);
							if (mediaType.equalsIgnoreCase("DVD") || mediaType.equalsIgnoreCase("BluRay")) {
								purpleBox.addProductToMovieInventory(newProduct);
								System.out.println("Product " + name + " successfully added to inventory.");
								break;
							} else if (mediaType.equalsIgnoreCase("PS4") || mediaType.equalsIgnoreCase("Xbox")) {
								purpleBox.addProductToGameInventory(newProduct);
								break;
							} else {
								System.out.println("Unknown Input. Please try again.");
							}
						}

					} else if (adminChoice == 2) {
						String userInput = getStringInput("Enter a title to be removed from inventory: ");
						ArrayList<Product> foundProducts = purpleBox.searchByName(purpleBox.getAllProducts(),
								userInput);
						if (foundProducts.isEmpty()) {
							System.out.println("Product not found, please try again.");
						} else {
							printProduct(foundProducts);
							for (Product productToRemove : foundProducts) {
								purpleBox.removeProductFromInventory(productToRemove);
								System.out.println("Product " + productToRemove.getName()
										+ " has been successfully removed from the inventory.");
							}
						}
						break;
					} else if (adminChoice == 3) {
						double newDVDPrice = 0.0;
						System.out.println("Enter new price for all DVDs.");
						newDVDPrice = console.nextDouble();
						purpleBox.changeDVDPrice(newDVDPrice);
						System.out.println("Price of all DVDs has been changed to " + "$" + newDVDPrice + ".");
					} else if (adminChoice == 4) {
						double newBluRayPrice = 0.0;
						System.out.println("Enter new price for all DVDs.");
						newBluRayPrice = console.nextDouble();
						purpleBox.changeBluRayPrice(newBluRayPrice);
						System.out.println("Price of all DVDs has been changed to " + "$" + newBluRayPrice + ".");
					} else if (adminChoice == 5) {
						double newGamesPrice = 0.0;
						System.out.println("Enter new price for all games.");
						newGamesPrice = console.nextDouble();
						purpleBox.changeGamePrice(newGamesPrice);
						System.out.println("Price of all DVDs has been changed to " + "$" + newGamesPrice + ".");
					} else if (adminChoice == 6) {
						double newVolumeDiscount = 0.0;
						System.out.println("Set a new volume discount for all products.");
						newVolumeDiscount = console.nextDouble();
						purpleBox.setVolumeDiscount(newVolumeDiscount);
						System.out.println("A new volume discount of " + newVolumeDiscount + " has been set.");
					} else if (adminChoice == 7) {
						String newPromoCodeName = null;
						double newDiscountForPromoCode = 0.0;
						System.out.println("Please enter the name for a new promo code: ");
						newPromoCodeName = console.next();
						System.out.println("Please enter the desired discount rate for new promo code: ");
						newDiscountForPromoCode = console.nextDouble();
						purpleBox.setPromoCodes(newPromoCodeName, newDiscountForPromoCode);
						for (Entry<String, Double> row : purpleBox.getPromoCodes().entrySet()) {
							System.out.println("Found promo code " + row.getKey() + " as value " + row.getValue());
						}
						System.out.println("Operation successful");

					} else if (adminChoice == 8) {
						boolean unitEnabled = false;
						System.out.println("Would you like to enable the unit? Enter true or false.");
						unitEnabled = console.nextBoolean();
						purpleBox.enableUnit(unitEnabled);
						System.out.println("Unit has been enabled.");
					} else if (adminChoice == 9) {
						break;
					}
				}
			} else if (result == 5) {
				System.out.println("Thank you for using PurpleBox the complete rip off of Red Box!!!");
				System.exit(0);
			}
		}

	}

	public static void printProductMenu(String mediaType, String genreType, ArrayList<Product> productList,
			PurpleBox purpleBox) {
		while (true) {
			int productChoice = printMenuTextVariableOptions("Rent a " + mediaType + "\n" + "  1 -- View All "
					+ mediaType + "\n" + "  2 -- Search by Name\n" + "  3 -- Search by Genre\n"
					+ "  4 -- Search by Disc Type\n" + "  5 -- Search by Release Date\n"
					+ "  6 -- Search by MetaScore\n" + "  7 -- Return to Main Menu\n", 1, 7);
			if (productChoice == 1) {
				printProduct(purpleBox.getMovieList());
			} else if (productChoice == 2) {
				String userInput = getStringInput("Enter " + mediaType + " title: ");
				ArrayList<Product> foundMovies = purpleBox.searchByName(productList, userInput);
				if (foundMovies.isEmpty()) {
					System.out.println("Product not found.");
				} else {
					printProduct(foundMovies);
					makeSelectionMenu(foundMovies, purpleBox);
				}
			} else if (productChoice == 3) {
				String userInput = getStringInput("Enter a genre from the following list:  " + genreType);
				ArrayList<Product> foundGenres = purpleBox.searchByGenre(productList, userInput);
				if (foundGenres.isEmpty()) {
					System.out.println("Genre not found.");
				} else {
					printProduct(foundGenres);
					makeSelectionMenu(foundGenres, purpleBox);
				}
			} else if (productChoice == 4) {
				String userInput = getStringInput("Enter a format from the following list: DVD or BluRay ");
				ArrayList<Product> foundFormats = purpleBox.searchByFormat(productList, userInput);
				if (foundFormats.isEmpty()) {
					System.out.println("Format not found.");
				} else {
					printProduct(foundFormats);
					makeSelectionMenu(foundFormats, purpleBox);
				}
			} else if (productChoice == 5) {
				String userInput = getStringInput(
						"Enter a release date from the following list: 2016, 2017, 2018, 2019 ");
				ArrayList<Product> foundReleaseDates = purpleBox.searchByReleaseDate(productList, userInput);
				if (foundReleaseDates.isEmpty()) {
					System.out.println("Release date not found.");
				} else {
					printProduct(foundReleaseDates);
					makeSelectionMenu(foundReleaseDates, purpleBox);
				}
			} else if (productChoice == 6) {
				int userInput = getIntInput("Enter a metascore from the following list: 1, 2, 3, 4, 5 ");
				ArrayList<Product> foundMetaScores = purpleBox.searchByMetaScore(productList, userInput);
				if (foundMetaScores.isEmpty()) {
					System.out.println("Metascores not found.");
				} else {
					printProduct(foundMetaScores);
					makeSelectionMenu(foundMetaScores, purpleBox);
				}
			} else if (productChoice == 7) {
				break;
			}
		}
	}

	public static void printProduct(ArrayList<Product> selectedProducts) {
		for (Product thisProduct : selectedProducts) {
			System.out.println(thisProduct);
			System.out.println();
		}
	}

	public static String getStringInput(String textToPrint) {
		System.out.println(textToPrint);
		String textInput = console.next();
		return textInput;
	}

	public static int getIntInput(String textToPrint) {
		System.out.println(textToPrint);
		int textInput = console.nextInt();
		return textInput;
	}

	public static int printMenuText(String menuText) {
		int userInput = 0;
		while (true) {
			try {
				System.out.println(menuText + "\n" + "  1 -- Yes\n" + "  2 -- No\n");
				System.out.print("Choose a number 1-2: ");
				userInput = console.nextInt();

				if (userInput < 1 || userInput > 2) {
					throw new Exception();
				}

				System.out.println();

				break;
			} catch (InputMismatchException e) {
				System.out.println("\n** Enter a number 1-2. **\n");
				console.nextLine();
			} catch (Exception e) {
				System.out.println("\n** Enter a number 1-2. **\n");
			}
		}
		return userInput;
	}

	public static int printMenuTextVariableOptions(String menuText, int min, int max) {
		int userInput = 0;
		while (true) {
			try {
				System.out.println(menuText + "\n");
				System.out.print("Choose a number " + min + "-" + max + ": ");
				userInput = console.nextInt();

				if (userInput < min || userInput > max) {
					throw new Exception();
				}

				System.out.println();

				break;
			} catch (Exception e) {
				System.out.println("\n** Enter a number" + min + "-" + max + "**\n");
			}
		}
		return userInput;
	}

	public static void makeSelectionMenu(ArrayList<Product> selectedProducts, PurpleBox purpleBox) {
		while (true) { // Outer while loop
			// print list of products
			int result = printMenuText("Did you find what you are looking for?");

			if (result == 1) { // if 'Yes', User did find what they were looking for...
				result = printMenuText("Add products to cart?");
				if (result == 1) {
					for (Product toCart : selectedProducts) {
						purpleBox.addToCart(toCart);
					}
					System.out.println(selectedProducts.size() + " Products have been added to your cart.");
				}
				result = printMenuText("Return to the previous menu?");
				if (result == 1) {
					break;
				}
			}
		}

	}

	public static ArrayList<Product> createProductList() {
		ArrayList<Product> productList = new ArrayList<Product>();
		Product movie1 = new Product("MovieA", "Horror", "DVD", "2018", 5, 2.00, true);
		Product movie2 = new Product("MovieB", "Drama", "DVD", "2016", 3, 2.00, true);
		Product movie3 = new Product("MovieC", "Action", "DVD", "2017", 4, 2.00, true);
		Product movie4 = new Product("MovieD", "Comedy", "Blu-Ray", "2019", 4, 2.50, true);
		Product movie5 = new Product("MovieE", "Family", "Blu-Ray", "2018", 3, 2.50, true);
		Product movie6 = new Product("MovieF", "Sci-Fi", "Blu-Ray", "2016", 5, 2.50, true);
		Product movie7 = new Product("MovieG", "Documentary", "Blu-Ray", "2017", 5, 2.50, true);
		Product game1 = new Product("GameA", "FPS", "PS4", "2018", 5, 1.50, true);
		Product game2 = new Product("GameB", "Racing", "PS4", "2019", 5, 1.50, true);
		Product game3 = new Product("GameC", "MMORPG", "XBox", "2017", 5, 1.50, true);
		Product game4 = new Product("GameD", "Strategy", "XBox", "2016", 5, 1.50, true);
		productList.add(movie1);
		productList.add(movie2);
		productList.add(movie3);
		productList.add(movie4);
		productList.add(movie5);
		productList.add(movie6);
		productList.add(movie7);
		productList.add(game1);
		productList.add(game2);
		productList.add(game3);
		productList.add(game4);
		return productList;
	}

	public static ArrayList<Product> createMovieList(ArrayList<Product> productList) {
		ArrayList<Product> movieList = new ArrayList<Product>();

		for (int i = 0; i < productList.size(); i++) {
			if (productList.get(i).getMediaType().equals("DVD")
					|| productList.get(i).getMediaType().equals("Blu-Ray")) {
				movieList.add(productList.get(i));
			}
		}

		return movieList;
	}

	public static ArrayList<Product> createGameList(ArrayList<Product> productList) {

		ArrayList<Product> gameList = new ArrayList<Product>();

		for (int i = 0; i < productList.size(); i++) {
			if (productList.get(i).getMediaType().equals("PS4") || productList.get(i).getMediaType().equals("XBox")) {
				gameList.add(productList.get(i));
			}
		}

		return gameList;
	}

	public static ArrayList<Product> createCart() {
		ArrayList<Product> cartList = new ArrayList<Product>();
		return cartList;
	}

	public static void createPromoCodes(PurpleBox purpleBox) {
		purpleBox.setPromoCodes("SUMMER50", 0.50);
		purpleBox.setPromoCodes("FALL20", 0.20);
		purpleBox.setPromoCodes("SPRING30", 0.30);
	}

}
