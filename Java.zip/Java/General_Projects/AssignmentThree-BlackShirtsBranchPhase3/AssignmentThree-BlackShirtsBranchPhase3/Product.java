package purpleBox;

public class Product {

	//data members
	private String name;
	private String genre;
	private String mediaType;
	private String releaseDate;
	private int metaScore;
	private double price;
	private boolean isAvailable;
	
	/**
	 * 
	 * @param String name
	 * @param String genre
	 * @param String mediaType
	 * @param String releaseDate
	 * @param int metaScore
	 * @param double price
	 * @param boolean isAvailable
	 */
	public Product(String name, String genre, String mediaType, String releaseDate, int metaScore, double price,
			boolean isAvailable) {
		this.name = name;
		this.genre = genre;
		this.mediaType = mediaType;
		this.releaseDate = releaseDate;
		this.metaScore = metaScore;
		this.price = price;
		this.isAvailable = isAvailable;
	}

	/**
	 * Returns Product name.
	 * 
	 * @return String name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets Product name.
	 * 
	 * @param String name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns Product genre.
	 * 
	 * @return String genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * Sets Product genre.
	 * 
	 * @param String genre
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * Returns Product media type (either DVD, Blu-Ray, PS4, or XBox).
	 * 
	 * @return String mediaType
	 */
	public String getMediaType() {
		return mediaType;
	}

	/**
	 * Sets Product media type (either DVD, Blu-Ray, PS4, or XBox).
	 * 
	 * @param String mediaType
	 */
	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	/**
	 * Returns Product release date.
	 * 
	 * @return String releaseDate
	 */
	public String getReleaseDate() {
		return releaseDate;
	}

	/**
	 * Sets Product release date.
	 * 
	 * @param String releaseDate
	 */
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	/**
	 * Returns Product meta score.
	 * 
	 * @return int metaScore
	 */
	public int getMetaScore() {
		return metaScore;
	}

	/**
	 * Sets Product meta score.
	 * 
	 * @param int metaScore
	 */
	public void setMetaScore(int metaScore) {
		this.metaScore = metaScore;
	}

	/**
	 * Returns Product price.
	 * 
	 * @return double price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Sets Product price.
	 * 
	 * @param double price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * Returns whether Product is available or not.
	 * 
	 * @return boolean isAvailable (true || false)
	 */
	public boolean isAvailable() {
		return isAvailable;
	}

	/**
	 * Sets whether Product is available or not.
	 * 
	 * @param boolean isAvailable (true || false)
	 */
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	/**
	 * Returns Product information for User.
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return "---------------------------------------\n"
				+ "Name: " + this.name 
				+ "\nDiscType: " + this.mediaType
				+ "\nGenre: " + this.genre
				+ "\nRelease Date: " + this.releaseDate
				+ "\nmetaScore: " + this.metaScore
				+ "\nPrice: " + this.price
				+ "\nisAvailable" + this.isAvailable
				+ "\n--------------------------------------------\n";
	}
	
	
}
