package purpleBox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

public class PurpleBox implements PurpleBoxUserInterface, PurpleBoxAdministratorInterface {

	static Scanner console = new Scanner(System.in);
	boolean unitEnabled = false;
	ArrayList<Product> allProducts = new ArrayList<>();
	ArrayList<Product> movieList = new ArrayList<>();
	ArrayList<Product> gameList = new ArrayList<>();
	ArrayList<Product> cart = new ArrayList<>();
	HashMap<String, Double> promoCodes = new HashMap<>();
	
	public HashMap<String, Double> getPromoCodes() {
		return promoCodes;
	}

	public void setPromoCodes(HashMap<String, Double> promoCodes) {
		this.promoCodes = promoCodes;
	}

	public ArrayList<Product> getCart() {
		return cart;
	}

	public void setCart(ArrayList<Product> cart) {
		this.cart = cart;
	}

	public ArrayList<Product> getMovieList() {
		return movieList;
	}

	public void setMovieList(ArrayList<Product> movieList) {
		this.movieList = movieList;
	}

	public ArrayList<Product> getGameList() {
		return gameList;
	}

	public void setGameList(ArrayList<Product> gameList) {
		this.gameList = gameList;
	}

	public ArrayList<Product> getAllProducts() {
		return allProducts;
	}

	public void setAllProducts(ArrayList<Product> allProducts) {
		this.allProducts = allProducts;
	}

	@Override
	public void addToCart(Product someProduct) {
		cart.add(someProduct);
	}

	@Override
	public void removeFromCart( Product someProduct) {
		for (int i = 0; i < cart.size(); i++) {
			if (cart.get(i) == someProduct) {
				cart.remove(i);
				break;
			}
		}
	}

	@Override
	public void emptyCart() {
		cart.clear();
	}

	@Override
	public boolean isProductAvailable(Product someProduct) {
		if (someProduct.isAvailable() == true) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void checkout() {
		int userInput = -1;
		String method = "";

		

		do {
			try {
				System.out.println("Your total amount owed is: " + totalCartCost());
				System.out.print("What's your payment method?\n" + "  1 -- Debit\n" + "  2 -- Credit\n");
				System.out.print("Make a selection: ");
				userInput = console.nextInt();

				if (userInput < 1 || userInput > 2) {
					throw new Exception();
				}

				System.out.println();

				break;

			} catch (InputMismatchException e) {
				System.out.println("** Enter a number 1-2 **");
				console.nextLine();
			} catch (Exception e) {
				System.out.println("** Enter a number 1-2 **");
			}
		} while (true);

		switch (userInput) {
		case 1:
			method = "debit";
			break;
		case 2:
			method = "credit";
			break;
		}
		do {
			try {
				System.out.print("Do you have a promo code?\n" + "  1 -- Yes\n" + "  2 -- No\n");
				System.out.print("Make a selection: ");
				userInput = console.nextInt();

				if (userInput < 1 || userInput > 2) {
					throw new Exception();
				}

				System.out.println();

				break;

			} catch (InputMismatchException e) {
				System.out.println("** Enter a number 1-2 **");
				console.nextLine();
			} catch (Exception e) {
				System.out.println("** Enter a number 1-2 **");
			}
		} while (true);
		
		if(userInput == 1) {
			do {
					System.out.print("Please enter promo code: \n" );
					String promoCode = console.next();
					Double foundPromoCodeDiscount = promoCodes.get(promoCode);
					if(foundPromoCodeDiscount == null) {
						System.out.println("Promo Code not found.");
					} else {
						setVolumeDiscount(foundPromoCodeDiscount);
						System.out.println("Applied promo code with discount" + foundPromoCodeDiscount+".");
						System.out.println("Total cost after applied discount: " + totalCartCost());
						System.out.println("Payment Accepted, We thank you for your business!");
						break;
					}
			} while (true);
		}
		makePayment(method);
	}

	public double totalCartCost() {
		double totalCost = 0.0;
		for (int i = 0; i < cart.size(); i++) {
			totalCost += cart.get(i).getPrice();
		}
		return totalCost;
	}

	@Override
	public void makePayment(String method) {
		emptyCart();
	}

	

	@Override
	public void sortByName(ArrayList<Product> allProducts) {
		int minIndex;
		Product temp;

		for (int x = 0; x < allProducts.size(); x++) {
			minIndex = x;

			for (int i = x; i < allProducts.size(); i++) {
				if (allProducts.get(i).getName().compareToIgnoreCase(allProducts.get(minIndex).getName()) < 0) {
					minIndex = i;
				}
			}

			temp = allProducts.get(x);
			allProducts.set(x, allProducts.get(minIndex));
			allProducts.set(minIndex, temp);
		}
	}

	@Override
	public void sortByReleaseDate(ArrayList<Product> allProducts) {
		int maxIndex;
		Product temp;

		for (int x = 0; x < allProducts.size(); x++) {
			maxIndex = x;

			for (int i = x; i < allProducts.size(); i++) {
				if (allProducts.get(i).getReleaseDate()
						.compareToIgnoreCase(allProducts.get(maxIndex).getReleaseDate()) > 0) {
					maxIndex = i;
				}
			}

			temp = allProducts.get(x);
			allProducts.set(x, allProducts.get(maxIndex));
			allProducts.set(maxIndex, temp);
		}
	}

	@Override
	public void sortByMetaScore(ArrayList<Product> allProducts) {
		int maxIndex;
		Product temp;

		for (int x = 0; x < allProducts.size(); x++) {
			maxIndex = x;

			for (int i = x; i < allProducts.size(); i++) {
				if (allProducts.get(i).getMetaScore() > allProducts.get(maxIndex).getMetaScore()) {
					maxIndex = i;
				}
			}

			temp = allProducts.get(x);
			allProducts.set(x, allProducts.get(maxIndex));
			allProducts.set(maxIndex, temp);
		}
	}

	@Override
	public ArrayList<Product> viewAllMovies() {

		return movieList;
	}

	@Override
	public ArrayList<Product> viewAllGames() {

		return gameList;
	}

	public ArrayList<Product> searchByName(ArrayList<Product> allProducts, String productName) {
		ArrayList<Product> foundProducts = new ArrayList<>();

		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getName().equalsIgnoreCase(productName)) {
				foundProducts.add(allProducts.get(i));
			}
		}
		return foundProducts;
	}

	public ArrayList<Product> searchByGenre(ArrayList<Product> allProducts, String genre) {
		// declare variables

		ArrayList<Product> foundProducts = new ArrayList<>();

		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getGenre().equalsIgnoreCase(genre)) {
				foundProducts.add(allProducts.get(i));
			}
		}
		return foundProducts;
	}

	@Override
	public ArrayList<Product> searchByFormat(ArrayList<Product> allProducts, String mediaType) {
		ArrayList<Product> foundProducts = new ArrayList<>();

		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getMediaType().equalsIgnoreCase(mediaType)) {
				foundProducts.add(allProducts.get(i));
			}
		}
		return foundProducts;

	}

	@Override
	public ArrayList<Product> searchByReleaseDate(ArrayList<Product> allProducts, String releaseDate) {
		ArrayList<Product> foundProducts = new ArrayList<>();

		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getReleaseDate().equalsIgnoreCase(releaseDate)) {
				foundProducts.add(allProducts.get(i));
			}
		}
		return foundProducts;
	}

	@Override
	public ArrayList<Product> searchByMetaScore(ArrayList<Product> allProducts, int metaScore) {
		ArrayList<Product> foundProducts = new ArrayList<>();

		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getMetaScore() == metaScore) {
				foundProducts.add(allProducts.get(i));
			}
		}
		return foundProducts;
	}

	@Override
	public void addProductToInventory(Product someProduct) {
		allProducts.add(someProduct);

	}
	
	public void addProductToMovieInventory(Product someProduct) {
		movieList.add(someProduct);

	}

	public void addProductToGameInventory(Product someProduct) {
		gameList.add(someProduct);

	}


	@Override
	public boolean removeProductFromInventory(Product someProduct) {
		return allProducts.remove(someProduct);
	}

	@Override
	public void removeAllFromInventory() {
		allProducts.clear();

	}

	public void changeDVDPrice(double newDVDPrice) {
		String mediaType = "DVD";
		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getMediaType().equals(mediaType)) {
				allProducts.get(i).setPrice(newDVDPrice);
			}
		}
	}

	public void changeBluRayPrice(double newBluRayPrice) {
		String mediaType = "BluRay";
		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getMediaType().equals(mediaType)) {
				allProducts.get(i).setPrice(newBluRayPrice);
			}
		} // end for loop
	}// end ChangeBluRayPrice

	public void changeGamePrice(double newGamePrice) {
		String mediaTypeOne = "Xbox";
		String mediaTypeTwo = "PS4";
		for (int i = 0; i < allProducts.size(); i++) {
			if (allProducts.get(i).getMediaType().equals(mediaTypeOne)
					|| allProducts.get(i).getMediaType().equals(mediaTypeTwo)) {
				allProducts.get(i).setPrice(newGamePrice);
			}
		} // end for loop
	}// end changeGamePrice

	@Override
	public void setVolumeDiscount(double discount) {
		for (Product productToDiscount : cart) {
			double finalPrice = productToDiscount.getPrice() - (productToDiscount.getPrice() * discount);
			productToDiscount.setPrice(finalPrice);
		}
	}
	@Override
	public void setPromoCodes(String codes, double discount) {
		promoCodes.put(codes, discount);
	}
	@Override
	public boolean disableUnit(boolean status) {
		unitEnabled = status;
		return unitEnabled;
	}
	@Override
	public boolean enableUnit(boolean status) {
		unitEnabled = status;
		return unitEnabled;
	}

}
