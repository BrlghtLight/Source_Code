//
//  SettingsController.swift
//  WizardingHats
//
//  Created by Comisky, Jon T on 5/4/19.
//  Copyright © 2019 Comisky, Jon T. All rights reserved.
//

import UIKit

class SettingsController: UIViewController{
    
}
