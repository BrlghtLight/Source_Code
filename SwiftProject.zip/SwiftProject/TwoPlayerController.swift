//
//  TwoPlayerController.swift
//  WizardingHats
//
//  Created by Comisky, Jon T on 5/3/19.
//  Copyright © 2019 Comisky, Jon T. All rights reserved.
//

import UIKit

class TwoPlayerController: UIViewController{
    var home: UIImageView = UIImageView()
    var settings: UIImageView = UIImageView()
    var player1Life: UILabel = UILabel()
    var player2Life: UILabel = UILabel()
    var player1Plus: UIImageView = UIImageView()
    var player2Plus: UIImageView = UIImageView()
    var player1Minus: UIImageView = UIImageView()
    var player2Minus: UIImageView = UIImageView()
    var player1Frame: UIView = UIView()
    var player2Frame: UIView = UIView()
    var oneLifeTotal: Int = Int(20)
    var twoLifeTotal: Int = Int(20)

    
    override func viewDidLoad() {
        self.view.backgroundColor = UIColor.lightGray
        //setup home button
        home.image = UIImage(named: "home.png")
        home.frame = CGRect(x: WIDTH/50, y: 28.4*HEIGHT/30, width: WIDTH/17, height: HEIGHT/23)
        home.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(homeButtonHandler)))
        home.isUserInteractionEnabled = true
        //setup settings button
        settings.image = UIImage(named: "settings.png")
        settings.frame = CGRect(x: 9.3*WIDTH/10, y: 28.5*HEIGHT/30, width: WIDTH/17, height: WIDTH/17)
        settings.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(settingsButtonHandler)))
        settings.isUserInteractionEnabled = true
        
        //setup top screen minus button
        player2Minus.isUserInteractionEnabled = true
        player2Minus.image = UIImage(named: "minus.png")
        player2Minus.frame = CGRect(x: (WIDTH/2)-(WIDTH/20), y: 3*HEIGHT/30, width: WIDTH/10, height: WIDTH/10)
       player2Minus.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(twoMinusButtonHandler)))
        
        //setup top screen plus button
        player2Plus.isUserInteractionEnabled = true
        player2Plus.image = UIImage(named: "plus.png")
        player2Plus.frame = CGRect(x: (WIDTH/2)-(WIDTH/20), y: 10*HEIGHT/30, width: WIDTH/10, height: WIDTH/10)
        player2Plus.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(twoPlusButtonHandler)))
        
        //setup bottom screen plus button
        player1Plus.isUserInteractionEnabled = true
        player1Plus.image = UIImage(named: "plus.png")
        player1Plus.frame = CGRect(x: (WIDTH/2)-(WIDTH/20), y: 18*HEIGHT/30, width: WIDTH/10, height: WIDTH/10)
        player1Plus.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onePlusButtonHandler)))
        
        //setup bottom screen minus button
        player1Minus.isUserInteractionEnabled = true
        player1Minus.image = UIImage(named: "minus.png")
        player1Minus.frame = CGRect(x: (WIDTH/2)-(WIDTH/20), y: 25*HEIGHT/30, width: WIDTH/10, height: WIDTH/10)
       player1Minus.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(oneMinusButtonHandler)))
        
        //declare swipeUp and swipeDown for one and two
        let oneSwipeUp = UISwipeGestureRecognizer(target: self, action: #selector(SwipeUpHandler(_:)))
        let oneSwipeDown = UISwipeGestureRecognizer(target: self, action: #selector(SwipeDownHandler(_:)))
        let twoSwipeUp = UISwipeGestureRecognizer(target: self, action: #selector(SwipeUpHandler(_:)))
        let twoSwipeDown = UISwipeGestureRecognizer(target: self, action: #selector(SwipeDownHandler(_:)))
        //assign direction for each swipe handler
        oneSwipeUp.direction = .up
        oneSwipeDown.direction = .down
        twoSwipeUp.direction = .up
        twoSwipeDown.direction = .down
        
        //setup frame for bottom half
        player1Frame.frame = CGRect(x: 0, y: HEIGHT/2, width: WIDTH, height: HEIGHT/2)
        player1Frame.backgroundColor = RED
        player1Frame.addGestureRecognizer(oneSwipeUp)
        player1Frame.addGestureRecognizer(oneSwipeDown)
        
        //setup frame for top half
        player2Frame.frame = CGRect(x: 0, y: 0, width: WIDTH, height: HEIGHT/2)
        player2Frame.backgroundColor = GREEN
        player2Frame.addGestureRecognizer(twoSwipeDown)
        player2Frame.addGestureRecognizer(twoSwipeUp)
        
        //setup life total for top screen
        player1Life.font = UIFont(name: "Helvetica", size: WIDTH/6)
        player1Life.frame = CGRect(x: (WIDTH/2)-(WIDTH/4), y: 21*HEIGHT/30, width: WIDTH/2, height: WIDTH/6)
        player1Life.textAlignment = NSTextAlignment.center
        player1Life.text = String(oneLifeTotal)
        
        
        //setup life total for bottom screen
        player2Life.font = UIFont(name: "Helvetica", size: WIDTH/6)
        player2Life.frame = CGRect(x: (WIDTH/2)-(WIDTH/4), y: 6*HEIGHT/30, width: WIDTH/2, height: WIDTH/6)
        player2Life.textAlignment = NSTextAlignment.center
        player2Life.text = String(twoLifeTotal)
        player2Life.transform =
player2Life.transform.rotated(by: CGFloat(Double.pi))
        
        
        self.view.addSubview(player1Frame)
        self.view.addSubview(player2Frame)
        self.view.addSubview(home)
        self.view.addSubview(settings)
        self.view.addSubview(player1Life)
        self.view.addSubview(player2Life)
        self.view.addSubview(player1Plus)
        self.view.addSubview(player2Plus)
        self.view.addSubview(player1Minus)
        self.view.addSubview(player2Minus)
        
    }
    
    @objc func homeButtonHandler(){
        let alert: UIAlertController
            = UIAlertController(title: "Return to Main Menu?", message: "Are you sure? You will lose the current game state.", preferredStyle:
                UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            
            self.presentingViewController?.dismiss(animated: true, completion: {() -> Void in
            })
        }))
        alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.destructive, handler: {(_: UIAlertAction!) in
            
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func settingsButtonHandler(){
        present(SettingsController(), animated: true) {
        }
    }
    
    @objc func onePlusButtonHandler(){
        oneLifeTotal += 1
        player1Life.text = String(oneLifeTotal)
        
    }
    
    @objc func oneMinusButtonHandler(){
        oneLifeTotal = (oneLifeTotal - 1)
        player1Life.text = String(oneLifeTotal)
    }
    
    @objc func twoPlusButtonHandler(){
        twoLifeTotal += 1
        player2Life.text = String(twoLifeTotal)
    }
    
    @objc func twoMinusButtonHandler(){
        twoLifeTotal = (twoLifeTotal - 1)
        player2Life.text = String(twoLifeTotal)
    }
    
    @objc func SwipeUpHandler(_ gestureRecognizer: UISwipeGestureRecognizer){
        if gestureRecognizer.view == player1Frame {
        oneLifeTotal += 5
        player1Life.text = String(oneLifeTotal)}
        else if gestureRecognizer.view == player2Frame{
            twoLifeTotal -= 5
            player2Life.text = String(twoLifeTotal)
        }else{
            
        }
    }
    
    
    @objc func SwipeDownHandler(_ gestureRecognizer: UISwipeGestureRecognizer){
        if gestureRecognizer.view == player1Frame {
            oneLifeTotal -= 5
            player1Life.text = String(oneLifeTotal)}
        else if gestureRecognizer.view == player2Frame{
            twoLifeTotal += 5
            player2Life.text = String(twoLifeTotal)
        }else{
            
        }
    }
}
