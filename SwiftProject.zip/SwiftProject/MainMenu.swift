//
//  ViewController.swift
//  WizardingHats
//
//  Created by Comisky, Jon T on 4/29/19.
//  Copyright © 2019 Comisky, Jon T. All rights reserved.
//

import UIKit
let WIDTH: CGFloat = UIScreen.main.bounds.width
let HEIGHT: CGFloat = UIScreen.main.bounds.height
let GREEN: UIColor = UIColor.init(red: 0, green: 115/255, blue: 62/255, alpha: 1)
let RED: UIColor = UIColor.init(red: 211/255, green: 32/255, blue: 42/255, alpha: 1)
let BLACK: UIColor = UIColor.init(red: 21/255, green: 11/255, blue: 0/255, alpha: 1)
let BLUE: UIColor = UIColor.init(red: 14/255, green: 104/255, blue: 171/255, alpha: 1)
let WHITE: UIColor = UIColor.init(red: 249/255, green: 250/255, blue: 244/255, alpha: 1)

class MainMenu: UIViewController {
    private let IMGLIST: [String] = [String](arrayLiteral: "liliana.jpg", "liliana2.png", "teyo.png", "Domri.png", "sorin.jpg", "vraska.png", "theWanderer.jpg", "gideon.jpg")
    private var copyright: UILabel = UILabel()
    private var appName: UILabel = UILabel()
    private var appName2: UILabel = UILabel()
    private var twoPlayer: UIButton = UIButton(type: UIButton.ButtonType.roundedRect)
    private var settings: UIButton = UIButton(type: UIButton.ButtonType.roundedRect)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        appName.font = UIFont(name: "Cochin", size: 40)
        appName.textColor = UIColor.init(red: 230/255, green: 230/255, blue: 230/255, alpha: 0.8)
        appName.text = "Wizarding Hats"
        appName.textAlignment = NSTextAlignment.center
        appName.frame = CGRect(x: WIDTH/230, y: HEIGHT/20, width: WIDTH, height: HEIGHT/10)
        appName2.font = UIFont(name: "Cochin", size: 40)
        appName2.textColor = UIColor.black
        appName2.text = "Wizarding Hats"
        appName2.textAlignment = NSTextAlignment.center
        appName2.frame = CGRect(x: 0, y: HEIGHT/20, width: WIDTH, height: HEIGHT/10)
        
        twoPlayer.titleLabel?.font = UIFont(name: "Cochin", size: 32)
        twoPlayer.frame = CGRect(x: WIDTH/78, y: 10*HEIGHT/15, width: 7.8*WIDTH/8, height: HEIGHT/10)
        twoPlayer.layer.cornerRadius = 10
        twoPlayer.layer.borderWidth = 2
        twoPlayer.backgroundColor = UIColor.white
        twoPlayer.isOpaque = false
        twoPlayer.layer.opacity = 0.75
        twoPlayer.setTitle("Two Players", for: UIButton.State.normal)
        twoPlayer.setTitleColor(UIColor.black, for: UIButton.State.normal)
        twoPlayer.isUserInteractionEnabled = true
        twoPlayer.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MainMenu.twoPlayerButtonHandler)))
        
        settings.titleLabel?.font = UIFont(name: "Cochin", size: 32)
        settings.frame = CGRect(x: WIDTH/78, y: 12*HEIGHT/15, width: 7.8*WIDTH/8, height: HEIGHT/10)
        settings.layer.cornerRadius = 10
        settings.layer.borderWidth = 2
        settings.backgroundColor = UIColor.white
        settings.isOpaque = false
        settings.layer.opacity = 0.75
        settings.setTitle("Settings", for: UIButton.State.normal)
        settings.setTitleColor(UIColor.black, for: UIButton.State.normal)
        settings.setTitleColor(UIColor.white, for: UIControl.State.selected)
        settings.isUserInteractionEnabled = true
        settings.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(MainMenu.settingsButtonHandler)))
        
        copyright.font = UIFont(name: "Cochin", size: 28)
        copyright.textColor = UIColor.darkGray
        copyright.text = "Copyright 2019 WalCom"
        copyright.textAlignment = NSTextAlignment.center
        copyright.frame = CGRect(x: 0, y: 13.8*HEIGHT/15, width: WIDTH, height: WIDTH/10)
        
        assignBackground(name: IMGLIST[Int.random(in: 0...7)])
        self.view.addSubview(appName)
        self.view.addSubview(appName2)
        self.view.addSubview(twoPlayer)
        self.view.addSubview(settings)
        self.view.addSubview(copyright)
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    func assignBackground(name: String){
        let background = UIImage(named: name)
        
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIView.ContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubviewToBack(imageView)
    }
    @objc func twoPlayerButtonHandler(){
        present(TwoPlayerController(), animated: true)
    }
    @objc func settingsButtonHandler(){
        present(SettingsController(), animated: true)
    }
}

